# Arena Desktop — как устроено всё приложение

Справочник по всему приложению, а не только по входу. Написан по коду
(`arena/*.py`, `arena/web/app.py`, `arena/web/static/app.js`) и по боевым логам
`desktop-*.log`. Ничего не сокращено: и работающее, и сломанное, с указанием,
где именно смотреть.

Если поведение изменится — правьте этот файл. Иначе он начнёт врать, а врать в
документе про авторизацию опаснее всего: по нему чинят.

Оглавление:

1. Что это за приложение и из чего состоит
2. Как оно запускается (процесс, порты, окна)
3. Поток запроса: от нажатия кнопки до arena.ai
4. Режимы и модальности
5. Экран загрузки (гейт)
6. Авторизация Arena — все кнопки и пути
7. Авторизация Google — все кнопки и пути
8. Чаты и история
9. Файлы, воркспейс, терминал, гит
10. Агент, инструменты, разрешения
11. MCP-коннекторы и шлюз
12. Автоматизации, память, настройки
13. Диагностика и логи
14. Сборка EXE
15. Полный список известных дефектов

---

## 1. Что это за приложение и из чего состоит

Arena Desktop — **нативное окно поверх локального веб-приложения**. Не Electron,
не веб-сайт в браузере: pywebview создаёт настоящее окно Windows, внутри которого
работает Edge WebView2, а внутри него — локальный Flask-сервер, отдающий
одностраничное приложение.

Ключевая идея: у Arena нет публичного API для чатов, который можно было бы просто
вызывать. Поэтому приложение **управляет настоящей страницей arena.ai** в
отдельном окне — так же, как это делал бы человек: печатает запрос в поле ввода,
нажимает отправить, читает ответ. Побочный эффект: вход, капча и проверки
безопасности делаются человеком в этом окне, а не подделкой запросов.

```
┌──────────────────────────────────────────────────────────────┐
│ Главное окно (pywebview / WebView2)                          │
│   http://127.0.0.1:<port>/  ← Flask отдаёт index.html+app.js │
│   ┌────────────────────────────────────────────────────────┐ │
│   │ Интерфейс: чаты, режимы, файлы, настройки, гейт         │ │
│   └────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
        │ fetch /api/...                │ pywebview js_api
        ▼                               ▼
┌────────────────────────┐    ┌──────────────────────────────┐
│ Flask (arena/web/app.py│    │ JsBridge (desktop.py)        │
│ 11 351 строка, 119     │    │ окно: свернуть/показать      │
│ маршрутов /api/*)      │    └──────────────────────────────┘
└───────────┬────────────┘
            │
   ┌────────┴──────────┬──────────────┬───────────────┐
   ▼                   ▼              ▼               ▼
Engine (engine.py)  Api (api.py)  GoogleEngine    Локальные
окно arena.ai,      HTTP-клиент   (google_ai.py)  инструменты
отправка чатов      к arena.ai    окно google.com (agent.py,
                                                     tools/*)
```

### Файлы и их роли

| Файл | Строк | Что делает |
|---|---|---|
| `arena/web/app.py` | 11 351 | весь бэкенд: 119 маршрутов `/api/*`, гейт, аккаунты, чаты, файлы |
| `arena/web/static/app.js` | ~14 400 | весь фронтенд одним файлом, без сборки |
| `arena/web/static/index.html` | — | разметка, подключает app.js и style.css |
| `arena/engine.py` | 1 694 | окно arena.ai: вход, отправка чата, чтение ответа, капча |
| `arena/api.py` | 762 | HTTP-клиент arena.ai: `/me`, отправка, разбор потока |
| `arena/google_ai.py` | ~1 450 | окно google.com: вход, cookie jar, чтение DOM |
| `arena/google_http.py` | 663 | Google AI mode по чистому HTTPS, без окна |
| `arena/desktop.py` | 627 | точка сборки окна: Flask в потоке, окна, трей, deep-link |
| `arena/auth.py` | 219 | поиск cookie в браузерах, парсинг, буфер обмена |
| `arena/agent.py` | 677 | локальные инструменты для чатов (файлы, команды) |
| `arena/native_agent.py` | 852 | протокол Native Arena Agent |
| `arena/permissions.py` | 125 | режимы разрешений (как в Claude Code) |
| `arena/workspace.py` | 145 | локальные папки проектов |
| `arena/connectors.py` | 576 | MCP-коннекторы |
| `arena/gateway.py` | 776 | шлюз: локальный MCP наружу через Cloudflare Tunnel |
| `arena/diag.py` | 522 | логи, heartbeat, дампы стеков |
| `arena/models.py` | 559 | каталог моделей, кэш, маршрутизация по модальности |
| `arena/history_sync.py` | 445 | импорт облачной истории в локальные чаты |
| `arena/deep_links.py` | 217 | `arenadesktop://` ссылки |
| `arena/crypto.py` | 120 | DPAPI-защита cookie на диске |
| `arena/procguard.py` | 84 | Job Object: дочерние процессы умирают с приложением |
| `arena/tools/*` | — | file/shell/mcp/browser инструменты |
| `arena-cli.py` | 37 | вход: `main()` из desktop.py |

---

## 2. Как оно запускается

`arena-cli.py` → `arena/desktop.py::main()`.

1. **Порт.** `find_free_port()` занимает любой свободный порт на `127.0.0.1`.
   Порт не фиксирован — поэтому адрес берётся из окружения, а не из константы.
2. **Flask в отдельном потоке.** `start_flask(port)` поднимает
   `arena.web.app.app` с `threaded=True`. Это важно: запросы обрабатываются
   параллельно, и именно поэтому блокировка одного потока (например, ожидание
   .NET-задачи с GIL) останавливает **всё** приложение, а не один запрос.
3. **Ожидание порта.** `wait_port` до 10 с.
4. **Три окна pywebview:**

| Окно | Назначение | Стартовое состояние |
|---|---|---|
| `Arena Desktop` | главное, интерфейс | видимо (или скрыто при `--background`) |
| `arena.ai - Arena Desktop` | окно входа/капчи/движка | скрыто, показывается по требованию |
| `Google AI mode - Arena Desktop` | вход в Google | скрыто, `about:blank` до первого использования |

5. **`webview.start(gui="edgechromium", private_mode=False, storage_path=...)`.**
   `private_mode=False` + `storage_path` = cookie и localStorage переживают
   перезапуск; все три окна делят один профиль WebView2.
6. **Трей.** Если включён `tray_enabled` или запуск с `--background`, закрытие
   окна сворачивает в трей, а не выходит.
7. **Deep-link.** `arenadesktop://` обрабатывается через второй процесс и
   передаётся первому по `/api/deep-link` с одноразовым `INSTANCE_TOKEN`.

### Почему всё однопроцессное и почему это важно

Внутри одного процесса живут: UI-поток WinForms, потоки Flask, потоки
наблюдения (`google-signin-watch`, `diag-heartbeat`, `diag-watchdog`).
WinForms и WebView2 — apartment-bound: обращаться к ним можно **только** с
UI-потока. Любой вызов оттуда же, который ждёт завершения .NET-задачи, держит
GIL и останавливает вообще все Python-потоки. Отсюда два правила, разбросанных
по коду:

* всё, что касается `CoreWebView2` — только через `_on_ui()`;
* ждать задачи можно только снаружи UI-вызова, опросом `IsCompleted`, никогда
  через `Task.Wait()`.

Нарушение любого из них выглядит в логах как «всё замерло, исключения нет,
crash-файл пустой».

---

## 3. Поток запроса: от кнопки до arena.ai

```
[клик] → app.js → fetch('/api/...', {headers: {'X-Arena-Token': ...}})
       → Flask: _local_same_origin_only (проверка Host и токена)
       → маршрут (/api/chat, /api/models, ...)
       → Engine.request() или Api.send_chat()
       → arena.ai
       → стрим обратно: SSE/JSON → app.js → DOM
```

### Охранник `_local_same_origin_only` (app.py ~10337)

Выполняется **перед каждым** запросом:

* `Host` должен быть `127.0.0.1` или `localhost` — иначе 403 `Unknown host`.
  Это защита от DNS rebinding и от чужих превью.
* Для `/api/*` обязателен заголовок `X-Arena-Token` = `_API_TOKEN`. Иначе 403
  `Missing or invalid API token`. Токен генерируется при старте и попадает в
  `index.html`.
* Единственное исключение — `POST /api/deep-link` с верным
  `X-Arena-Instance-Token` (одноразовый, для передачи ссылки из второго процесса).
* Для не-GET методов проверяется `Origin`.

Практическое следствие: обращаться к API «просто curl'ом» не выйдет — нужен
токен. В тестах он берётся как `app._API_TOKEN`.

### Движок arena.ai (engine.py)

`Engine.request(path, body, method, timeout)` — общий путь ко всем внутренним
эндпоинтам arena.ai. `Engine.send_chat(...)` — отправка сообщения: печатает в
поле ввода страницы, ждёт ответа, читает DOM, отдаёт текст по мере появления.

`Engine.state()` возвращает словарь, по которому UI решает, что показывать:
`attached`, `ready`, `challenge`, `host`, `login_open`, `open`, `separate_window`.

---

## 4. Режимы и модальности

Из `contracts.py`:

```python
API_MODES = ("battle", "side-by-side", "direct-battle", "direct")
API_MODALITIES = ("auto", "chat", "webdev", "search", "image", "p2l", "video", "audio")
UI_MODES = {"battle": "battle", "side-by-side": "side-by-side",
            "direct": "direct-battle", "agent": "direct-battle"}
```

| Режим | Что это | Как выглядит |
|---|---|---|
| `battle` | две модели отвечают на один запрос, ответы сравниваются | два столбца, голосование |
| `side-by-side` | две выбранные модели рядом | два столбца, модели выбираются вручную |
| `direct-battle` | одна модель, но в режиме сравнения | один столбец |
| `direct` | прямая переписка с моделью | один столбец |

`UI_MODES` переводит язык интерфейса в язык API: кнопка «direct» отправляет
`direct-battle`, кнопка «agent» — тоже `direct-battle` (агент работает в прямом
режиме).

**Про «при чём тут battle-mode».** Battle — это штатный режим arena.ai: сайт
показывает два ответа и просит выбрать лучший, на этом построена его модель
рейтинга. Приложение его поддерживает, потому что это режим по умолчанию на
сайте, а не потому что он нужен для чата. Если он мешает — переключение режима
уводит на `direct`, и сравнение моделей больше не запрашивается. Модальности
(`chat`, `webdev`, `image`, ...) ортогональны режиму: режим — как показывать,
модальность — что именно генерировать.

---

## 5. Экран загрузки (гейт)

Файл: `app.js`, `boot()`, `runBootGate()`, `runBootCheck()`, `bootSetState()`,
`bootAddActions()`, `bootNote()`, `bootClose()`. Бэкенд:
`GET /api/readiness` (app.py ~1383).

### Порядок и смысл шагов

```
dependencies → integrity → accounts → chats → models
```

Проверяются строго по очереди: следующий запрос уходит только после ответа
предыдущего (`GET /api/readiness?check=<id>`).

| id | Проверяет | Блокирует |
|---|---|---|
| `dependencies` | импорт обязательных модулей, наличие движка | **да** |
| `integrity` | целостность файлов приложения | **да** |
| `accounts` | есть ли живая сессия arena.ai (`optional: False`) | **да** |
| `chats` | доступен ли список чатов | нет |
| `models` | доступен ли каталог моделей (анонимно 403) | нет |

Фактическое поведение на живом сервере с токеном:

```
dependencies  ok=True     accounts  ok=False
integrity     ok=True     models    ok=False
chats         ok=True
```

Блокируют только `dependencies` и `integrity`. `accounts` и `models` ждут входа.

### «Блокирует» = кнопка, а не стена

Упавший шаг помечается `failed`, и внизу появляется **Continue anyway**
(`bootContinue`), ведущая в `startApp()`. Экран не запирает насмерть, но и не
пропускает молча: человек видит, что именно не проверено. Ложный отказ при
рабочей системе — баг, а не задумка.

### Особые ветки

* **Список шагов не пришёл** (эндпоинт недоступен) → гейт закрывается сразу,
  приложение стартует. Осознанный выбор: не запирать человека из-за сломанного
  эндпоинта. Цена: при полностью лежащем сервере причина не показывается.
* **Таймаут шага** — 8 с через `AbortController`. Таймаут = «не подтверждено, но
  не блокирует» с текстом «the check did not answer within 8 seconds». Медленная
  машина не превращается в «сломанную установку».
* **`bootClose()`** только скрывает оверлей; приложение стартует через
  `startApp()` с флагом `APP_STARTED` (защита от двойного старта).

---

## 6. Авторизация Arena — все кнопки и пути

### Где живёт сессия

`Client` в web-слое: cookie `arena-auth-prod-v1…` (префикс из
`contracts.AUTH_COOKIE_PREFIX`). На диске — в зашифрованном виде через DPAPI
(`arena/crypto.py`), чтобы cookie нельзя было просто скопировать из файла.

### Бэкенд `POST /api/login` (app.py ~1584)

| `method` | Что делает |
|---|---|
| `window` | проверяет `_engine_on()`; сбрасывает `_me_cache`; `ENGINE.open_login()`; отвечает `{ok, pending}`. **Ничего не входит** — открывает окно |
| `auto` | ищет cookie сам: сначала `fetch_cookies_via_cdp` (Chrome DevTools, порт 9222), затем `_extract_browser_cookies` (профили Chrome/Edge/Brave) |
| `clipboard` | берёт строку из буфера обмена |
| `manual` | берёт `cookie` из тела запроса |

Далее любой путь идёт в `_activate_cookie()`:

1. `parse_cookie_input(raw)`;
2. обязателен префикс `arena-auth-prod-v1`, иначе 400 «That text has no
   arena-auth-prod-v1 cookie»;
3. посторонние cookie отбрасываются — в аккаунт попадают только auth-чанки;
4. cookie проверяется запросом `/me`; при успехе `_me_cache` обновляется,
   `_register_account()` добавляет аккаунт в список.

**Про `auto`:** свежие Chrome шифруют cookie так, что другое приложение их не
прочитает. Отказ здесь — частое и ожидаемое поведение, а не поломка; текст
ошибки это и говорит.

### `GET /api/login/poll` — единственное место, где вход «завершается»

```python
st = ENGINE.state()
if not ENGINE.ready():
    → {done: false, hint}  или  {done: true, error: "window closed"}
user, err = ENGINE.get_me()          # прямой /me на arena.ai
if not user or not email:
    → {done: not login_open, hint: "guest only / not signed in"}
ENGINE.sync_to(get_client())         # cookie из окна → HTTP-клиент
_register_account(...)
ENGINE.finish_login()                # ← окно закрывается ЗДЕСЬ
→ {ok: true, done: true, accounts: [...]}
```

`ENGINE.finish_login()` — единственный код, закрывающий окно входа. Он живёт
внутри поллинга, поэтому **без поллинга окно не закроется никогда**.

### Кнопка «Sign in to Arena» на гейте

1. `POST /api/login {method: 'window'}` → окно открылось, ответ `pending`.
2. Тост «Finish signing in inside the Arena window…», под шагом появляется
   `bootNote` «Waiting for you to finish signing in…».
3. Цикл до 600 раз по 1 с: `GET /api/login/poll`.
4. `done: true` → `await runBootGate()`: экран перепроверяется сам, шаг
   `accounts` зеленеет.
5. Ошибка или таймаут → `bootNote` с причиной, кнопка снова активна.

Было сломано: шаг 3 отсутствовал, поэтому окно висело, а гейт продолжал
показывать «не вошёл». В логе `desktop-21.log` нажатие и `window.show` есть, а
`/api/login/poll` — ни одного за 72 секунды.

### Кнопка «Sign in» в панели аккаунта

`startLogin()` в app.js — тот же цикл опроса, но с обновлением чатов, моделей,
прав и панели воркспейса после успеха. Это исходный, «правильный» путь; гейт
теперь повторяет его логику.

### Вход по cookie (кнопка «Use cookies»)

`API.loginCookie(cookie)` → `POST /api/login {method: 'manual', cookie}` →
`_activate_cookie()` → 200 при успехе, 401 при отказе с текстом причины.

### Выход

`API.logout()` → `POST /api/logout` → снимает текущий аккаунт из стора; cookie
из окна движка удаляются через `ENGINE.logout()`.

### Аккаунты (мультиаккаунт)

`/api/accounts`, `/api/accounts/add`, `/api/accounts/switch`, `/api/accounts/remove`,
`/api/account-sessions`. Хранилище — в `_accounts_load/_accounts_save`, cookie
каждого аккаунта защищены DPAPI. Переключение меняет `Client` целиком, включая
модели и права.

---

## 7. Авторизация Google — все кнопки и пути

### Зачем отдельный аккаунт

Google AI mode — второй «трек» приложения: ответы Google читаются страницей
google.com. Это **другой** аккаунт, никак не связанный с arena.ai. Вход в Google
не проходит шаг `accounts` гейта и не должен: это разные сервисы.

### Окно

Третье окно pywebview (`Google AI mode`), скрытое, `about:blank`, пока не
понадобится. Драйвер — `GoogleEngine` в `arena/google_ai.py`,
в веб-слой прокинут как `web_app.GOOGLE_ENGINE` (ставится в `desktop.py`).
Вне EXE `GOOGLE_ENGINE is None` → все Google-эндпоинты отвечают 400
«The Google window is part of Arena-Desktop.exe».

### Эндпоинты

| Маршрут | Что делает |
|---|---|
| `POST /api/google/sign-in` | `open_sign_in(fresh)` + `watch_sign_in()`; возвращает `{ok, pending, window: cookie_probe()}` |
| `POST /api/google/open` | показать окно / открыть URL / меню аккаунта / скрыть |
| `GET /api/google/status` | состояние окна |
| `GET /api/google/account` | кто вошёл + список аккаунтов |
| `POST /api/google/accounts/cookies` | добавить аккаунт из вставленной cookie (только после проверки Google) |
| `POST /api/google/accounts/use` | переключить аккаунт |
| `POST /api/google/accounts/remove` | удалить аккаунт |
| `GET /api/google/threads` | список тредов AI mode |
| `POST /api/google/thread/read` | прочитать тред |
| `POST /api/google/import` | импорт тредов в локальные чаты |
| `GET /api/google/prefs` / `POST` | настройки Google-трека |

### `open_sign_in(fresh)`

```
если окно уже открыто и fresh=True → НЕ чистим jar, только ensure_visible()   ← исправлено
иначе:
    fresh=True → clear_cookies(): DeleteAllCookies через CookieManager + clear_storage
    load("https://www.google.com/?authuser=0&hl=ru")
    ensure_visible()   ← окно показывается ДО любого чтения jar
```

Почему так: скрытый WebView2 не выполняет задачи, которые ему ставят — его
renderer заморожен. Чтение cookie из скрытого окна не «пустое», оно **висит**.

### Как определяется «вошёл»

```
account()
  → script_result(ACCOUNT_JS)      разбор страницы: ссылка SignOutOptions / EditUserOptions
  → если не распознано: jar_signed_in()
        → _cookies_direct("https://www.google.com/")
              → cookies_readable()?          ← окно должно быть на экране
              → _on_ui(start)                GetCookiesAsync на UI-потоке
              → ожидание задачи               (см. ниже)
              → повтор, если пришёл пустой список
              → _flatten_cookies_on_ui()     COM-объекты → простые кортежи
        → есть ли SID / __Secure-1PSID / __Secure-3PSID / SAPISID
  → если signed, а email пуст: _email_via_http()   HTTPS-запрос к Google
```

### Наблюдение `watch_sign_in`

Поток `google-signin-watch` раз в 0.6 с вызывает `account()`; при
`signed_in=True` вызывает колбэк `_google_on_signed_in` (сохраняет аккаунт и
закрывает окно) и выходит. Таймаут — 900 с (15 минут), после чего поток просто
завершается, ничего не сообщая.

### Три причины, по которым чтение jar могло не работать

Раньше в логах непрерывно шло `[google-cookies] task did not complete in time`.
Три разных отказа давали одинаковую картину; все три адресованы:

| | Причина | Что сделано |
|---|---|---|
| (а) | задача не завершается (UI занят / окно спящее) | скрытое окно вообще не опрашивается (`cookies_readable`), а при таймауте пишется полный снимок задачи и окна |
| (б) | задача завершилась с исключением при чтении `Result` | исключение логируется один раз, а не проглатывается |
| (в) | задача «завершилась» пустым списком, пока jar ещё не наполнен | пустой список от завершённой задачи считается неответом и читается повторно |

Плюс диагностика `cookie_probe()`: `window`, `visible`, `shown_once`, `ready`,
`host`, `quiet_until`, `show_failed` — отдаётся и в `/api/google/sign-in`.

### Кнопка «Sign in to Google» на гейте

1. `POST /api/google/sign-in {fresh: true}`.
2. Тост «Finish signing in inside the Google window. It closes by itself when done.»
3. Под шагом — `bootNote`: Google-вход живёт в своём окне, экран следит за
   аккаунтом Arena, а не Google.
4. Гейт **не перезапускается** — иначе экран мигал и выглядел как перезагрузка.

### Google по HTTPS (без окна)

`arena/google_http.py` — тот же AI mode, но чистыми HTTP-запросами с cookie из
окна. Быстрее и не требует показа окна; используется для отправки и истории,
окно нужно только для входа и человеческих проверок.

---

## 8. Чаты и история

| Маршрут | Назначение |
|---|---|
| `POST /api/chat` | отправить сообщение (основной путь) |
| `GET/POST /api/chats` | список / создать |
| `GET /api/chats/<id>` | прочитать чат |
| `DELETE /api/chats/<id>/delete` | удалить |
| `POST /api/chats/<id>/fork` | ветка от сообщения |
| `POST /api/chats/<id>/vote` | голос в battle |
| `POST /api/chats/<id>/compact` | сжать контекст |
| `GET /api/chats/<id>/export.md` / `.html` | экспорт |
| `GET /api/search` | поиск по истории |
| `POST /api/new` | новый чат |
| `POST /api/stop` | остановить генерацию |
| `GET /api/arena-chats` | облачные чаты аккаунта arena.ai |
| `POST /api/arena-chats/<eval_id>/open` | открыть облачный чат |
| `POST /api/arena-chats/<session_id>/archive` | архивировать |

Локальные чаты хранятся в `~/.arena-personal/` (или в `./data` в портативном
режиме, если рядом с EXE лежит `portable.txt` — см. `config._config_dir()`).
`history_sync.py` умеет импортировать облачную историю в локальный формат.

---

## 9. Файлы, воркспейс, терминал, гит

| Маршрут | Назначение |
|---|---|
| `/api/files`, `/api/files/read`, `/api/files/write`, `/api/files/delete`, `/api/files/mkdir` | файловый менеджер |
| `/api/workspace`, `/api/workspace/tree`, `/api/workspace/file`, `/api/workspace/save` | воркспейс проекта |
| `/api/workspace/open`, `/api/workspace/set` | выбрать папку |
| `/api/workspace/snapshot`, `/api/workspace/zip`, `/api/workspace/download` | снимок и выгрузка |
| `/api/workspace/preview/<path>` | просмотр файла |
| `/api/workspace/git/status|diff|stage|unstage|commit` | панель git |
| `/api/terminal` | терминал |
| `/api/uploads` | загрузка вложений |
| `/api/media/save`, `/api/media-choices` | сохранение сгенерированных файлов |

Воркспейс (`arena/workspace.py`) — папка на диске, к которой агент имеет доступ.
Терминал и файловые операции подчиняются `permissions.py`.

---

## 10. Агент, инструменты, разрешения

| Файл | Что делает |
|---|---|
| `arena/agent.py` | инструменты, которые модель вызывает: чтение/запись файлов, запуск команд |
| `arena/native_agent.py` | протокол Native Arena Agent через прокси Arena |
| `arena/tools/file_tools.py` | файловые инструменты |
| `arena/tools/shell_tools.py` | запуск команд с таймаутом и убийством по простою |
| `arena/tools/mcp.py`, `browser_mcp.py` | инструменты через MCP |
| `arena/permissions.py` | режимы: как в Claude Code — спрашивать / разрешать / запрещать |

Маршруты: `POST /api/agent/native`, `/api/permissions`, `/api/permission-mode`,
`/api/questions`, `/api/components*`, `/api/checkpoints/<cid>/restore`.

**Режимы разрешений** важны для понимания «почему агент не выполнил команду»:
в строгом режиме каждое действие требует подтверждения через `/api/permissions`
и `/api/questions`; отказ возвращается модели как результат инструмента, а не
как ошибка приложения.

---

## 11. MCP-коннекторы и шлюз

* `arena/connectors.py` — конфигурация и рантайм MCP-серверов.
  Маршруты: `/api/connectors`, `/api/connectors/<name>/connect|disconnect|test|
  enabled|delete`, `/api/connectors/reload`, `/api/connectors/preset`,
  `/api/connectors/cli`.
* `arena/gateway.py` — «Agent Gateway»: даёт настоящему Arena Agent вызывать
  выбранные локальные MCP-серверы через временный туннель Cloudflare Quick
  Tunnel. Свойства: bearer-код парности (`secrets.token_urlsafe(32)`,
  сравнение в постоянном времени), жёсткий срок жизни и авто-стоп по простою,
  подтверждения через `PermissionBroker`, последовательное выполнение задач.
  Наружу не слушает ничего, кроме loopback; `Stop` убирает токен, туннель и
  сервер вместе. Маршруты: `/api/gateway`, `/api/gateway/start`,
  `/api/gateway/stop`.
* `arena/components.py` — необязательные внешние компоненты: обнаружение и
  установка. Маршруты `/api/components`, `/api/components/install`.

---

## 12. Автоматизации, память, настройки

| Маршрут | Назначение |
|---|---|
| `/api/automations` (+ `<aid>`, `/run`) | запланированные запуски агента |
| `/api/memory` (GET/POST) | долговременная память |
| `/api/settings` (GET/POST) | настройки, отдельно для каждого трека |
| `/api/settings/export`, `/api/settings/import` | перенос настроек |
| `/api/models` | каталог моделей (анонимно 403) |
| `/api/mode`, `/api/modality` | переключение режима и модальности |
| `/api/usage` | расход |
| `/api/elo` | рейтинг моделей |
| `/api/update-check` | проверка обновлений |
| `/api/status` | сводка состояния: кто вошёл, что открыто, что включено |

Настройки скоупятся по треку (`settingsQuery()` в app.js): пока открыто окно
настроек, переключатель трека решает, к какому из двух миров относится запрос.

---

## 13. Диагностика и логи

`arena/diag.py` пишет в `~/.arena-personal/desktop.log` (и `desktop-crash-*.log`
при аварии).

| Строка | Что значит |
|---|---|
| `[ui] <t> click «label»` | нажатие кнопки |
| `[ui] <t> request METHOD /path` | запрос из интерфейса |
| `[ui] <t> response ... 200 87ms` | ответ |
| `-> имя` / `<- имя 12ms` | вход/выход в медленный вызов, видно, где время |
| `[diag <t>s]` | секунд с запуска |
| `[heartbeat] потоков=N, вызовов в работе=...` | раз в 10 с; растущее «в работе» = залипание |
| `[google-cookies] ...` | всё про cookie jar Google |
| `[google-window] ...` | жизненный цикл окна Google |
| дампы стеков всех потоков | `diag.dump_threads` |

Признак зависания: `MainThread` в `winforms.py create_window`, остальные в
`select`/`loop` — процесс жив, но ждёт. Именно это видно в `desktop-trace.log` и
`desktop-crash-5.log`.

Что теперь логируется по Google (добавлено специально, чтобы не угадывать):

* `[google-cookies] reading is paused: … visible=… shown_once=… host=…` —
  окно не на экране, читать нечего и не нужно;
* `[google-cookies] task did not complete in time | type=… has_is_completed=…
  status=… result_error=… window=… visible=… shown_once=… ready=…
  show_failed=… host=… url=…` — полный снимок;
* `[google-cookies] task completed but its Result threw …` — версия (б);
* `[google-cookies] first read returned an empty list; retrying once` — версия (в);
* `[google-cookies] the UI thread did not answer in N s` — UI занят.

---

## 14. Сборка EXE

Полная сборка (`tools/build_exe.sh`) занимает ~63 с, из которых 55 с —
PyInstaller Analysis (обход графа импортов 1466 модулей). Кеш Analysis под wine
нечитаем (`marshal.load` → `MemoryError`), поэтому он каждый раз с нуля.

Быстрая сборка (`tools/build_fast.sh`) — **12 секунд**:

1. `tools/rebuild_pyz_full.py` под **CPython 3.12** (обязательно: байткод
   версионно-залочен, бандл собран под 3.12; `uv python install 3.12`)
   перекомпилирует **все 1460 модулей** из исходников и собирает `PYZ.pyz`
   с нуля — проект, stdlib и сторонние пакеты из venv 3.12.
2. `tools/fast_rebuild.py` переписывает внешний архив вокруг существующего
   bootloader, подменяя data-файлы (`app.js`, `style.css`, …) и используя новый
   PYZ из `tools/pyz_fresh.bin`.
3. Проверка: **каждый** модуль внутри готового EXE распаковывается и
   разбирается `marshal`, плюс ищутся маркеры изменений.

Этот третий шаг появился не просто так: до него готовый архив был корректным по
формату, но содержал старый Python-код, потому что PYZ копировался из эталона
как есть. Размер и читаемость при этом сходились, и ошибка была невидимой.

### Почему первые проверки не поймали второй крэш

Первый набор тестов повторял логику импортёра **у себя**, а не брал её из
сборки. Именно поэтому он и позеленел на сломанном EXE: и тест, и импортёр
искали запись по последнему сегменту имени — но импортёр делает это только
внутри `sys._MEIPASS`, а для вложенного пакета строит имя с префиксом пути
поиска. `flask` добавляет в `__path__` каталог `<_MEIPASS>/flask`, и оттуда
`flask.sansio` превращается в запись `flask.sansio`, а не `sansio`.

Отсюда правило, которое теперь соблюдается буквально: **проверка должна
исполнять тот же код, что и в бою**. `tests/test_bundle_integrity.py`
распаковывает из EXE настоящие `pyimod01_archive` и `pyimod02_importers`,
вызывает их `install()` и подменяет только источник архива (распакованный
файл вместо смещения внутри `.exe`). Всё остальное — хуки путей, префиксы,
typecodes, `__path__` — подлинное.

Второй провал был в классификации: настоящая ошибка `flask.app →
flask.sansio` попадала в категорию «нет внешней зависимости» и не считалась
ошибкой. Теперь правило жёсткое: если у отсутствующего имени в архиве есть
дочерние модули, это пакет, и его отсутствие — провал.

### Namespace-пакеты: второй способ убить сборку

`flask.sansio` — пакет **без `__init__.py`** (PEP 420). У него нет файла,
значит его легко потерять: нечего копировать. И его нет в TOC как обычный
модуль — импортёр PyInstaller ищет запись по **последнему сегменту** имени
(`_compute_pyz_entry_name` → `fullname.rpartition('.')[2]`), то есть для
`flask.sansio` ему нужна запись `sansio` с typecode **3**. Без неё родитель не
резолвится, и приложение падает на импорте с `No module named 'flask.sansio'`,
хотя `flask.sansio.app` в архиве есть.

Поэтому `rebuild_pyz_full.py` после сборки проходит по всем именам, находит
отсутствующих родителей и **синтезирует** для них записи typecode 3 с пустым
телом. Сейчас так добавляется 5 пакетов (`flask.sansio`,
`setuptools._distutils.compilers`, `...compilers.C`, `setuptools._vendor`,
`setuptools._vendor.jaraco`).

Правило, которое из этого следует и которое теперь проверяется автоматически:
**если в TOC нельзя молча выбросить модуль, то и сборка не имеет права
продолжаться, когда чего-то не хватает.** `rebuild_pyz_full.py` падает, если
хотя бы один перечисленный модуль не удалось восстановить.

### Тест, который действительно ловит такие поломки

`tests/test_bundle_integrity.py` — не смотрит на структуру архива, а
**импортирует** его содержимое по-настоящему:

* распаковывает PYZ из готового EXE,
* поднимает CPython 3.12 и подключает в `sys.meta_path` свой finder, как это
  делает `pyimod02_importers`,
* обходит **каждый** модуль из TOC и пытается его исполнить,
* отдельно проверяет, что у каждого родительского пакета есть запись.

Разница принципиальная: сломанная сборка проходила любые проверки структуры
(архив открывается, число записей верное, маркеры на месте) и падала при
запуске. Поймать отсутствующий модуль можно только импортом.

Модули, которым нужны скомпилированные расширения, Windows-only рантайм или
сеть, проверяются на **наличие** и на то, что их код компилируется — запускать
их вне EXE нельзя, и тест это честно разделяет.

`tools/build_fast.sh` **не завершится успешно**, если этот тест не прошёл.

### Окно входа в Google не открывалось

Cообщено после запуска: «окно не открывается у входа гугла». Причина найдена в
порядке вызовов, а не в окне.

pywebview 6 оборачивает `load_url` (а также `hide`, `resize`, `move`) в
декоратор `@_shown_call`: он **сначала ждёт 20 секунд события `shown`** и
только потом делает дело, а не дождавшись — бросает `WebViewException("Main
window failed to start")`. Окно Google создаётся с `hidden=True`, а такой
window в winforms создаётся как `Show(); Hide()` — то есть на момент входа
оно ни разу не было на экране.

`open_sign_in` сначала вызывал `load()`, и только потом `ensure_visible()`.
Порядок и был багом: загрузка тратила свои 20 секунд на событие, которого ещё
не могло быть, навигация выбрасывалась, а окно так и не появлялось. В логе это
видно дословно: `show: shown event reported=False` и
`show() returned but the window never reported 'shown'`.

Исправлено в двух местах:

* `open_sign_in` показывает окно **до** навигации;
* если `load_url` всё же отказал (окно не дошло до экрана), навигация идёт
  прямо в WebView2 через UI-поток — `_navigate_direct`. Иначе окно, потерявшее
  первый `shown`, теряло бы и все последующие загрузки.

Тесты: `test_sign_in_cannot_touch_the_window_before_showing_it` падает на
старом коде с `['load_url', 'show']` и проходит после правки.

### Запуск, а не только импорт

Импорт всех модулей всё ещё не значит «приложение работает»: лаунчер может
упасть в GUI-слое, маршрут может бросать исключение, статики может не быть.
Поэтому `tools/smoke_wine.py` **запускает готовый EXE** под Wine и
разговаривает с ним по HTTP: страница, токен, `app.js`/`style.css`, эндпоинты
`/api/accounts`, `/api/chats`, `/api/models`, отказ без токена, живой процесс.

Wine — не Windows, и это честно оговорено: окно открыть нельзя (в Wine Mono
нет `System.Windows.Forms`), поэтому проверяется всё **до** окна и включая
таблицу маршрутов. Именно этот участок и падал дважды.

`build_fast.sh` не завершится успешно ни без импорт-теста, ни без живого
запуска. Если Wine не установлен — сборка **падает**, а не пропускает шаг.

### Формат архива (то, на чём легко попасться)

* `archive_length` в cookie **включает** сам cookie;
* `entry_length` в TOC **включает** паддинг до 16 байт;
* поля записи: `(entry_length, entry_offset, length, uncompressed_length,
  compression_flag, typecode)`;
* `pyvers` = **312**, не 3;
* PYZ лежит в TOC как обычная запись с typecode `z` — второй `append` даёт
  лишние ~9.8 МБ;
* в PYZ: смещение TOC **абсолютное** от начала файла, смещения записей тоже
  абсолютные (первая = 17), формат записи `(name, (typecode, offset, length))`.

---

## 15. Полный список известных дефектов

| # | Дефект | Где | Статус |
|---|---|---|---|
| 1 | «Sign in to Arena» открывал окно и на этом останавливался | гейт не опрашивал `/api/login/poll` | **исправлено**, тест `test_arena_sign_in_waits_for_the_session` |
| 2 | Чтение jar из скрытого окна висело | `_cookies_direct` | **исправлено**: скрытое окно не опрашивается |
| 3 | Исключение при чтении `task.Result` проглатывалось | `_await_task` | **исправлено**: логируется |
| 4 | Пустой список от завершённой задачи считался ответом | `_cookies_direct` | **исправлено**: повтор |
| 5 | Повторное нажатие Google сбрасывало начатый вход | `open_sign_in(fresh=True)` | **исправлено** |
| 6 | «Sign in to Google» перезапускал гейт и мигал | `bootAddActions` | **исправлено** |
| 7 | Правки Python не попадали в EXE | `fast_rebuild` копировал PYZ | **исправлено**: `rebuild_pyz_full.py` + полная проверка |
| 7a | Падение при старте: `incorrect header check` | незатронутые блобы копировались со сдвигом 17 байт | **исправлено**: PYZ собирается с нуля, каждый блоб проверяется |
| 7b | Падение при старте: `No module named 'flask.sansio'` | namespace-пакет без `__init__.py` выпал из архива | **исправлено**: записи typecode 3 синтезируются под полным именем |
| 7c | То же после «исправления» | тест повторял логику импортёра у себя и соглашался с ошибкой | **исправлено**: тест грузит подлинный `pyimod02_importers` из EXE |
| 7d | Сборки не проверялись запуском | импорт ≠ старт | **исправлено**: `smoke_wine.py` запускает EXE и опрашивает HTTP |
| 7e | Окно входа в Google не открывается | `load_url` вызывался до `show()`; pywebview ждёт `shown` 20 с и бросает | **исправлено**: сначала показ, затем загрузка + обход через WebView2 |
| 8 | `watch_sign_in` по таймауту 15 минут молчит | `google_ai.py` | **открыт**: нужен текст ошибки человеку |
| 9 | Тост «Sign in inside the window» двусмысленный | `bootAddActions` | **исправлено** текстом |
| 10 | `models` анонимно 403 и попадает в отказ гейта | `_check_models` | по замыслу: `needs_account: True` |
| 11 | 3 теста падают из-за отсутствия `/home/user/.cargo/env` | `test_core.py`, `test_tools.py` | среда, не приложение |

---

## 16. Шпаргалка

* **Войти в Arena:** кнопка открывает окно; вход делает человек в окне; поллинг
  замечает сессию и закрывает окно.
* **Войти в Google:** другой аккаунт, на гейт не влияет; успех — cookie
  `SID`/`__Secure-1PSID` или ссылка `SignOutOptions` на странице.
* **Окно Arena не открывается** → `_engine_on()` = False (веб-режим), ответ 400.
* **Окно Google не открывается** → `GOOGLE_ENGINE is None`, тот же случай.
* **Вход по cookie** → нужен префикс `arena-auth-prod-v1`, иначе 400.
* **Гейт не пускает** → `GET /api/readiness?check=accounts` с `X-Arena-Token`;
  ложный отказ при рабочем входе — баг.
* **Собрать за 5 секунд** → `bash tools/build_fast.sh`; он же проверяет, что
  правки реально внутри EXE.
