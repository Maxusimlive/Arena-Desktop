# Arena Desktop — проектная документация

## 1. Что это за проект

**Arena Desktop** — это локальное десктопное приложение (Windows-клиент) для работы с платформой arena.ai. Оно представляет собой оболочку вокруг веб-интерфейса arena.ai, запущенную встроенным браузером (WebView2 на базе Edge), с локальным Python-бэкендом (Flask), который управляет сессиями, куками, браузерными окнами и коммуникацией между веб-интерфейсом и операционной системой.

Приложение позволяет:
- Войти в arena.ai через отдельное окно браузера (Google sign-in или cookies)
- Работать с чатами, подключениями (connectors), настройками
- Использовать Google AI mode и Arena mode
- Управлять сохранёнными аккаунтами и сессиями

### Стек технологий

| Слой | Технология |
|------|------------|
| Оболочка окна | pywebview (WebView2, Edge) |
| Локальный сервер | Flask (Python 3.12) |
| Фронт-энд | Vanilla JS + HTML/CSS (одностраничное приложение) |
| Сборка | PyInstaller → один EXE-файл (~23 МБ) |
| Язык интерфейса | Русский / английский |

---

## 2. Архитектура приложения

```
Arena-Desktop.exe
├── Bootloader (PyInstaller)
│   ├── PYZ archive (скомпилированные .pyc модули)
│   └── Data files (arena/web/static/*)
│       ├── app.js      — контроллер интерфейса
│       ├── style.css   — стили
│       └── index.html  — разметка
│
└── Python runtime (внутри PYZ)
    ├── arena/web/app.py          — Flask-сервер, API-роуты, Google-сессии
    ├── arena/google_ai.py        — управление браузерным окном Google, куки
    ├── arena/browserwindow.py    — управление вкладками/окнами браузера
    ├── arena/engine.py           — движок браузера (WebView2)
    ├── arena/ephemeral.py        — одноразовые окна входа
    ├── arena/lazywindow.py       — отложенное создание окон
    ├── arena/diag.py             — диагностика и логирование вызовов
    └── ...
```

### Как запускается приложение

1. `arena-cli.py` — точка входа, регистрирует протокол `arenadesktop://` для текущего пользователя Windows.
2. Запускается встроенный Flask-сервер на локальном порту.
3. Создаётся главное окно через WebView2, загружает `index.html`.
4. JS-контроллер (`app.js`) инициирует загрузку статуса, проверяет сессию, отрисовывает интерфейс.

---

## 3. Как работает Google sign-in (основной фокус разработки)

Это самая сложная часть приложения, потому что требует взаимодействия между Python-бэкендом, WebView2-окном браузера и Google-аккаунтом пользователя.

### Пошаговый поток входа

```
Пользователь нажимает «Sign in to Google»
        │
        ▼
1. JS вызывает API.googleSignIn() → POST /api/google/sign-in
        │
        ▼
2. Python: engine.open_sign_in(fresh=True)
   — открывает отдельное окно браузера (WebView2)
   — окно загружает страницу входа Google
        │
        ▼
3. Пользователь вводит логин/пароль в окне Google
   — окно закрывается самим сервером после успешного входа
        │
        ▼
4. Python: engine.watch_sign_in(_google_on_signed_in)
   — считывает куки из окна браузера (через WebView2 CookieManager)
   — сохраняет аккаунт с куками в локальном хранилище (google_accounts.json)
   — закрывает окно входа
        │
        ▼
5. JS: watchGoogleSignIn() опрашивает GET /api/google/status
   — когда приходит signed_in: true — зажигает галочку ✓ на кнопке
   — блокирует кнопку (disabled)
   — обновляет состояние соединения в Арене
```

### Проблемы, которые решались

| Проблема | Причина | Решение |
|----------|---------|---------|
| Процесс замерзал при чтении кук | `engine.cookies()` вызывает COM/DCOM вызов на UI-потоке WebView2, удерживая GIL | Чтение кук вынесено в отдельный поток с таймаутом 2.5 с |
| Галочка появлялась сразу, без входа | `/api/google/status` возвращал `signed_in: true` по наличию сохранённых кук | Fallback теперь возвращает `signed_in: false`, живое подтверждение только от сервера |
| Кнопка не блокировалась после входа | В JS не было обработки состояния `googleSignedIn()` | Добавлен класс `is-signed-in`, `disabled=true`, галочка ✓ |
| Состояние в Арене не менялось | После входа не обновлялось соединение | Добавлен вызов `updateConnectionUI()` после sign-in |

---

## 4. Ключевые компоненты

### arena/web/app.py (~11 500 строк)
Основной Flask-сервер. Содержит:
- API-роуты: `/api/google/sign-in`, `/api/google/status`, `/api/google/verify`, `/api/chat`, `/api/settings` и др.
- Управление Google-аккаунтами: `_google_store_account()`, `_google_on_signed_in()`, `_google_current_cookie()`
- Диагностика окон: `_google_window_diagnosis()`
- Безопасные обёртки над блокирующими вызовами: `_google_call_bounded()`

### arena/web/static/app.js (~14 600 строк)
JS-контроллер интерфейса. Содержит:
- `googleSignIn()`, `watchGoogleSignIn()`, `checkGoogleSignIn()` — управление входом Google
- `updateAccountUI()` — отрисовка состояния аккаунта (кнопка, галочка, текст)
- `googleIdentity()`, `googleSignedIn()` — проверка состояния сессии
- `API` объект — обёртка над fetch-запросами к Flask

### arena/google_ai.py (~8 700 строк)
Управление браузерным окном Google. Содержит:
- `_cookies_direct()` — чтение кук через WebView2 CookieManager (было место замерзания процесса)
- `open_sign_in()`, `watch_sign_in()` — открытие и мониторинг окна входа
- `clear_cookies()`, `hide()`, `show()` — управление окном

### arena/browserwindow.py
Управление вкладками браузера. Ключевое исправление round 13: `page_tab` теперь сравнивает URL через `_domain_matches(_host_of(url), domains)` вместо прямого сравнения строк.

### arena/ephemeral.py
Одноразовые окна входа. После использования профиль удаляется, следующий sign-in начинается с чистого листа.

---

## 5. Процесс сборки

### Сборка EXE (быстрая, ~15 секунд)

```bash
cd /home/user/Arena-Desktop
bash tools/build_fast.sh
```

Этапы:
1. **rebuild_pyz_full.py** — перекомпилирует все 1476 Python-модулей в PYZ-архив (требуется CPython 3.12)
2. **fast_rebuild.py** — переписывает внешний архив EXE, обновляя статические файлы (app.js, style.css, index.html)
3. Проверка маркеров в бандле (что изменения действительно попали в EXE)
4. Smoke-тест под Wine (запуск EXE, проверка HTTP-роутов)

### Результат
- `/home/user/Arena-Desktop/releases/Arena-Desktop.exe` — единственный файл для распространения
- Размер: ~23 МБ
- Все зависимости встроены (Python, Flask, WebView2 runtime не требуется отдельно)

---

## 6. История изменений (круги разработки)

| Круг | Что сделано | Статус |
|------|-------------|--------|
| Round 10 | Исправлен повторный sign-in, закрытие окон | ✅ Завершён |
| Round 11 | Исправлены дубли вкладок, тихий отказ входа | ✅ Завершён |
| Round 12 | Исправлен тихий отказ входа, 662 теста | ✅ Завершён |
| Round 13 | Исправлен вход после одной кнопки, page_tab, POLL_TICK | ✅ Завершён |
| Round 14 | UX кнопки Google sign-in (зелёный + ✓), защита от зависания процесса | ✅ Завершён |

---

## 7. Система тестирования

Все тесты в `/home/user/Arena-Desktop/tests/`:

```
670 passed, 29 skipped, 0 failures (после round 14)
```

### Преду-existing неисправности (не касаются round 14)
- `test_shell_refusal_and_idle_kill` — POSIX-окружение (`sh -l` vs `source` в `/etc/profile`), не относится к Windows
- `test_cache_button.py::test_the_button_reports_what_it_cleared` — ищет несуществующую функцию `cacheResultText`
- Несколько тестов `test_cache_button.py` — ищут устаревшую верстку кэш-кнопки

---

## 8. Файлы проекта

| Файл | Описание |
|------|----------|
| `Arena-Desktop.exe` | Готовый Windows-клиент (~23 МБ) |
| `Arena-Desktop-code.pdf` | Полный исходный код в PDF (823 стр.) |
| `TASK-ROUND14.md` | Техническое задание round 14 |
| `HANDOFF-ROUND14.md` | Передача проекта round 14 |
| `GEMINI-ROUND13-REVIEW.md` | Ревью предыдущего раунда |
| `arena/web/app.py` | Flask-бэкенд (~11 500 строк) |
| `arena/web/static/app.js` | JS-контроллер (~14 600 строк) |
| `arena/web/static/style.css` | Стили |
| `arena/web/static/index.html` | Разметка |
| `arena/google_ai.py` | Управление окном Google |
| `tests/` | Тесты (670+ тестов) |

---

## 9. Как вносить изменения

1. Править исходники в `arena/web/` (Python) и `arena/web/static/` (JS/CSS/HTML)
2. Пересобирать EXE: `bash tools/build_fast.sh`
3. Прогонять тесты: `pytest tests/`
4. Проверять, что изменения попали в EXE (распаковкой архива или через маркеры в build_fast.sh)

---

## 10. Ограничения

- Приложение только для Windows (WebView2)
- Требуется локальный запуск (Flask сервер на localhost)
- Google sign-in требует подключения к интернету
- Некоторые функции требуют arena.ai аккаунта
