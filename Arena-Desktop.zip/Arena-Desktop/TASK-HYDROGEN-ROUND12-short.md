Проект: Arena-Desktop (Python + Chromium через DevTools). Исходники — в PDF/архиве, который прилагаю.

ЖАЛОБА: одно нажатие «Войти» открывает 2–3 страницы; сам вход не засчитывается.
Это два разных дефекта, ищи их отдельно.

Всё ниже я проверил запуском. Если не согласен — скажи, какой факт неверен и чем проверил.

== 1. ЛИШНИЕ СТРАНИЦЫ ==

Факт 1. arena/ephemeral.py:109 — защита от повторной загрузки НЕ СРАБАТЫВАЕТ НИКОГДА:

  starting = getattr(self._window, "open_url_on_start", None)
  if starting and starting == str(url or "").strip():
      return True

Сравнение строк не совпадает в обоих окнах:
- Arena: на командной строке "https://arena.ai/", движок просит "https://arena.ai" (contracts.py:17 ORIGIN, без косой черты).
- Google: "https://www.google.com/" против "https://www.google.com/?authuser=0&hl=ru" (open_sign_in).
Проверено в REPL: оба сравнения False.

Значит после старта всегда уходит вторая навигация. Дальше browserwindow.py:787 load_url: если вкладки ещё нет в /json → _open_tab(url) → PUT /json/new?url → НОВАЯ ВКЛАДКА.

Факт 2. browserwindow.py:829 _open_tab: докстрока «create the window's one page, when there is none yet», но проверки «нет ли уже страницы» в самом методе НЕТ — она у вызывающих, и load_url её не делает.

Факт 3. browserwindow.py:488 start(): второй процесс создаётся только когда _proc уже вышел, а поток запуска ещё жив (Edge, передавший команду запущенному экземпляру). Воспроизвёл: 2 процесса, 2 вкладки. При живом _proc защита держит (проверял).

Факт 4. browserwindow.py:895 show() = start(). «Показать окно» и «создать окно» — одна операция; движок зовёт show() в _present() на каждый open_login/open_path/cloudflare. Для одноразового окна это новый профиль и новая вкладка.

Скажи: какая из четырёх причин даёт именно 2–3, и откуда третья.

== 2. ВХОД НЕ ЗАСЧИТЫВАЕТСЯ ==

Факт 5. engine.py:1082 open_login() ведёт на contracts.ORIGIN (главная arena.ai). grep "accounts.google.com" arena/engine.py → НИЧЕГО: страницы входа Google в коде нет. Человек жмёт «Войти» и попадает на главную.
Проверь по archive/Arena-Desktop-original, какая функция вела на accounts.google.com раньше и что её заменило.

Факт 6. engine.py:1652 get_me(): подтверждение входа = request() (engine.py:1245), то есть fetch ВНУТРИ страницы arena.ai. Помешал Cloudflare/навигация — «Signed in as a guest only». Какие запасные признаки входа есть (cookie_tuples, AUTH_COOKIE_PREFIX, cookie_str клиента) и почему ни один не используется?

Факт 7. Окно Arena — транспорт всех запросов; закрывать его после входа НЕЛЬЗЯ (HANDOFF). Найди места, где close_and_forget/close_sign_in_window зовут для arena-окна.

== 3. САМ ==

Найди другое, дающее те же симптомы:
- try/except, оставляющий состояние «наполовину сделанным» (окно есть, навигации нет; вкладка есть, движок смотрит в другую);
- расхождение @property / def: ephemeral.py:147 host — СВОЙСТВО (возвращает строку), browserwindow.py:931 host — МЕТОД. Есть ли место, где .host зовут как метод (TypeError внутри try/except = «ничего не происходит»)?
- второе нажатие «Войти», пока первое окно открывается.

== ЗАПРЕТЫ ==
1. Никакого --incognito (даёт пустую банку после входа).
2. Окно Arena не закрывать после входа.
3. Не менять политику «нечитаемый браузер закрываем, пробуем следующий» (tests/test_browser_profile_reuse.py).
4. Не трогать LazyWindow.is_browser: это ломает старт окна (test_the_engine_stops_believing_in_a_closed_window).
5. Не переписывать слой окон заново.

== ОТВЕТ ==
По каждому дефекту: причина (файл:строка, пошагово) → diff → какой тест закрепит. Затем «найдено самостоятельно» списком и «чего не проверял».
