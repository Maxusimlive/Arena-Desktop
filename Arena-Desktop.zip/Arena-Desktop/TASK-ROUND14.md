# TASK-ROUND14: UX кнопки Google sign-in — состояние «done» после успешного входа + фикс зависания `_google_current_cookie` + визуальный баг текста

## Проблема (confirmed by desktop-26.log, desktop-crash-10.log, screenshot image-2.png)

После успешного Google sign-in (пользователь вошёл в аккаунт Google в отдельном окне, окно закрылось само):

1. Кнопка входа (`#accountButton` в топбаре) остаётся активной, не становится «недоступной / зелёной с галочкой». Только белая галочка слева, без зелёного фона.
2. В самой Арене после входа ничего не меняется: нет смены состояния, нет обновления сессии.
3. Текст «Google sign-in stays open in its own window...» в boot-шаге съехал по буквам (каждая буква на новой строке).
4. Если при загрузке приложения есть сохранённые аккаунты с куками, то при проверке «хоть один работает — заходит в приложение» (все аккаунты загораются как вошедшие, даже если только один валиден).
5. При истечении сессии кнопка не возвращается в обычное состояние.

Корневые причины (из логов и кода):

- **`_google_current_cookie()` в `app.py` зависает** на `engine.cookies(tries=1)` → `_cookies_from_edge()` → `_cookies_direct()` (чтение кук Edge через WebView2 на UI-потоке). Поток держит GIL в ожидании DCOM/COM. `desktop-crash-10.log`: `_cookies_direct` → `_on_ui` → `winforms.py:808 create`.
- **`/api/google/status` возвращает fallback** `{"signed_in": False}` через `_google_call_bounded` (таймаут 2.5с), но зависший воркер держит GIL, так что endpoint не успевает ответить клиенту.
- **`googleSignedIn()` в `app.js` проверяет `g.account?.signed_in` без проверки наличия кук** — при загрузке приложения сохранённая запись из прошлой сессии зажигает галочку сразу, без живого подтверждения сервера.
- **`loadGoogleStatus()` в `app.js` не копирует `data.signed_in` в `state.google`** — серверный ответ `signed_in: true` не попадает в состояние, поэтому `watchGoogleSignIn()` никогда не видит подтверждение.
- **`.boot-step-note` в `style.css` не имеет `grid-column`** — текст попадает в неправильную ячейку CSS Grid и съезжает по буквам.

## Цель

После успешного Google sign-in:
- Кнопка `#accountButton` становится **недоступной (disabled)**, **горит зелёным**, показывает **галочку (✓)**.
- В Арене происходит **изменение состояния**: сессия обновляется, UI отражает «signed in».
- `/api/google/status` не заводится — чтение кук Edge имеет жёсткий таймаут 2.5 с.
- Текст boot-шага не съезжает.
- При загрузке загораются только аккаунты с живой сессией (куки + подтверждение сервера).

## Файлы для правки

### Бэкенд (`arena/web/app.py`)
- `_google_current_cookie()` (стр. ~8374) — обернуть `engine.cookies(tries=1)` в worker-поток с таймаутом 2.5с, чтобы зависшее чтение Edge не блокировало весь процесс.
- `api_google_status()` (стр. ~9314) — гарантировать возврат fallback с `signed_in: False` даже при зависшем `_google_live_account`. Добавить поля `diagnosis`, `signed_in`, `configured`, `has_cookie` в ответ.

### Фронт (`arena/web/static/app.js`)
- `googleIdentity()` (стр. ~3480) — проверять `signed_in`, `state.google.signed_in`, `acc.signed_in && state.google.has_cookie`.
- `watchGoogleSignIn()` (стр. ~3500) — добавить `verifyAttempted`, `sawWindowOpen`; при закрытии окна сервером (`diagnosis.state === "closed"`) или наличии кук делать `API.googleVerify()` для мгновенного перехода в `signed_in`; при successo сбрасывать `loginPending`, синхронизировать `state.google`, вызывать `refreshGoogleStatus()`, `refreshReadiness()`, `updateAccountUI()`, `updateConnectionUI()`.
- `googleSignIn()` (стр. ~3533) — ранний возврат если `googleSignedIn()` уже `true`.
- `updateAccountUI()` (стр. ~6718) — при `googleSignedIn()`: класс `is-signed-in`, `disabled=true`, `aria-disabled="true"`, скрывать поповер, показывать `#accountCheck`; при истечении — отменять.
- `googleSignedIn()` (стр. ~14207) — проверять `g.signed_in || (acc.signed_in && g.has_cookie)` с учётом `!expired`.
- `loadGoogleStatus()` (стр. ~3459) — копировать `signed_in: Boolean(data?.signed_in)` в `state.google`.
- `els.accountCheck = $('#accountCheck')`, `els.accountPopover = $('#accountPopover')` — добавить в инициализацию `els`.

### Статика
- `arena/web/static/style.css` — `.account-button.is-signed-in` (зелёный фон, обводка), `:disabled` (некликабельно), `.account-check` (галочка ✓), `.boot-step-note` (grid-column: 2 / -1, чтобы текст не съезжал).
- `arena/web/static/index.html` — `<span class="account-check" id="accountCheck" hidden>✓</span>` внутри `#accountButton`; `<div class="account-popover" id="accountPopover" hidden></div>` после кнопки.

## Критерии приёмки (жёсткие)

1. **Кнопка заблокирована после sign-in**: `googleSignedIn() === true` → `els.accountButton.disabled = true`, `aria-disabled="true"`, поповер скрыт.
2. **Зелёный цвет + галочка ✓**: класс `is-signed-in` на кнопке, `#accountCheck` видим, стили в `style.css`.
3. **Текст кнопки меняется**: при `g.signedIn` — email или «Google: signed in»; при `g.expired` — «Session expired».
4. **Состояние в Арене меняется**: после sign-in сбрасывается `loginPending`, вызываются `updateConnectionUI()`, `refreshGoogleStatus()`, `refreshReadiness()`.
5. **Кнопка снова активна при истечении**: `expired === true` → `disabled = false`, класс убран, `#accountCheck` скрыт, `.account-dot` → `is-warn`.
6. **`_google_current_cookie()` не заводит процесс**: чтение кук Edge обёрнуто в поток с таймаутом 2.5с; при завале возвращается `""`.
7. **Визуальный баг исправлен**: `.boot-step-note` имеет `grid-column: 2 / -1`, текст не съезжает по буквам.
8. **При загрузке загораются только живые аккаунты**: `googleSignedIn()` требует `g.signed_in` или `(acc.signed_in && g.has_cookie)` — сохранённая запись без кук не засчитывается.
9. **Нет регрессий**: `pytest tests/` проходит (кроме преду-existing POSIX и кеш-тестов).
10. **Сборка**: `tools/baseline.exe` = round-13 EXE, `fast_rebuild.sh` refresh'ит статику из исходников, изменения попадают в `Arena-Desktop.exe`.

## Что НЕ нужно делать

- Не менять `agent.py` (средовое падение `test_shell_refusal_and_idle_kill` — POSIX).
- Не использовать `Arena-Desktop-for-review.zip` как источник кода (устарела).
- Не ломать критерий приёмки round 13: вход после одной кнопки.

## Формат ответа Gemini

Присылай только диффы (`diff -u`) к перечисленным файлам. Каждый дифф с filepath в заголовке. После диффов — краткий список изменений и как они закрывают каждый критерий приёмки. Без общих рассуждений, без «возможно», без recomendations без кода. Если правка противоречит работе проекта (ломает существующий функционал или критерии приёмки) — укажите это явно перед диффом.
