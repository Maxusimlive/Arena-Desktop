"""
Arena Code CLI - Modular AI Coding Assistant
"""

__version__ = "1.0.0"

from . import diag  # noqa: F401  (diag is imported by app.py, desktop.py, engine.py)

