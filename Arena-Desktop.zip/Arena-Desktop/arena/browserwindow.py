"""The Google sign-in window, as a real browser instead of WebView2.

Why this exists
---------------
WebView2 inside this app has cost more than it ever returned: a message loop
that has to be obeyed from one thread, COM objects that only answer on the
thread that made them, tasks that arrive already finished when a task was
expected, a ``shown`` gate that never opens for a hidden window. Every one of
those was a real freeze. None of them exists in a browser.

So the Google pane is handed to a browser the person already has. It looks and
behaves like any other browser window (that is what was asked for), Google's
sign-in is a first-class citizen there, and the one thing the app actually
needs -- the cookie jar -- is read over the DevTools protocol, which this
project already uses for arena.ai (`arena/auth.py`, `arena/api.py`).

Why not the default browser without a flag
------------------------------------------
The cookies have to come OUT of the window. A browser that is not listening on
a debugging port cannot be asked for them, and that is not a detail that can be
worked around. The profile also has to be ours: pointing the app at the
person's everyday profile would lock them out of their own browser while the
app runs, and would put their whole browsing history in the same sandbox as a
throw-away sign-in.

So the browser is the person's default one (found through the Windows `UserChoice`
registry value), with two additions: a private, app-owned profile under the
app's config folder, and a debugging port. To the user it is an ordinary browser
window on google.com. The only visible difference is that it is signed out --
which is exactly what a sign-in window should be.

If the debugging port cannot be opened (group policy, an old browser build),
the window is still opened the plain way: it will not hand back cookies, but the
person is not left with nothing, and the app says so in its log.
"""

from __future__ import annotations

import json
import logging
import os
import re
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

LOG = logging.getLogger("arena.browserwindow")

IS_WINDOWS = sys.platform == "win32"

HOME_URL = "https://www.google.com/"
ARENA_URL = "https://arena.ai/"

# Cookie domains that mean "this is the site the window was opened for".
GOOGLE_DOMAINS = ("google.com", "google.ru", "google.co.uk", "gstatic.com")
ARENA_DOMAINS = ("arena.ai",)

# Google's session cookies. Any one of these means "this window is signed in".
AUTH_COOKIES = ("SID", "SAPISID", "__Secure-1PSID", "__Secure-3PSID",
                "__Secure-1PSIDTS", "__Secure-3PSIDTS")


# ---------------------------------------------------------------------------
# Finding the browser the person actually uses
# ---------------------------------------------------------------------------
def _user_choice_browser() -> str | None:
    """The .exe Windows would open for http:// links, or None.

    This is the same key Windows itself consults, so it answers "the default
    browser" rather than "a browser we guessed is good".
    """
    if not IS_WINDOWS:
        return None
    try:
        import winreg
    except ImportError:
        return None
    key = (r"Software\Microsoft\Windows\Shell\Associations"
           r"\UrlAssociations\http\UserChoice")
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key) as handle:
            prog_id, _ = winreg.QueryValueEx(handle, "ProgId")
    except OSError:
        return None
    return _exe_for_progid(str(prog_id))


def _exe_for_progid(prog_id: str) -> str | None:
    """Turn a ProgId such as ``MSEdgeHTM`` into an executable path."""
    import winreg

    candidates = [prog_id]
    if prog_id.startswith("Firefox"):
        candidates.append("FirefoxURL")
    for prog in candidates:
        for root in (winreg.HKEY_CURRENT_USER, winreg.HKEY_CLASSES_ROOT):
            shell = rf"{prog}\shell\open\command"
            try:
                with winreg.OpenKey(root, shell) as handle:
                    command, _ = winreg.QueryValueEx(handle, "")
            except OSError:
                continue
            path = _exe_from_command(str(command))
            # Firefox cannot be driven by the DevTools protocol, so a cookie
            # read there is impossible; skip it and keep looking.
            if path and "firefox" not in Path(path).name.lower():
                return path
    return None


def _exe_from_command(command: str) -> str | None:
    """Pull the executable out of a shell command line."""
    text = command.strip()
    if not text:
        return None
    match = re.match(r'"([^"]+)"', text)
    if match:
        path = match.group(1)
    else:
        path = text.split(" ")[0]
    path = os.path.expandvars(path)
    return path if os.path.isfile(path) else None


# Browsers that speak the DevTools protocol. Used when the default browser is
# Firefox (which does not): signing in there would work, but the cookies could
# never be read, so a Chromium window is opened instead.
CHROMIUM_CANDIDATES = {
    # Chrome first, and the order is load-bearing. Windows 11 ships a Store build
    # of Edge that is an MSIX app: launching its .exe does not reliably carry the
    # command line across the app-container boundary, so the debugging flag --
    # and with it every cookie read -- silently does not take effect. The browser
    # that appeared was Edge's own start page with no page of ours in it.
    "Google Chrome": [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
    ],
    "Microsoft Edge": [
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
    ],
    "Brave": [
        r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe",
        r"C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application\brave.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\BraveSoftware\Brave-Browser\Application\brave.exe"),
    ],
    "Vivaldi": [
        os.path.expandvars(r"%LOCALAPPDATA%\Vivaldi\Application\vivaldi.exe"),
        r"C:\Program Files\Vivaldi\Application\vivaldi.exe",
    ],
}


def chromium_fallback() -> str | None:
    """Any driveable browser, Chrome first."""
    path, _how = find_browser()
    return path


# Where the app looks for a browser. `chrome` is the default on purpose: it is
# the one build we can drive reliably, and the person asked for it explicitly.
BROWSER_ORDER = ("chrome", "edge", "brave", "vivaldi", "default")


# Short names the switch and the fallback list use, and the display names the
# candidate table is keyed by. Without this map `_by_name("chrome")` looked up a
# key that does not exist and answered None -- so every browser "was not found",
# both windows silently refused to open, and the log said only "no browser found
# to open Google in". That is the round-7 regression: the app stopped opening
# any window at all on a machine where Chrome and Edge were both installed.
_NAME_ALIASES = {
    "chrome": "Google Chrome",
    "google chrome": "Google Chrome",
    "edge": "Microsoft Edge",
    "msedge": "Microsoft Edge",
    "microsoft edge": "Microsoft Edge",
    "brave": "Brave",
    "vivaldi": "Vivaldi",
}

# Where the registry keeps the real path of the installed executable. A Store
# build of Edge is an MSIX app and has no plain file, but it does register here.
_APP_PATHS = {
    "Google Chrome": "chrome.exe",
    "Microsoft Edge": "msedge.exe",
    "Brave": "brave.exe",
    "Vivaldi": "vivaldi.exe",
}


def _exe_from_app_paths(exe_name: str) -> str | None:
    """``App Paths`` from the registry: the path Windows itself would use."""
    try:
        import winreg
    except ImportError:
        return None
    for root in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        try:
            with winreg.OpenKey(
                    root, rf"SOFTWARE\Microsoft\Windows\CurrentVersion"
                          rf"\App Paths\{exe_name}") as handle:
                value, _ = winreg.QueryValueEx(handle, "")
        except OSError:
            continue
        value = os.path.expandvars(str(value)).strip('"')
        if os.path.isfile(value):
            return value
    return None


def _by_name(name: str) -> str | None:
    """The executable for ``chrome`` / ``edge`` / a display name, or None."""
    key = _NAME_ALIASES.get(str(name).strip().lower(), str(name).strip())
    for path in CHROMIUM_CANDIDATES.get(key) or []:
        if os.path.isfile(path):
            return path
    exe = _APP_PATHS.get(key)
    if exe:
        path = _exe_from_app_paths(exe)
        if path:
            return path
    return None


def find_browser() -> tuple[str | None, str]:
    """``(path, how)`` — the executable to use and where it came from.

    Deliberately NOT "the default browser". A default can be anything the user
    installed -- including a browser whose sign-in flow the app cannot read --
    and the failure mode is invisible: a window opens, and the cookies never
    arrive. Chrome first, Edge only when Chrome is genuinely absent.
    """
    wanted = (os.environ.get("ARENA_BROWSER") or "chrome").strip().lower()
    order = [wanted] if wanted in CHROMIUM_CANDIDATES or wanted == "default" \
        else list(BROWSER_ORDER)
    if wanted != "default" and "default" not in order:
        order.append("default")
    for name in order:
        if name == "default":
            path = _user_choice_browser()
            if path:
                return path, "default"
            continue
        path = _by_name(name)
        if path:
            return path, name
    return None, "none"


# ---------------------------------------------------------------------------
# DevTools protocol
# ---------------------------------------------------------------------------
def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def wait_for_debugger(port: int, timeout: float = 25.0) -> bool:
    """True once the browser answers on its debugging port."""
    end = time.time() + timeout
    url = f"http://127.0.0.1:{port}/json/version"
    while time.time() < end:
        try:
            with urllib.request.urlopen(url, timeout=1.0) as response:
                if response.status == 200:
                    return True
        except Exception:
            time.sleep(0.25)
    return False


def _tabs(port: int) -> list[dict]:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/json", timeout=2.0) as response:
            return json.loads(response.read().decode("utf-8", "replace"))
    except Exception:
        return []


def page_tab(port: int, domains: tuple[str, ...]) -> dict | None:
    """The page tab for one of ``domains``, or None.

    Matching on the domain matters: the browser now serves both arena.ai and
    google.com, and a window that grabs "the first tab" ends up reading another
    site's cookies.
    """
    pages = [t for t in _tabs(port)
             if str(t.get("type")) == "page" and t.get("webSocketDebuggerUrl")]
    for tab in pages:
        # The host, not the whole URL: `_domain_matches` compares domains, and
        # "https://www.google.com/" does not end with ".google.com" -- the
        # scheme and the slash make sure of it. Passing the URL here meant no
        # tab ever matched its own site, which is why the window could show
        # google.com for 90 s while the pane said "no page appeared".
        if _domain_matches(_host_of(str(tab.get("url") or "")), domains):
            return tab
    for tab in pages:
        url = str(tab.get("url") or "")
        # A blank tab is ours to use -- but only a truly blank one. The
        # browser's own start page ("edge://newtab", "chrome://newtab") is not:
        # navigating it away is fine, but treating it as "the page is ready"
        # is how the pane reported success while showing the browser's home.
        if url in ("about:blank", ""):
            return tab
    return None


def _domain_matches(value: str, domains: tuple[str, ...]) -> bool:
    """True when ``value`` (a URL or a cookie domain) belongs to ``domains``."""
    text = str(value or "").lower().lstrip(".")
    if not text:
        return False
    for domain in domains:
        if text == domain or text.endswith("." + domain):
            return True
    return False


def google_tab(port: int) -> dict | None:
    """The page tab that is on google.com, preferring the sign-in flow."""
    pages = [t for t in _tabs(port)
             if str(t.get("type")) == "page" and t.get("webSocketDebuggerUrl")]
    for tab in pages:
        url = str(tab.get("url") or "")
        if "accounts.google.com" in url:
            return tab
    for tab in pages:
        url = str(tab.get("url") or "")
        if "google.com" in url or url in ("about:blank", ""):
            return tab
    return pages[0] if pages else None


def cdp(ws_url: str, method: str, params: dict | None = None,
        timeout: float = 10.0) -> dict | None:
    """One DevTools command, one reply.

    Same shape as `arena/api.py::_cdp_execute`, for the same reason: a fresh
    socket per call is slower than a kept one, but it cannot be left half-read
    when the browser closes the window mid-command.
    """
    try:
        import websocket
    except ImportError:
        LOG.info("websocket-client is missing; the browser cannot be read")
        return None
    try:
        ws = websocket.create_connection(ws_url, timeout=timeout)
        message = {"id": 1, "method": method}
        if params:
            message["params"] = params
        ws.send(json.dumps(message))
        reply = json.loads(ws.recv())
        ws.close()
        return reply
    except Exception as exc:
        LOG.info("DevTools command %s failed: %s", method, exc)
        return None


def evaluate(ws_url: str, script: str, timeout: float = 10.0):
    """Run a script in the page and return its value, or None."""
    reply = cdp(ws_url, "Runtime.evaluate",
                {"expression": script, "returnByValue": True,
                 "awaitPromise": True}, timeout=timeout)
    if not reply:
        return None
    result = reply.get("result", {})
    if result.get("exceptionDetails"):
        LOG.info("DevTools script raised: %s", result["exceptionDetails"])
        return None
    value = result.get("result", {})
    return value.get("value")


def all_cookies_raw(ws_url: str) -> list[dict]:
    """Every cookie the browser holds, as the DevTools dicts themselves."""
    reply = cdp(ws_url, "Network.getAllCookies")
    if not reply:
        return []
    return list(reply.get("result", {}).get("cookies") or [])


def all_cookies(ws_url: str) -> list[tuple[str, str]]:
    """Every ``(name, value)`` the browser holds. Empty on any failure."""
    reply = cdp(ws_url, "Network.getAllCookies")
    if not reply:
        return []
    cookies = reply.get("result", {}).get("cookies") or []
    out = []
    for item in cookies:
        try:
            out.append((str(item.get("name")), str(item.get("value"))))
        except Exception:
            continue
    return out


# ---------------------------------------------------------------------------
# The window itself
# ---------------------------------------------------------------------------
class BrowserEvent:
    """The tiny slice of the pywebview event API that `attach()` subscribes to."""

    def __init__(self, name: str):
        self.name = name
        self._handlers: list = []
        self._lock = threading.Lock()

    def __iadd__(self, handler):
        with self._lock:
            self._handlers.append(handler)
        return self

    def __isub__(self, handler):
        with self._lock:
            self._handlers = [h for h in self._handlers if h is not handler]
        return self

    def set(self) -> None:
        with self._lock:
            handlers = list(self._handlers)
        for handler in handlers:
            try:
                handler()
            except Exception:
                LOG.info("a %s handler failed", self.name, exc_info=True)


class BrowserEvents:
    def __init__(self):
        self.loaded = BrowserEvent("loaded")
        self.shown = BrowserEvent("shown")
        self.closing = BrowserEvent("closing")
        self.closed = BrowserEvent("closed")


class BrowserWindow:
    """A browser window opened for the Google pane, driven over DevTools.

    Nothing here blocks a caller: the browser is started on its own thread, and
    every command has a timeout. That is the whole point of the change -- the
    class of bug this replaces was always "a call that waited on a message
    loop that was not running".
    """

    domains: tuple[str, ...] = GOOGLE_DOMAINS

    def __init__(self, url: str = HOME_URL, *, user_data_dir: str | None = None,
                 private: bool = True, domains: tuple[str, ...] | None = None,
                 title_marker: str = "google"):
        self.url = url or HOME_URL
        self.user_data_dir = user_data_dir
        self.private = private
        self.events = BrowserEvents()
        self.native = None          # no WinForms form any more
        self.webview = None
        self._proc: subprocess.Popen | None = None
        self._port: int = 0
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        # Its own lock: `_open_tab` runs from two threads at once (the launch
        # thread's `_watch_page` and a navigation's `load_url`), and both can
        # find `/json` empty before either tab exists. The check and the
        # create must be one step, or both create -- which is how one press
        # produced two tabs even after the caller-side checks were fixed.
        self._tab_lock = threading.Lock()
        # The page this window created, remembered until it is gone. A
        # browser does not list a brand-new tab in `/json` immediately, so
        # for a moment after `/json/new` returns, `/json` still looks
        # empty -- and a second caller (navigation vs. the launch thread)
        # then created yet another tab. Remembering the tab closes that
        # window of time; `/json` cannot.
        self._known_tab: dict | None = None
        self._known_fresh = False      # trusted until the browser lists it
        self._host = ""
        self._closed = False
        self._exit_watched = None      # the process whose exit is being watched
        self._debug_ok = False
        self._browser: str | None = None
        self._how = "none"
        self.build_error: str | None = None
        # A machine-readable twin of `build_error`, for the page: the
        # message is English prose that may be reworded, and the diagnosis
        # screen used to guess the cause by matching that prose.
        self.build_code: str | None = None
        if domains is not None:
            # The same transport serves arena.ai now, so "which site is this
            # window for" cannot be a constant any more.
            self.domains = tuple(domains)
        self.title_marker = title_marker
        self._last_load = 0.0
        self._load_failures = 0
        # Cookie operations must not be run twice at once: the sign-in watcher
        # polls every second and a second DevTools socket on the same tab is a
        # needless way to make both fail.
        self._cookie_lock = threading.Lock()

    # -- creation --------------------------------------------------------
    def start(self) -> bool:
        if not IS_WINDOWS:
            LOG.info("no browser window on this platform; the pane stays on HTTPS")
            return False
        with self._lock:
            if self._closed:
                return False
            proc = self._proc
            alive = proc is not None and proc.poll() is None
            if not alive:
                # The previous browser is gone: closed by the person, or by
                # close_and_forget(). Keeping `_thread` from a dead window is
                # why the *second* sign-in opened nothing at all -- this method
                # answered True on a thread that had already finished, so the
                # caller believed a window was being built.
                self._thread = None
                self._proc = None
                self._debug_ok = False
            elif self._thread is not None and self._thread.is_alive():
                return True
            self._thread = threading.Thread(target=self._launch, daemon=True,
                                            name="google-browser")
            self._thread.start()
        return True

    def _watch_exit(self, proc) -> None:
        """Notice a browser the person closed, without waiting for a poll.

        `events.closed` used to be set only by our own `destroy()`, so a window
        closed with the X looked alive for the whole 15-minute sign-in timeout:
        the spinner never stopped and the next click did nothing.

        Watched once per process, and never on a process that has already
        exited -- `_launch` calls this both on success and on the "started but
        unreadable" path, and the second call arrived after the browser was
        gone, which marked a perfectly good window as closed one millisecond
        after it opened.
        """
        if proc is None:
            return
        with self._lock:
            if self._exit_watched is proc:
                return
            self._exit_watched = proc
        if proc.poll() is not None:
            return                         # already gone; nothing to watch

        def watch():
            try:
                proc.wait()
            except Exception:
                return
            if self._closed:
                return
            self._closed = True            # a window closed for good stays closed
            self._debug_ok = False
            LOG.info("browser window: closed by the person")
            self.events.closed.set()

        threading.Thread(target=watch, daemon=True,
                         name="browser-exit-watch").start()

    # Browsers to try, in order, when the first one will not start. This is the
    # "open a window no matter what" half of the answer: Chrome is still the
    # preferred one, but a working sign-in in Edge beats a dead button in Chrome.
    FALLBACK_ORDER = ("chrome", "edge", "brave", "vivaldi")
    # How long one browser gets to answer on its port. The old 25 s was spent
    # per attempt and only once; with a list of browsers behind it, a shorter
    # wait keeps a dead candidate from holding the button for two minutes.
    DEBUG_WAIT = float(os.environ.get("ARENA_DEBUG_WAIT") or 12.0)

    def _candidates(self) -> list[tuple[str, str]]:
        """Every (path, how) worth trying, best first, without duplicates."""
        wanted = (os.environ.get("ARENA_BROWSER") or "chrome").strip().lower()
        # The keys are display names ("Google Chrome", "Microsoft Edge"), the
        # switch takes short ones ("chrome", "edge"), so any word will do.
        known = {word.lower() for name in CHROMIUM_CANDIDATES
                 for word in name.split()}
        order = [wanted] if wanted in known else list(self.FALLBACK_ORDER)
        for name in self.FALLBACK_ORDER:
            if name not in order:
                order.append(name)
        found: list[tuple[str, str]] = []
        for name in order:
            path = _by_name(name)
            if path and all(path != seen[0] for seen in found):
                found.append((path, name))
        return found

    def _launch(self) -> None:
        try:
            candidates = self._candidates()
            if not candidates:
                self.build_code = "no_browser"
                self.build_error = "no supported browser found"
                LOG.warning("browser window: no browser found to open Google in")
                self.events.loaded.set()
                return
            for path, how in candidates:
                if self._try_browser(path, how):
                    return
                # Every failure passes the turn to the next candidate, including
                # a browser that started but stayed unreadable: `_try_browser`
                # closes that process before returning, so there is nothing left
                # to keep. Keeping it was tried and abandoned (see
                # tests/test_browser_profile_reuse.py and desktop-23.log): a
                # window this app cannot read is one it can never take cookies
                # from, so the attempt has to move on. When no candidate can be
                # read at all, `_open_unreadable` at the end still puts the page
                # on screen for the person.
            self._open_unreadable()
            self.events.loaded.set()
        except Exception as exc:
            self.build_error = f"{type(exc).__name__}: {exc}"
            LOG.exception("browser window: could not be opened")
            self.events.loaded.set()

    def _close_proc(self) -> None:
        """End the browser process this object started, if it is still running."""
        proc = self._proc
        self._proc = None
        self._debug_ok = False
        if proc is None or proc.poll() is not None:
            return
        try:
            proc.terminate()
            proc.wait(timeout=3)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass

    def _open_unreadable(self) -> None:
        """Last resort: open the page in a browser the app cannot read.

        The person asked for the window to open "no matter what", and a session
        they can actually finish beats a button that does nothing. Cookies then
        come from a pasted header instead of the jar, which the pane already
        supports -- so this is a degraded mode, not a broken one.
        """
        if not self.url:
            return
        try:                                       # pragma: no cover - platform
            os.startfile(self.url)                 # type: ignore[attr-defined]
        except Exception:
            try:                                   # pragma: no cover - platform
                subprocess.Popen(["cmd", "/c", "start", "", self.url],
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
            except Exception:
                LOG.exception("browser window: could not open the page at all")
                return
        if not self.build_code:
            self.build_code = "no_readable_browser"
        if not self.build_error:
            self.build_error = ("opened in the default browser, which the app "
                                "cannot read: finish signing in there and paste "
                                "the Cookie header")
        LOG.warning("browser window: fell back to an unreadable window: %s",
                    self.build_error)

    def _try_browser(self, path: str, how: str) -> bool:
        """One attempt: start this browser, wait for its debugging port.

        Returns True when the window is up and readable. On failure it records
        why in `build_error` and returns False, leaving the caller free to try
        the next browser.
        """
        try:
            self._browser, self._how = path, how
            self._port = free_port()

            # A dedicated port is not enough on its own: without an explicit
            # bind address the debugger is refused on newer Chromium builds for
            # anything but loopback-local calls, and Edge in particular ignores
            # the port entirely when it hands the command line to a running
            # instance. 127.0.0.1 makes the listener real.
            args = [path, f"--remote-debugging-port={self._port}",
                    "--remote-debugging-address=127.0.0.1",
                    "--no-first-run", "--no-default-browser-check"]
            profile = _safe_profile(self.user_data_dir)
            if profile:
                args.append(f"--user-data-dir={profile}")
            if self.private:
                # A sign-in window must never arrive carrying somebody's
                # session: Google would sign the person straight back in.
                args.append("--incognito")
            # Start blank and navigate over CDP. Passing the URL on the command
            # line opened a second window in Edge: the browser shows the
            # argument AND the first `load_url` navigates, so the person got two
            # windows and only one of them was the one the app could read.
            #
            # The exception is a single-use window (`arena/ephemeral.py`): it is
            # *given* its page on the command line and never navigated after
            # that, which is what makes it start in one second instead of nine
            # and show exactly one window. The difference is the promise that no
            # later `load_url` will follow, not the flag itself.
            start_url = getattr(self, "open_url_on_start", None)
            args.append(start_url or "about:blank")

            LOG.info("browser window: opening %s (%s)", Path(path).name, how)
            self._proc = subprocess.Popen(
                args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            self.events.shown.set()

            self._debug_ok = wait_for_debugger(self._port, timeout=self.DEBUG_WAIT)
            if not self._debug_ok:
                # The distinction matters, because the two cases look the same
                # to the person (no window, nothing happens) and need different
                # answers.
                code = self._proc.poll() if self._proc is not None else None
                if code is not None:
                    # The browser was started and exited on its own. That is
                    # what an already-running Chrome does when it is handed a
                    # command line without --user-data-dir: the new process
                    # forwards the request to the existing instance and dies,
                    # so no window of ours ever appears and no port is opened.
                    self.build_code = "already_running"
                    self.build_error = (
                        f"the browser exited at once (code {code}); if a "
                        f"{self._how} window is already open, close it or the "
                        f"app cannot start its own")
                else:
                    # The window is up but the debugger is not listening. An
                    # Edge that was already running (or a Store build that
                    # never took the flags) answers exactly like this: a
                    # perfectly good window the app cannot read. Retrying the
                    # *same* browser cannot help -- it will reuse the running
                    # instance again -- so this counts as a failed attempt and
                    # the caller moves to the next candidate.
                    self.build_code = "port_blocked_or_store_edge"
                    self.build_error = (
                        f"{self._how} is open but its debugging port never "
                        f"answered; it reuses its running instance")
                LOG.warning("browser window: %s", self.build_error)
                # Leave nothing half-alive behind: a browser we cannot read is
                # not a window this app should keep, and its profile folder is
                # then free for the next attempt.
                self._close_proc()
                return False
            LOG.info("browser window: debugging port %s is up", self._port)
            self._watch_exit(self._proc)
            self._watch_page()
            return True
        except Exception as exc:
            self.build_code = "launch_failed"
            self.build_error = f"{type(exc).__name__}: {exc}"
            LOG.exception("browser window: could not be opened")
            return False

    def _watch_page(self) -> None:
        """Fire `loaded` when the tab has a page the app can talk to."""
        # Point the window at the site. If the browser put its own start page
        # there, that page is navigated; if it is empty, a page is created.
        tab = self.tab()
        if tab is None:
            # The new page is created *at* the address, so it already shows it.
            # Navigating it too was the second half of the doubling: /json/new
            # opened arena.ai, and the immediate Page.navigate re-requested the
            # same URL -- two loads, and on the slow path two windows.
            tab = self._open_tab(getattr(self, "open_url_on_start", None) or self.url)
        elif getattr(self, "open_url_on_start", None) is None:
            # Only a blank window is navigated. A single-use window already
            # carries its page from the command line, and navigating it again
            # is exactly what produced the second copy of the page.
            self._navigate(tab, self.url)
        else:
            # The page is expected to arrive on its own. Give the browser a
            # moment for that, then navigate as a fallback -- a startup page
            # left blank is the one case where the command line did not take.
            deadline = time.time() + 4.0
            while time.time() < deadline and not self._closed:
                now = self.tab()
                if now and str(now.get("url") or "") not in ("", "about:blank"):
                    break
                time.sleep(0.3)
            else:
                fresh = self.tab()
                if fresh is not None:
                    LOG.info("browser window: the start page stayed blank; navigating")
                    self._navigate(fresh, self.url)
        end = time.time() + 90.0
        while time.time() < end and not self._closed:
            tab = self.tab()
            if tab and str(tab.get("url") or "") not in ("", "about:blank"):
                self._host = _host_of(str(tab.get("url") or ""))
                self.events.loaded.set()
                LOG.info("browser window: page is %s", tab.get("url"))
                return
            time.sleep(0.5)
        LOG.info("browser window: no page appeared; the pane cannot watch it")

    # -- the surface the engines use -------------------------------------
    def tab(self) -> dict | None:
        """The page belonging to this window's site."""
        return page_tab(self._port, self.domains)

    def load_url(self, url: str) -> bool:
        """Navigate the window to ``url`` (new tab if it is gone)."""
        url = str(url)
        self._last_load = time.time()
        if self.build_error is not None:
            return False

        def work():
            # A navigation can arrive before the debugging port is up (the
            # window is created lazily and the button is pressed immediately).
            # Without this wait the tab lookup failed, the page was never
            # navigated, and the person was left looking at a blank window.
            if not self._debug_ok:
                self._debug_ok = wait_for_debugger(self._port, timeout=20.0)
                if not self._debug_ok:
                    LOG.warning("browser window: port never answered; %s was "
                                "not opened", url)
                    return
            tab = self.tab()
            if tab is not None and self._navigate(tab, url):
                self._host = _host_of(url)
                self._load_failures = 0
                return
            # Only when there is no page at all: create one. Anything else
            # would be a second window the app cannot see.
            tab = self._open_tab(url)
            if tab is not None:
                self._navigate(tab, url)
            self._host = _host_of(url)
            self._load_failures = 0

        threading.Thread(target=work, daemon=True,
                         name="google-browser-load").start()
        return True

    def _navigate(self, tab: dict, url: str) -> bool:
        """Point an existing page at ``url``. No new window, ever."""
        if not tab or not tab.get("webSocketDebuggerUrl"):
            return False
        reply = cdp(tab["webSocketDebuggerUrl"], "Page.navigate", {"url": url})
        return reply is not None

    def _open_tab(self, url: str) -> dict | None:
        """Create the window's one page -- and only when there is none.

        The docstring always said "when there is none yet"; the code never
        checked. `PUT /json/new` opens a tab whatever the browser is already
        showing, so every caller that guessed wrong about the state of `/json`
        left an extra tab behind. That is what a person describes as "it opens
        two or three pages at once": the page from the command line, the one a
        navigation created, and one more from the next navigation that ran
        before the previous tab had a URL to match.
        """
        with self._tab_lock:
            known = self._known_tab
            listed = _tabs(self._port)
            if known and known.get("webSocketDebuggerUrl"):
                for tab in listed:
                    if tab.get("webSocketDebuggerUrl") == known["webSocketDebuggerUrl"]:
                        # The browser has caught up and lists it; from now on
                        # its own list is the authority, and the remembered tab
                        # gets no more benefit of the doubt.
                        self._known_fresh = False
                        return tab
                if not listed:
                    # The list is briefly empty right after a create, so an
                    # empty answer right after one is not evidence the tab is
                    # gone. Only ask this question about a tab we just made;
                    # `_known_fresh` carries whether we may still trust it.
                    if self._known_fresh:
                        return known
                # Otherwise the remembered tab is genuinely gone (the person
                # closed it, or the browser was replaced) and `_known_tab`
                # must not be handed out again.
                self._known_tab = None
            existing = [t for t in listed
                        if str(t.get("type")) == "page"
                        and t.get("webSocketDebuggerUrl")]
            if existing:
                # Some page already exists. Ours if it matches our domains;
                # otherwise the first one, which the caller will navigate.
                # Either way, opening another tab is not the answer.
                found = self.tab() or existing[0]
                self._known_tab = found
                self._known_fresh = False
                return found
            try:
                # Create the page *at* the address. The parameter is not
                # optional: /json/new without it opens an empty tab and leaves
                # the caller to navigate, which is how the same URL ended up
                # loading twice.
                request = urllib.request.Request(
                    f"http://127.0.0.1:{self._port}/json/new?{url}",
                    method="PUT")
                with urllib.request.urlopen(request, timeout=3.0) as response:
                    created = json.loads(response.read().decode("utf-8", "replace"))
                if isinstance(created, dict) and created.get("webSocketDebuggerUrl"):
                    self._known_tab = created
                    self._known_fresh = True
                    return created
            except Exception:
                LOG.info("browser window: could not create a page")
            return self.tab()

    def evaluate_js(self, script: str, timeout: float = 8.0):
        if not self._debug_ok:
            return None
        tab = self.tab()
        if tab is None:
            return None
        return evaluate(tab["webSocketDebuggerUrl"], str(script), timeout=timeout)

    def run_js(self, script: str, timeout: float = 8.0):
        return self.evaluate_js(script, timeout)

    def evaluate_js_value(self, script: str, timeout: float = 8.0):
        """Same as `evaluate_js`: the DevTools reply is already a plain value."""
        return self.evaluate_js(script, timeout)

    def get_cookies(self, *a, **kw):
        return self.cookie_tuples()

    def cookie_tuples(self, limit: float = 8.0) -> list[tuple[str, str, str]]:
        """The jar as plain tuples. This is what the whole design exists for."""
        if not self._debug_ok:
            return []
        with self._cookie_lock:
            tab = self.tab()
            if tab is None:
                # During OAuth / Cloudflare redirects the tab URL may not match
                # self.domains yet, even though Network.getAllCookies already
                # holds the session cookies. Any live page target works for CDP.
                pages = [t for t in _tabs(self._port)
                         if str(t.get("type")) == "page" and t.get("webSocketDebuggerUrl")]
                tab = pages[0] if pages else getattr(self, "_known_tab", None)
            if tab is None:
                return []
            raw = all_cookies_raw(tab["webSocketDebuggerUrl"])
        out = []
        for item in raw:
            domain = str(item.get("domain") or "")
            if not _domain_matches(domain, self.domains):
                continue
            try:
                out.append((str(item.get("name")), str(item.get("value")),
                            domain or ("." + self.domains[0])))
            except Exception:
                continue
        return out

    def clear_cookies(self) -> bool:
        if not self._debug_ok:
            return False
        tab = self.tab()
        if tab is None:
            return False
        reply = cdp(tab["webSocketDebuggerUrl"], "Network.clearBrowserCookies")
        return reply is not None

    # -- window management -----------------------------------------------
    def show(self) -> None:
        """Bring the browser forward. A closed window is reopened."""
        if self._proc is not None and self._proc.poll() is None:
            return
        self.start()

    def hide(self) -> None:
        """Do nothing, on purpose.

        The window belongs to the person's own browser now; minimising or
        closing it is their business. Closing it here is what the old code did,
        and it destroyed the session before the jar could be read.
        """

    def resize(self, width: int, height: int) -> None:
        """Not applicable: a browser window ignores an app's bounds."""

    def move(self, x: int, y: int) -> None:
        """Not applicable, for the same reason as `resize`."""

    def restore(self) -> None:
        """Not applicable: the window is managed by the browser."""

    def destroy(self) -> None:
        """Close the window we opened -- and only the one we opened."""
        self._closed = True
        self.events.closing.set()
        proc = self._proc
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
            except Exception:
                pass
        self.events.closed.set()

    # -- introspection ---------------------------------------------------
    def host(self) -> str:
        tab = self.tab() if self._debug_ok else None
        if tab:
            url = str(tab.get("url") or "")
            if url:
                return _host_of(url)
        return self._host

    @property
    def browser(self):
        """Kept for `google_ai._read_edge_host_on_ui`; there is no Edge layer."""
        return None

    def is_ready(self) -> bool:
        return self._debug_ok

    def wait_built(self, timeout: float = 8.0) -> bool:
        """True once the browser answered, or once it is clear it never will.

        The startup code asks this to decide whether to keep the window or fall
        back. A browser window is "built" when its debugging port answers --
        there is no form to wait for.
        """
        end = time.time() + timeout
        while time.time() < end:
            if self.build_error is not None:
                return False
            if self._debug_ok:
                return True
            if self._proc is not None:
                # The port may still be coming up; keep waiting while it lives.
                if self._proc.poll() is not None and not self._debug_ok:
                    return False
            time.sleep(0.2)
        return self._debug_ok

    def state(self) -> dict:
        proc = self._proc
        return {
            "platform": "browser" if self._debug_ok else "browser-unreadable",
            "browser": Path(self._browser).name if self._browser else None,
            "found_via": self._how,
            "port": self._port,
            "debuggable": self._debug_ok,
            "running": bool(proc is not None and proc.poll() is None),
            "thread": self._thread.name if self._thread else None,
            "build_error": self.build_error,
            "build_code": self.build_code,
        }


# What WebView2 leaves behind in its profile folder. A Chromium pointed at one
# of these is pointed at a live WebView2 store, which is a native conflict: the
# app died the instant the browser opened, with an empty desktop.log because the
# fault was in native code.
#
# The marker is `EBWebView` and nothing else. `Default/Cache` and
# `Default/Network` used to be listed here, and that was wrong in a way that
# cost the person a working sign-in: those are *ordinary Chrome folders*, so the
# app's own `google-browser` profile was refused from its **second** launch
# onwards -- the first run created the profile, and every run after saw
# `Default/Cache` and decided it was WebView2. The window was then started
# without `--user-data-dir`, and a Chrome started without one hands its command
# line to whatever Chrome is already running and exits: no new window, no
# debugging port, and a sign-in button that does nothing at all.
_WEBVIEW2_MARKERS = (("EBWebView",),)


def _safe_profile(user_data_dir: str | None) -> str | None:
    """A profile folder that cannot belong to the app's own WebView2.

    Returns a path to use, or None when no profile should be passed at all
    (the browser then uses its private one, which is what a sign-in window
    wants anyway).
    """
    if not user_data_dir:
        return None
    path = Path(user_data_dir)
    # Defence in depth: the caller was fixed to pass its own folder, but a
    # folder named `webview` at this level is the main window's store.
    if path.name.lower() in ("webview", "ebwebview"):
        LOG.warning("browser window: %s is the app's WebView2 profile; using a "
                    "private one instead", path)
        return None
    for parts in _WEBVIEW2_MARKERS:
        if path.joinpath(*parts).exists():
            LOG.warning("browser window: %s already holds a WebView2 store; "
                        "using a private profile instead", path)
            return None
    # The folder already exists: `mkdtemp` made it, and a single-use profile is
    # deleted the moment its window closes. Re-creating it here raced with that
    # deletion -- the launch thread was still inside `_safe_profile` when the
    # window was closed, and an empty `arena-signin-*` folder appeared right
    # after `rmtree` had removed it. Creating only what is missing ends the
    # race without changing what the browser is handed.
    try:
        path.mkdir(parents=True, exist_ok=True)
    except Exception:
        return None
    return str(path)


def _host_of(url: str) -> str:
    match = re.match(r"https?://([^/]+)", str(url))
    return match.group(1).lower() if match else ""


class EngineBrowserWindow:
    """Adapts `BrowserWindow` to the surface `google_ai` already expects.

    Same role `EngineWindow` played for the WebView2 host: the engine keeps
    working unchanged, and only this class has to follow when the transport
    changes again.
    """

    # A browser window is not pywebview: there is no message loop of ours, no
    # `shown` event, and "created" is the only fact there is. Engines ask this
    # flag instead of guessing from `native`, which is None for pywebview too.
    is_browser = True

    def __init__(self, window: BrowserWindow):
        self._window = window
        self.events = window.events
        window.start()

    @property
    def native(self):
        return None                 # no native control; the engine checks this

    def wait_built(self, timeout: float = 8.0) -> bool:
        return self._window.wait_built(timeout)

    def evaluate_js(self, script, *a, **kw):
        return self._window.evaluate_js(script, *a, **kw)

    def evaluate_js_value(self, script, *a, **kw):
        return self._window.evaluate_js_value(script, *a, **kw)

    def run_js(self, script, *a, **kw):
        return self._window.run_js(script, *a, **kw)

    def load_url(self, url):
        return self._window.load_url(url)

    def show(self):
        return self._window.show()

    def hide(self):
        return self._window.hide()

    def resize(self, width, height):
        return self._window.resize(width, height)

    def move(self, x, y):
        return self._window.move(x, y)

    def restore(self):
        return self._window.restore()

    def destroy(self):
        return self._window.destroy()

    def get_cookies(self, *a, **kw):
        return self._window.get_cookies(*a, **kw)

    def cookie_tuples(self, *a, **kw):
        return self._window.cookie_tuples(*a, **kw)

    def clear_cookies(self):
        return self._window.clear_cookies()

    @property
    def host(self):
        return self._window.host()

    @property
    def webview(self):
        return None

    @property
    def browser(self):
        return None

    def state(self):
        return self._window.state()


def create_google_window(user_data_dir: str | None = None):
    """The Google pane's window, or None where there is no GUI.

    `ARENA_GOOGLE_WINDOW` still decides: ``webview2`` keeps the old host,
    ``pywebview`` the older one, and by default the browser is used.
    """
    if not IS_WINDOWS:
        return None
    window = BrowserWindow(HOME_URL, user_data_dir=user_data_dir,
                           domains=GOOGLE_DOMAINS)
    return EngineBrowserWindow(window)


def create_arena_window(user_data_dir: str | None = None):
    """The arena.ai sign-in window: the same transport, a different site."""
    if not IS_WINDOWS:
        return None
    window = BrowserWindow(ARENA_URL, user_data_dir=user_data_dir,
                           domains=ARENA_DOMAINS, title_marker="arena")
    return EngineBrowserWindow(window)
