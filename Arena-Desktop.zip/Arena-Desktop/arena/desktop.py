"""
Arena Desktop: a native window (pywebview + Edge WebView2) over the local Flask
UI, plus a hidden arena.ai window (the engine) that sends chats from arena's
own page. Sign-in and human checks show it as a pane inside the main window.
"""

import json
import logging
import os
import socket
import sys
import threading
import time
import urllib.parse
from pathlib import Path

LOG = logging.getLogger("arena.desktop")


def find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def start_flask(port: int):
    from arena.web.app import app
    app.run(host="127.0.0.1", port=port, debug=False, threaded=True, use_reloader=False)


def wait_port(port: int, timeout: float = 10.0) -> bool:
    end = time.time() + timeout
    while time.time() < end:
        try:
            socket.create_connection(("127.0.0.1", port), timeout=0.2).close()
            return True
        except OSError:
            time.sleep(0.1)
    return False


def _flag_value(name):
    """Value after a --flag in argv, or None (flags: --profile, --mode, --background)."""
    if name in sys.argv:
        i = sys.argv.index(name)
        if i + 1 < len(sys.argv) and not sys.argv[i + 1].startswith("--"):
            return sys.argv[i + 1]
    return None


def _switch_profile(port, wanted):
    """--profile <id|email>: activate that account on the local server before the UI loads."""
    try:
        import requests
        from arena.web import app as web_app
        headers = {"X-Arena-Token": web_app._API_TOKEN}
        data = requests.get(f"http://127.0.0.1:{port}/api/accounts", headers=headers, timeout=5).json()
        items = data.get("accounts") if isinstance(data, dict) else data
        for acc in items or []:
            if str(acc.get("id")) == wanted or str(acc.get("email") or "").lower() == wanted.lower():
                if acc.get("current"):
                    return
                requests.post(f"http://127.0.0.1:{port}/api/accounts/switch",
                              json={"id": acc.get("id"), "account_id": acc.get("id")}, headers=headers, timeout=15)
                return
        LOG.info("profile %r not found", wanted)
    except Exception:
        LOG.exception("profile switch failed")


_QUICK_HTML = """<!doctype html><html><head><meta charset="utf-8"><title>Quick ask</title>
<style>
 body{margin:0;background:#14171a;color:#e9f2ea;font-family:Segoe UI,system-ui,sans-serif}
 .wrap{padding:14px}
 h1{font-size:13px;margin:0 0 8px;font-weight:650}
 textarea{width:100%;box-sizing:border-box;height:74px;resize:none;border-radius:8px;border:1px solid #3b4140;background:#1d2221;color:#e9f2ea;padding:8px;font:inherit}
 .row{display:flex;justify-content:flex-end;gap:8px;margin-top:10px}
 button{border-radius:7px;border:1px solid #8dd39a;background:#b8e5bf;color:#17251a;padding:6px 14px;font-weight:650;cursor:pointer}
 button.q{background:#262a2b;color:#cfd8d2;border-color:#3b4140}
</style></head><body><div class="wrap">
<h1>Quick ask \u2014 starts a new chat</h1>
<textarea id="t" placeholder="Ask something\u2026 (Enter to send, Shift+Enter for a new line)"></textarea>
<div class="row"><button class="q" id="cancel">Cancel</button><button id="send">Send</button></div>
</div><script>
 const t=document.getElementById('t'); t.focus();
 const go=()=>{ const v=t.value.trim(); if(!v) return; window.pywebview.api.submit(v); };
 document.getElementById('send').onclick=go;
 document.getElementById('cancel').onclick=()=>window.pywebview.api.submit('');
 t.addEventListener('keydown',e=>{ if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();go();} if(e.key==='Escape') window.pywebview.api.submit(''); });
</script></body></html>"""


class _QuickAskApi:
    """js_api of the quick-ask window; submit('') just closes it."""

    def __init__(self, tray):
        self._tray = tray
        self._window = None

    def submit(self, text):
        self._tray._quick_submit(text)

class Tray:
    """System-tray icon + global Ctrl+Alt+A show/hide hotkey (Windows, best effort).

    Optional chrome around the window: every failure is logged and the app
    keeps running without it. With the tray on, closing the window hides it
    instead of quitting; Quit lives in the tray menu."""

    def __init__(self, window, icon_path):
        self.window = window
        self.icon_path = icon_path
        self.icon = None
        self.visible = True
        self.quitting = False
        self.quick_window = None

    def show_window(self):
        self.visible = True
        try:
            self.window.show()
            self.window.restore()
        except Exception:
            pass

    def hide_window(self):
        self.visible = False
        try:
            self.window.hide()
        except Exception:
            pass

    def toggle(self):
        self.hide_window() if self.visible else self.show_window()

    def hotkey_pressed(self):
        # Ctrl+Alt+A: hide when open; otherwise open the quick-ask window
        # (the fastest path from anywhere in Windows to a new chat).
        self.hide_window() if self.visible else self.open_quick_ask()

    def notify(self, title, text, kind="done"):
        # Questions always toast (the agent is blocked on the user);
        # finished generations only when the window is tucked away.
        if kind == "done" and self.visible:
            return
        try:
            if self.icon:
                self.icon.notify(text, title)
        except Exception:
            LOG.exception("tray notify failed")

    def open_quick_ask(self):
        try:
            import webview
            if self.quick_window is not None:
                try:
                    self.quick_window.show()
                    self.quick_window.restore()
                    return
                except Exception:
                    self.quick_window = None
            api = _QuickAskApi(self)
            self.quick_window = webview.create_window(
                "Quick ask - Arena Desktop", html=_QUICK_HTML, js_api=api,
                width=560, height=200, resizable=False, on_top=True)
            api._window = self.quick_window
        except Exception:
            LOG.exception("quick ask unavailable")
            self.show_window()

    def _quick_submit(self, text):
        text = (text or "").strip()
        if self.quick_window is not None:
            try:
                self.quick_window.destroy()
            except Exception:
                pass
            self.quick_window = None
        if not text:
            return
        self.show_window()
        try:
            import json as _json
            self.window.evaluate_js(
                "window.__quickAsk && window.__quickAsk(" + _json.dumps(text) + ")")
        except Exception:
            LOG.exception("quick ask handoff failed")

    def on_closing(self):
        if self.quitting:
            return True
        self.hide_window()
        return False  # cancel the close; the app lives in the tray

    def quit(self):
        self.quitting = True
        try:
            if self.icon:
                self.icon.stop()
        except Exception:
            pass
        os._exit(0)

    def start(self) -> bool:
        try:
            import pystray
            from PIL import Image
            image = Image.open(self.icon_path)
        except Exception:
            LOG.exception("tray unavailable (pystray/Pillow/icon)")
            return False
        menu = pystray.Menu(
            pystray.MenuItem("Open Arena Desktop", lambda *_: self.show_window(), default=True),
            pystray.MenuItem("Quick ask...", lambda *_: self.open_quick_ask()),
            pystray.MenuItem("Hide", lambda *_: self.hide_window()),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Quit", lambda *_: self.quit()),
        )
        self.icon = pystray.Icon("Arena Desktop", image, "Arena Desktop", menu)
        try:
            from arena.web import app as _webapp
            _webapp.NOTIFY_HOOK = lambda title, text, kind="done": self.notify(title, text, kind)
        except Exception:
            LOG.exception("notify hook wiring failed")
        threading.Thread(target=self._run_icon, daemon=True).start()
        if sys.platform == "win32":
            threading.Thread(target=self._hotkey_loop, daemon=True).start()
        return True

    def _run_icon(self):
        try:
            run_detached = getattr(self.icon, "run_detached", None)
            if run_detached:
                run_detached()
            else:
                self.icon.run()
        except Exception:
            LOG.exception("tray icon stopped")

    def _hotkey_loop(self):
        try:
            import ctypes
            from ctypes import wintypes
            MOD_ALT, MOD_CONTROL, VK_A, WM_HOTKEY = 0x0001, 0x0002, 0x41, 0x0312
            user32 = ctypes.WinDLL("user32")
            if not user32.RegisterHotKey(None, 1, MOD_CONTROL | MOD_ALT, VK_A):
                LOG.info("global hotkey Ctrl+Alt+A could not be registered")
                return
            msg = wintypes.MSG()
            while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                if msg.message == WM_HOTKEY:
                    self.hotkey_pressed()
        except Exception:
            LOG.exception("global hotkey unavailable")


def _dialog(name: str):
    import webview
    fd = getattr(webview, "FileDialog", None)
    if fd is not None:
        return getattr(fd, name)
    return getattr(webview, f"{name}_DIALOG")


class JsBridge:
    """js_api of the main window (local UI only). pywebview exposes every public attribute to JS
    and walks it recursively, so the window reference must stay private."""

    def __init__(self):
        self._window = None

    def open_file_dialog(self, file_types=None):
        ft = tuple(file_types or ()) + ("All files (*.*)",)
        result = self._window.create_file_dialog(_dialog("OPEN"), allow_multiple=True, file_types=ft)
        return list(result or [])

    def save_file_dialog(self, filename=""):
        result = self._window.create_file_dialog(_dialog("SAVE"), save_filename=filename)
        if isinstance(result, (list, tuple)):
            result = result[0] if result else None
        return result or None

    def choose_folder(self):
        result = self._window.create_file_dialog(_dialog("FOLDER"))
        return (result[0] if result else None) if isinstance(result, (list, tuple)) else result


def _user32():
    import ctypes
    from ctypes import wintypes as w
    u = ctypes.WinDLL("user32")  # own instance: argtypes set here do not leak into other ctypes users
    u.EnumProc = ctypes.WINFUNCTYPE(w.BOOL, w.HWND, w.LPARAM)
    u.EnumWindows.argtypes = [u.EnumProc, w.LPARAM]
    u.GetWindowThreadProcessId.argtypes = [w.HWND, ctypes.POINTER(w.DWORD)]
    u.GetWindowTextW.argtypes = [w.HWND, w.LPWSTR, ctypes.c_int]
    u.GetWindowLongW.argtypes = [w.HWND, ctypes.c_int]
    u.SetWindowLongW.argtypes = [w.HWND, ctypes.c_int, ctypes.c_long]
    u.SetParent.argtypes = [w.HWND, w.HWND]
    u.SetParent.restype = w.HWND
    u.ShowWindowAsync.argtypes = [w.HWND, ctypes.c_int]
    u.GetClientRect.argtypes = [w.HWND, ctypes.POINTER(w.RECT)]
    u.SetWindowPos.argtypes = [w.HWND, w.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, w.UINT]
    return u


class Dock:
    """Hosts the arena.ai window as a pane on the right of the main window (Win32 SetParent),
    like a built-in browser, so sign-in and human checks never open a second window."""

    SHARE = 0.55  # part of the main window's width the pane takes

    def __init__(self, main_win, pane_win):
        self.main, self.pane = main_win, pane_win
        self.h_main = self.h_pane = None
        self.visible = False
        self._share = None
        self._closing = False
        self.u = _user32()

    def _find(self, title):
        import ctypes
        from ctypes import wintypes
        found, pid = [], os.getpid()

        def each(h, _):
            owner = wintypes.DWORD()
            self.u.GetWindowThreadProcessId(h, ctypes.byref(owner))
            buf = ctypes.create_unicode_buffer(256)
            self.u.GetWindowTextW(h, buf, 256)
            if owner.value == pid and buf.value == title:
                found.append(h)
            return True

        self.u.EnumWindows(self.u.EnumProc(each), 0)
        return found[0] if found else None

    def _embed(self) -> bool:
        if self.h_pane:
            return True
        self.h_main = self.h_main or self._find(self.main.title)
        pane = self._find(self.pane.title)
        if not (self.h_main and pane):
            return False
        style = self.u.GetWindowLongW(pane, -16) & 0xFFFFFFFF  # GWL_STYLE
        style &= ~(0x80000000 | 0x00C00000 | 0x00040000 | 0x00080000 | 0x00020000 | 0x00010000)  # popup, caption, frame, buttons
        style |= 0x40000000 | 0x04000000  # WS_CHILD | WS_CLIPSIBLINGS
        self.u.SetWindowLongW(pane, -16, style - (1 << 32) if style >= 1 << 31 else style)
        self.u.SetParent(pane, self.h_main)
        self.h_pane = pane
        return True

    def layout(self):
        if not (self.visible and self.h_pane):
            return
        import ctypes
        from ctypes import wintypes
        r = wintypes.RECT()
        self.u.GetClientRect(self.h_main, ctypes.byref(r))
        w, h = r.right, r.bottom
        pw = min(w, max(int(w * self.SHARE), 560))
        self.u.SetWindowPos(self.h_pane, None, w - pw, 0, pw, h, 0x0040 | 0x0020)  # HWND_TOP, SWP_SHOWWINDOW | SWP_FRAMECHANGED
        share = round(pw / max(w, 1), 4)
        if share != self._share:  # resizing fires often: only tell the page when the split changes
            self._share = share
            self.main.evaluate_js("window.arenaPane && arenaPane(true, %.4f)" % share)

    def prime(self):
        """Find the main window handle early: the closing handler must not send window messages."""
        if not self.h_main:
            self.h_main = self._find(self.main.title)

    def vanish(self):
        """Close in two steps: hide the window at once, then tear WebView2 down out of sight.
        pywebview runs this on a worker while the GUI thread waits, so the work happens on a new thread."""
        if self._closing:
            return None
        self._closing = True
        threading.Thread(target=self._quit, daemon=True).start()
        return False  # cancel this close; _quit closes for real

    def _quit(self):
        try:
            self.main.hide()
        finally:
            self.main.destroy()

    def show(self) -> bool:
        try:
            if not self._embed():
                return False
            self.visible = True
            self.pane.show()
            self.layout()
            return True
        except Exception:
            logging.getLogger("arena.desktop").exception("could not dock the arena.ai pane")
            self.visible = False
            return False

    def hide(self):
        self.visible = False
        self._share = None
        self.pane.hide()
        try:
            self.main.evaluate_js("window.arenaPane && arenaPane(false)")
        except Exception:
            pass


def _ensure_webview2() -> None:
    """Note a missing WebView2 Runtime in the log — and never block startup.

    This used to raise a modal ``MessageBoxW`` on the main thread before any
    window existed. A modal dialog blocks the only thread that can create the
    UI, and it is invisible while there is no window: the app then sits behind
    an unseen prompt forever — no window, no log line, no reaction to closing.
    That is exactly "it just freezes". Detection is advisory now.
    """
    if not sys.platform.startswith("win"):
        return
    try:
        from arena import components
        found = [c for c in components.detect() if c["id"] == "webview2"]
        if found and found[0]["installed"]:
            LOG.info("WebView2 runtime version: %s", found[0].get("version") or "unknown")
            return
    except Exception:
        LOG.info("WebView2 detection failed; starting anyway", exc_info=True)
        return
    LOG.warning("WebView2 runtime not detected; the window is still attempted "
                "(if nothing opens, install the Microsoft Edge WebView2 Runtime)")


def _install_crash_logging() -> None:
    """Make a fatal error visible in desktop.log instead of a silent exit."""
    def on_uncaught(exc_type, exc_value, exc_tb):
        if issubclass(exc_type, KeyboardInterrupt):
            return
        LOG.critical("unhandled exception", exc_info=(exc_type, exc_value, exc_tb))

    def on_thread(args):
        if args.exc_type is SystemExit:
            return
        LOG.critical("unhandled exception in thread %s", getattr(args.thread, "name", "?"),
                     exc_info=(args.exc_type, args.exc_value, args.exc_traceback))

    try:
        sys.excepthook = on_uncaught
        threading.excepthook = on_thread
    except Exception:
        LOG.info("crash logging could not be installed")

    # Python hooks never see a native crash: a COM access violation kills the
    # process outright, the log just stops mid-line and nothing is written.
    # faulthandler writes the C-level stack to its own file in that case, and
    # also on any hard abort — the only evidence such a death leaves behind.
    try:
        import faulthandler
        from arena.config import CONFIG_DIR
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        crash_path = CONFIG_DIR / "desktop-crash.log"
        crash_file = open(crash_path, "a", encoding="utf-8", buffering=1)
        faulthandler.enable(file=crash_file, all_threads=True)
        # A freeze that holds the GIL — any blocking .NET call made from Python
        # while pythonnet keeps it — stops EVERY python thread: the log
        # watchdog, the heartbeat, all of them. Only C-level code still runs,
        # and faulthandler's timer is C code on its own thread, so this repeated
        # dump keeps working in exactly that case and names the blocked thread.
        try:
            faulthandler.dump_traceback_later(45, repeat=True, file=crash_file)
            LOG.info("freeze watchdog armed: a stack dump every 45 s")
        except Exception:
            LOG.info("repeated stack dump could not be armed")
        LOG.info("native crash handler armed: %s", crash_path)
    except Exception:
        LOG.info("faulthandler could not be armed")


def _pywebview():
    """pywebview, imported where it is needed.

    Module-level on purpose for this one function: `make_google_window` has to
    be testable without a GUI, and a local import inside it would make the
    fallback untestable -- which is how it went unverified in the first place.
    """
    import webview
    return webview


def _single_use() -> bool:
    """True when the sign-in windows are the single-use kind.

    Those windows are closed (profile deleted) after a sign-in instead of being
    hidden and reused, and the engines need to know that *before* the window
    exists: the decision is made on the first click.
    """
    return os.environ.get("ARENA_GOOGLE_WINDOW", "").lower() not in ("webview2", "pywebview")


def make_google_window(user_data_dir: str, build_timeout: float = 8.0):
    """The Google pane's window, in order of preference.

    Split out of `main()` so the choice can be tested at all: it used to be
    inline, which meant the fallback was written on faith and never exercised.

    * default -- the person's own browser (see `arena/browserwindow.py`). No
      message loop to obey, no COM apartment, no `shown` gate: the class of bug
      that froze the app simply does not exist there.
    * `ARENA_GOOGLE_WINDOW=webview2` -- the in-app WebView2 host, kept because
      it is the only path that shows Google inside the app window;
    * `ARENA_GOOGLE_WINDOW=pywebview` -- the oldest path.

    Each step falls through to the next when it cannot start, rather than
    leaving the pane with a window that will never appear.
    """
    choice = os.environ.get("ARENA_GOOGLE_WINDOW", "").lower()
    # The browser is the default now. WebView2 stays behind a switch because it
    # is the only path that can show Google *inside* the app, and someone may
    # still want it; but every freeze this app has had came from that control,
    # not from the browser.
    if choice not in ("pywebview", "webview2"):
        try:
            from arena import browserwindow
            win = browserwindow.create_google_window(user_data_dir=user_data_dir)
            if win is not None:
                if win.wait_built(12.0):
                    LOG.info("google window: using the default browser "
                             "(debugging port is up)")
                    return win
                why = (win.state() or {}).get("build_error") or "timed out"
                LOG.warning("google window: the browser did not answer (%s); "
                            "Google mode stays on plain HTTPS", why)
                try:
                    win.destroy()
                except Exception:
                    pass
        except Exception:
            LOG.exception("google window: browser host failed; falling back")

    if choice in ("webview2", "both"):
        # Falling back to WebView2 automatically was wrong: it is the component
        # that killed this app (native faults, no traceback, an empty log). When
        # the browser cannot start, the honest answer is "no window" -- Google
        # mode still works over plain HTTPS -- rather than starting the one
        # subsystem known to bring the process down.
        try:
            from arena import webwindow
            win = webwindow.create_google_window(user_data_dir=user_data_dir)
            if win is not None:
                # The host builds on its own thread, so "created" and "works"
                # are different facts. Ask once, briefly.
                if win.wait_built(build_timeout):
                    LOG.info("google window: using the direct WebView2 host")
                    return win
                why = (win.state() or {}).get("build_error") or "timed out"
                LOG.warning("google window: direct host did not build (%s); "
                            "falling back to pywebview", why)
        except Exception:
            LOG.exception("google window: direct host failed; falling back")
    if choice == "pywebview":
        win = _pywebview().create_window(
            "Google AI mode - Arena Desktop", "about:blank", width=1100,
            height=820, x=160, y=110, hidden=True, background_color="#000000")
        LOG.info("google window: using pywebview")
        return win
    # No window at all. That is a working state: Google chats go over plain
    # HTTPS with saved cookies, and the pane says "Google window is
    # unavailable" instead of pretending. Starting WebView2 here is what killed
    # the app on a machine without a browser.
    LOG.info("google window: none (no browser found); Google mode uses HTTPS")
    return None


def make_arena_window(user_data_dir: str):
    """The arena.ai sign-in window: a real browser, like the Google one.

    Same reasoning as `make_google_window`: an in-app WebView cannot take a
    person through arena's own sign-in (Cloudflare, OAuth, passkeys), and every
    freeze this app has had came from that control. The cookies are read over
    the same DevTools protocol the CLI already used for arena.ai.

    `ARENA_ARENA_WINDOW=pywebview` brings the old window back without a rebuild.
    """
    if os.environ.get("ARENA_ARENA_WINDOW", "").lower() != "pywebview":
        try:
            from arena import browserwindow
            win = browserwindow.create_arena_window(user_data_dir=user_data_dir)
            if win is not None:
                if win.wait_built(12.0):
                    LOG.info("arena window: using the default browser")
                    return win
                why = (win.state() or {}).get("build_error") or "timed out"
                LOG.warning("arena window: the browser did not answer (%s); "
                            "falling back to the in-app window", why)
                try:
                    win.destroy()
                except Exception:
                    pass
        except Exception:
            LOG.exception("arena window: browser host failed; falling back")
    # `contracts` is imported inside `main()`, which does not cover this
    # function -- so the fallback raised NameError the moment it was reached
    # (see desktop-crash-7.log). Imported here, at the point of use.
    from arena import contracts
    win = _pywebview().create_window(
        "arena.ai - Arena Desktop", contracts.ORIGIN, width=1000, height=760,
        x=120, y=120, hidden=True, background_color="#242422",
        js_api=ENGINE.bridge())
    LOG.info("arena window: using the in-app window")
    return win


def main():
    from arena import deep_links


    deep_link_arg = deep_links.find_deep_link_arg(sys.argv[1:])
    if deep_link_arg:
        try:
            deep_links.parse_deep_link(deep_link_arg)
        except ValueError:
            # A malformed custom-protocol invocation should still show the
            # app, but it must not reach the composer or chat router.
            deep_link_arg = "arenadesktop://open"
        if deep_links.forward_deep_link(deep_link_arg):
            return

    import webview
    from arena import contracts
    from arena import google_ai
    from arena.config import CONFIG_DIR
    from arena.engine import ENGINE
    from arena.web import app as web_app

    contracts.load_overrides()
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    # encoding="utf-8" is not optional: on Windows the default is cp1251/aNsi,
    # and any non-ASCII text in a trace line is silently written as rubbish.
    logging.basicConfig(filename=str(CONFIG_DIR / "desktop.log"), level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s",
                        encoding="utf-8")
    logging.getLogger("werkzeug").setLevel(logging.WARNING)  # keep the log to what the app does
    _install_crash_logging()

    # Bind every child process (WebView2's msedgewebview2.exe helpers) to this
    # process. They load DLLs from the bootloader's %TEMP%\_MEIxxxx folder and
    # outlive it after a hard crash or the os._exit on window close; the folder
    # then stays locked and PyInstaller shows "Failed to remove temporary
    # directory". A kill-on-close Job Object removes that dialog entirely.
    # Runs after logging is set up so the outcome is actually visible.
    try:
        from arena import procguard
        if procguard.keep_children_inside_job():
            LOG.info("process guard: children bound to this process (job object)")
        else:
            LOG.info("process guard: not applied (not Windows, or already in a job)")
    except Exception:
        LOG.exception("process guard failed to start")
    # Diagnostics: every traced call is written with entry, exit and cost, and a
    # watchdog dumps all thread stacks when something stops returning. This is
    # what turns "it freezes somewhere in the cookies" into a named function.
    try:
        from arena import diag
        diag.install()
    except Exception:
        LOG.exception("could not start diagnostics")
    if deep_links.register_protocol():
        LOG.info("registered arenadesktop:// for this Windows user")
    instance_token = deep_links.new_instance_token()
    web_app.INSTANCE_TOKEN = instance_token
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("arena.ai.desktop")
        except Exception:
            pass

    port = int(os.environ.get("ARENA_PORT") or 0) or find_free_port()
    threading.Thread(target=start_flask, args=(port,), daemon=True).start()
    wait_port(port)
    try:
        deep_links.write_instance(port, instance_token)
    except Exception:
        LOG.exception("could not publish the deep-link instance file")
    profile = _flag_value("--profile")
    if profile:
        _switch_profile(port, profile)

    base = Path(sys._MEIPASS) if getattr(sys, "frozen", False) else Path(__file__).resolve().parent.parent
    ico = base / "assets" / "arena-cli.ico"

    # Headless: start the server and stop before any GUI exists.
    #
    # This is what the launch check uses. Under Wine the GUI layer cannot start
    # at all (no .NET, no WinForms), and `webview.start()` kills the process
    # about a second after Flask comes up -- so an HTTP check raced the death
    # and passed or failed depending on machine speed. The server half is
    # testable; the window half never was under Wine, and this says so instead
    # of pretending.
    if os.environ.get("ARENA_NO_GUI"):
        LOG.info("headless mode: the server is up, no window will be created")
        print(f" * Arena Desktop is serving on http://127.0.0.1:{port}/",
              flush=True)
        while True:
            time.sleep(3600)

    _ensure_webview2()
    webview.settings["ALLOW_DOWNLOADS"] = True  # zip and media downloads from the UI
    from arena.config import load_config as _load_cfg
    cfg = _load_cfg()
    background = "--background" in sys.argv
    start_url = f"http://127.0.0.1:{port}/"
    mode_flag = _flag_value("--mode")
    query = []
    if mode_flag:
        query.append(("mode", mode_flag))
    if deep_link_arg:
        query.append(("deeplink", deep_link_arg))
    if query:
        start_url += "?" + urllib.parse.urlencode(query)
    bridge = JsBridge()
    main_win = webview.create_window("Arena Desktop", start_url, width=1280, height=840,
                                     min_size=(860, 600), background_color="#242422", text_select=True,
                                     js_api=bridge, hidden=background)
    bridge._window = main_win
    from arena.lazywindow import LazyWindow
    def _arena_factory():
        if os.environ.get("ARENA_ARENA_WINDOW", "").lower() == "pywebview":
            return make_arena_window(str(CONFIG_DIR / "arena-browser"))
        from arena.ephemeral import create_arena_sign_in_window
        win = create_arena_sign_in_window()
        if win is not None:
            LOG.info("arena window: single-use browser window (temporary profile)")
            return win
        return make_arena_window(str(CONFIG_DIR / "arena-browser"))

    arena_win = LazyWindow(_arena_factory, name="arena window",
                           ephemeral=_single_use())
    ENGINE.attach(arena_win, main_win)
    # Google AI mode chats run over plain HTTPS (arena.google_http), so this
    # window starts blank and stays blank until something actually needs it:
    # signing in, pasting cookies, or a human check Google asks for. Nothing
    # hidden talks to Google in the background any more.
    # The Google pane now has its own window implementation (arena/webwindow).
    # pywebview's second window could not be made reliable: its calls are gated
    # on a `shown` event that only the message loop sets, so any call made while
    # the window is hidden parks for 20 s with the GIL held -- the freeze that
    # survived three rounds of patching. The replacement runs its own STA thread
    # and its own message loop, marshals everything with BeginInvoke and never
    # waits on an event it cannot set itself.
    #
    # ARENA_GOOGLE_WINDOW=pywebview restores the old behaviour without a rebuild.
    # The window is built on first use, not now. With WebView2 "created" was
    # invisible; a browser cannot be, and opening google.com on launch -- before
    # the person asked for anything -- is exactly what this avoids. Every
    # entry point that needs the window (sign-in, open, cookie paste) goes
    # through the same lazy object, so nothing else changes.
    #
    # The profile folder is deliberately NOT `webview`. That one belongs to the
    # main window's WebView2 (see `storage` below), and a Chromium started with
    # `--user-data-dir` pointing at a live WebView2 profile is a native
    # conflict: the app died the moment the browser opened, with nothing in
    # desktop.log, because the crash was in native code rather than Python.
    # Single-use sign-in window: a throwaway browser profile per sign-in,
    # closed and deleted once the cookies are out. This is the format the
    # person asked for ("what Arena uses for Google sign-in: starts fast and
    # signs in normally") and the reason for it is in arena/ephemeral.py --
    # a persistent profile is what kept a half-finished sign-in alive and made
    # the jar read empty under --incognito.
    #
    # ARENA_GOOGLE_WINDOW=webview2|pywebview keeps the old paths.
    def _google_factory():
        if os.environ.get("ARENA_GOOGLE_WINDOW", "").lower() in ("webview2", "pywebview"):
            return make_google_window(str(CONFIG_DIR / "google-browser"))
        from arena.ephemeral import create_google_sign_in_window
        win = create_google_sign_in_window()
        if win is not None:
            LOG.info("google window: single-use browser window (temporary profile)")
            return win
        return make_google_window(str(CONFIG_DIR / "google-browser"))

    google_win = LazyWindow(_google_factory, name="google window",
                            ephemeral=_single_use())
    google_ai.ENGINE.attach(google_win, main_win)
    web_app.GOOGLE_ENGINE = google_ai.ENGINE
    # Keep the Arena WebView as a genuine top-level window. Login, OAuth and
    # human checks need a separate window rather than a reparented child view.
    ENGINE.dock = None
    def _on_main_closed(*_a):
        # `os._exit` is how the process ends when the main window goes away,
        # and it leaves nothing behind. A person reporting "the app closed"
        # then has an empty log and no way for anyone to tell a deliberate exit
        # from a crash -- which is exactly what happened when the browser
        # window opened on the main window's WebView2 profile.
        LOG.critical("main window closed: the process is exiting now "
                     "(stack follows, so a silent crash is still visible)")
        import traceback
        for line in traceback.format_stack()[-8:]:
            LOG.critical("  %s", line.strip())
        os._exit(0)

    main_win.events.closed += _on_main_closed
    # Optional tray life: close hides to the tray; Ctrl+Alt+A toggles the window.
    tray = None
    if cfg.get("tray_enabled") or background:
        tray = Tray(main_win, base / "assets" / "logo.png")
        tray.visible = not background
        if tray.start():
            main_win.events.closing += tray.on_closing
        elif background:
            main_win.show()  # no tray to bring it back from: never start invisible

    def handle_deep_link(payload):
        try:
            if tray is not None:
                tray.show_window()
            else:
                main_win.show()
                main_win.restore()
            main_win.evaluate_js(
                "window.__arenaDeepLink && window.__arenaDeepLink(" + json.dumps(payload) + ")")
            return True
        except Exception:
            LOG.exception("deep link window handoff failed")
            return False

    web_app.DEEP_LINK_HOOK = handle_deep_link

    storage = CONFIG_DIR / "webview"
    storage.mkdir(parents=True, exist_ok=True)
    webview.start(gui="edgechromium", private_mode=False, storage_path=str(storage),
                  icon=str(ico) if ico.exists() else None, debug=bool(os.environ.get("ARENA_DEBUG")))
    os._exit(0)


if __name__ == "__main__":
    main()
