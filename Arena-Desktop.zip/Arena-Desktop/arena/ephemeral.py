"""The one-time sign-in window: a throwaway browser, then a jar, then gone.

What the person asked for
-------------------------
"Switch to the one-time-window format — I don't know what the type is called,
but it is what Arena uses for Google sign-in: it starts fast and signs in
normally."

They are describing an **ephemeral browser instance**: a fresh Chromium is
launched straight onto the sign-in page, the person signs in once, the cookies
are read out, and the browser is closed. Nothing is kept on disk between runs,
so there is no stale profile to fight with — which is where every previous
failure lived:

* a profile that survived a half-finished sign-in, so the next attempt opened
  inside the old session;
* a profile that was refused (`_safe_profile`) and left the browser starting
  without one;
* an incognito flag on a *persistent* profile: the cookies live in a throwaway
  session, so the jar reads empty even after a successful sign-in — and the app
  concludes that nothing happened.

Why the old window was slow and why it doubled
----------------------------------------------
Both came from the same shape of the code, not from Chromium:

* the window was created on first use, *then* asked to navigate, *then* waited
  for a page to confirm. Measured on Windows: 8.8 s from click to navigation.
  A throwaway instance goes to the URL on its very first command line, so the
  page starts loading before the app has even found the debugging port;
* the arena window divided in two because the browser was started on
  `about:blank` and then navigated over CDP while the app had also been told
  (by pywebview's model) to "show" it. A single-use instance is started with
  exactly one URL and never re-navigated, so there is one window.

What this class is not
----------------------
It is not a new transport. `BrowserWindow` already speaks the DevTools
protocol and already knows how to read a jar; this is the same window with the
launch policy the person asked for:

============================  =============================================
profile                       a fresh throwaway folder per sign-in, deleted
                              when the window closes
first URL                     the sign-in page itself, on the command line
navigation afterwards         never needed: the page is where it must be
cookies                       the browser's own default store, so the jar
                              that is read is the jar that signed in
closing                       the browser process is closed as soon as the
                              cookies are out
============================  =============================================
"""

from __future__ import annotations

import logging
import os
import shutil
import tempfile
import threading
import time

from arena.browserwindow import (ARENA_DOMAINS, ARENA_URL, GOOGLE_DOMAINS,
                                 HOME_URL, BrowserWindow, EngineBrowserWindow)

LOG = logging.getLogger("arena.ephemeral")


def _same_origin(a: str, b: str) -> bool:
    """True when two URLs address the same site, ignoring slash and query."""
    def bare(value: str) -> str:
        text = str(value or "").strip().lower()
        text = text.split("#", 1)[0].split("?", 1)[0]
        return text.rstrip("/")
    left, right = bare(a), bare(b)
    return bool(left) and left == right


def _domains_of(window) -> tuple:
    """The sites this window is allowed to be on."""
    for holder in (window, getattr(window, "_window", None)):
        domains = getattr(holder, "domains", None)
        if domains:
            return tuple(str(d).lower() for d in domains)
    return ()


class EphemeralSignIn:
    """One sign-in, one browser, one profile, closed afterwards.

    The surface is the same as `EngineBrowserWindow`, so the engines do not
    change: it can be attached exactly like a normal window.
    """

    is_browser = True
    ephemeral = True

    def __init__(self, url: str = HOME_URL, *, domains: tuple[str, ...] = GOOGLE_DOMAINS,
                 title_marker: str = "google"):
        self.url = url
        self._window = BrowserWindow(url, user_data_dir=tempfile.mkdtemp(
            prefix="arena-signin-"), private=False, domains=domains,
            title_marker=title_marker)
        # Nothing is kept between sign-ins: this is the whole point.
        self._window.open_url_on_start = url
        self.events = self._window.events
        self._closed = False

    # -- the surface the engine uses -------------------------------------
    def wait_built(self, timeout: float = 8.0) -> bool:
        return self._window.wait_built(timeout)

    def evaluate_js(self, script, *a, **kw):
        return self._window.evaluate_js(script, *a, **kw)

    def evaluate_js_value(self, script, *a, **kw):
        return self._window.evaluate_js_value(script, *a, **kw)

    def run_js(self, script, *a, **kw):
        return self._window.run_js(script, *a, **kw)

    def load_url(self, url):
        """Navigate only if the throwaway window is not already there.

        A single-use window starts on the sign-in page; re-navigating it is
        what used to produce a second window and a second copy of the page.

        The check compares origins, not whole strings. It used to compare them
        character for character, which meant it never matched once:

        * Arena asks for ``https://arena.ai`` (``contracts.ORIGIN``) while the
          command line carries ``https://arena.ai/``;
        * Google asks for ``https://www.google.com/?authuser=0&hl=ru`` while
          the command line carries ``https://www.google.com/``.

        Both are the same page. Treating them as different sent every press
        down the navigation path, where a tab that had not yet appeared in
        ``/json`` was answered with ``/json/new`` -- the second window.
        """
        target = str(url or "").strip()
        if not target:
            return False
        starting = getattr(self._window, "open_url_on_start", None)
        if starting and _same_origin(starting, target):
            # The page is already on the command line: Chromium is loading it
            # right now, or is already there. Asking again would be a second
            # load of the same page.
            return True
        if self._window.is_ready():
            current = str(self._window.host() or "")
            # On our own site: the window is where it should be. The old test
            # was `current in self.url`, which missed the very case it was
            # written for -- "www.arena.ai" is not a substring of
            # "https://arena.ai/", so a signed-in page looked like a stray one.
            if current and any(
                    current == d or current.endswith("." + d)
                    for d in _domains_of(self._window)):
                return True
        return self._window.load_url(target)

    def show(self):
        return self._window.show()

    def hide(self):
        return None

    def resize(self, width, height):
        return None

    def move(self, x, y):
        return None

    def restore(self):
        return None

    def clear_cookies(self):
        return self._window.clear_cookies()

    def cookie_tuples(self, *a, **kw):
        return self._window.cookie_tuples(*a, **kw)

    def get_cookies(self, *a, **kw):
        return self._window.get_cookies(*a, **kw)

    @property
    def host(self):
        return self._window.host()

    @property
    def native(self):
        return None

    @property
    def webview(self):
        return None

    def is_ready(self) -> bool:
        return self._window.is_ready()

    def state(self) -> dict:
        state = dict(self._window.state() or {})
        state["ephemeral"] = True
        state["profile"] = "temporary (deleted when the window closes)"
        return state

    # -- lifecycle -------------------------------------------------------
    def close_and_forget(self) -> None:
        """Close the browser and delete its profile.

        Called the moment the cookies are out: the jar has been read, the
        session now lives in the app, and leaving a browser open would only
        invite the next press to land inside a finished sign-in.
        """
        if self._closed:
            return
        self._closed = True
        profile = self._window.user_data_dir
        try:
            self._window.destroy()
        except Exception:
            LOG.info("ephemeral window: could not close the browser cleanly")
        # The profile can only go once the browser has let go of it. `destroy()`
        # asks the process to terminate and returns; on Windows the folder stays
        # locked while it lives, and the launch thread can still be writing into
        # it, which recreates the directory right after a successful delete --
        # that is the "single-use profile survived" the tests caught about one
        # run in four.
        # Two things must stop before the folder can go: the browser process
        # (it holds the files) and the launch thread (it can still be inside
        # `_safe_profile`, which makes the profile folder). Waiting for the
        # process alone left an empty `arena-signin-*` folder behind roughly
        # one run in fifty -- the thread created it after `rmtree` had run.
        proc = getattr(self._window, "_proc", None)
        launch = getattr(self._window, "_thread", None)
        end = time.time() + 3.0
        while proc is not None and proc.poll() is None and time.time() < end:
            time.sleep(0.05)
        if launch is not None and launch is not threading.current_thread():
            launch.join(max(0.0, end - time.time()))
        if profile:
            for _attempt in range(3):
                try:
                    shutil.rmtree(profile)
                    break
                except FileNotFoundError:
                    break
                except OSError:
                    # The browser needs a moment to let go of its files.
                    time.sleep(0.4)
            if os.path.isdir(profile):
                LOG.info("ephemeral window: profile left behind at %s", profile)

    def destroy(self) -> None:
        self.close_and_forget()


def create_google_sign_in_window() -> EphemeralSignIn | None:
    """The throwaway Google sign-in window, or None where there is no GUI."""
    from arena.browserwindow import IS_WINDOWS
    if not IS_WINDOWS:
        return None
    return EphemeralSignIn(HOME_URL, domains=GOOGLE_DOMAINS, title_marker="google")


def create_arena_sign_in_window() -> EphemeralSignIn | None:
    """The same, for arena.ai."""
    from arena.browserwindow import IS_WINDOWS
    if not IS_WINDOWS:
        return None
    return EphemeralSignIn(ARENA_URL, domains=ARENA_DOMAINS, title_marker="arena")
