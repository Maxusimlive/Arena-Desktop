"""A window that is not opened until something actually needs it.

Why this exists
---------------
The Google pane's window is built once at startup and handed to the engine. For
WebView2 that was free: the host created a *hidden* form and nothing appeared on
screen. A real browser cannot hide: creating the object opens a window on
google.com. Started eagerly, the app therefore threw a browser window at the
person before they had asked for anything -- on launch, and on every start of
the app, whether or not they ever wanted Google.

That is what this wrapper fixes. It holds the same surface as the window it
wraps (so `EngineWindow`, `BrowserWindow` and pywebview all fit), but the real
window is created by the first call that needs one: `show()`, `load_url()`,
`cookie_tuples()` when the jar is actually being read. Everything else --
`state()`, `host`, `events` -- answers without opening anything.

`close()` releases the window. The engine calls `hide()` when a sign-in ends,
which for an eager window meant "the browser is gone from under the person
mid-flow"; here `hide()` only marks the pane closed, and the next `show()`
brings a window back.
"""

from __future__ import annotations

import logging
import threading
from typing import Any, Callable

LOG = logging.getLogger("arena.lazywindow")


class _LazyEvents:
    """Events that survive the real window being created later.

    Handlers are attached once, by the engine, before any window exists. They
    are remembered here and re-attached to the real window's own events the
    moment it appears, so a subscriber never has to know about the delay.
    """

    def __init__(self):
        self._handlers: dict[str, list[Callable]] = {
            "loaded": [], "shown": [], "closing": [], "closed": []}
        self._target = None
        self._lock = threading.Lock()

    def detach_from(self, events) -> None:
        """Forget a window that is gone, before another one is attached.

        Handlers live here, not on the window, so without this the engine's
        subscriptions would pile up and every new window would fire the old
        ones as well -- one sign-in completing would call the callback twice.
        """
        with self._lock:
            if self._target is events:
                self._target = None

    def attach_to(self, events) -> None:
        """Point at the real window's events and hand over the handlers."""
        with self._lock:
            self._target = events
            pending = {k: list(v) for k, v in self._handlers.items()}
        for name, handlers in pending.items():
            real = getattr(events, name, None)
            if real is None:
                continue
            for handler in handlers:
                try:
                    real += handler
                except Exception:
                    LOG.info("could not move a %s handler onto the window", name)

    def _event(self, name: str):
        target = self._target
        if target is not None:
            return getattr(target, name, None)
        return _ProxyEvent(self, name)

    # `window.events.loaded += handler` is really
    # `setattr(events, "loaded", getattr(events, "loaded").__iadd__(handler))`,
    # so every one of these needs a setter. It stores the handler and ignores
    # the value: the getter always returns the same proxy.
    @property
    def loaded(self):
        return self._event("loaded")

    @loaded.setter
    def loaded(self, value):
        pass

    @property
    def shown(self):
        return self._event("shown")

    @shown.setter
    def shown(self, value):
        pass

    @property
    def closing(self):
        return self._event("closing")

    @closing.setter
    def closing(self, value):
        pass

    @property
    def closed(self):
        return self._event("closed")

    @closed.setter
    def closed(self, value):
        pass

    def remember(self, name: str, handler) -> None:
        with self._lock:
            self._handlers.setdefault(name, []).append(handler)

    def drop(self, name: str, handler) -> None:
        with self._lock:
            self._handlers[name] = [h for h in self._handlers.get(name, [])
                                    if h is not handler]


class _ProxyEvent:
    """Stands in for one event while there is no real window yet."""

    def __init__(self, events: _LazyEvents, name: str):
        self._events = events
        self._name = name

    def __iadd__(self, handler):
        self._events.remember(self._name, handler)
        return self

    def __isub__(self, handler):
        self._events.drop(self._name, handler)
        return self

    def set(self) -> None:
        """Nothing to fire yet: the window that would have fired does not exist."""

    def is_set(self) -> bool:
        return False

    def wait(self, timeout: float | None = None) -> bool:
        return False


class LazyWindow:
    """Creates the real window on first use.

    ``factory`` is a zero-argument callable returning a window object (or None
    when there is no GUI at all). Everything else is pass-through.
    """

    def __init__(self, factory: Callable[[], Any], *, name: str = "google window",
                 ephemeral: bool = False):
        self._factory = factory
        self._name = name
        self._window = None
        self._lock = threading.Lock()
        self.events = _LazyEvents()
        self._closed_by_app = False
        self._built_for = None
        self._ephemeral_factory = bool(ephemeral)

    # -- creation --------------------------------------------------------
    def ensure(self):
        """The real window, created now if this is the first ask."""
        with self._lock:
            if self._window is not None:
                return self._window
            LOG.info("%s: opening on demand (nothing asked for it earlier)", self._name)
            try:
                window = self._factory()
            except Exception:
                LOG.exception("%s: could not be created", self._name)
                return None
            self._window = window
            self._closed_by_app = False
            try:
                # Now that the real window exists, give it the non-blocking
                # wrappers -- if it is a pywebview window. A browser window
                # keeps its own methods (see `arena/diag.py`).
                from arena import diag
                diag.make_window_calls_non_blocking(window)
            except Exception:
                LOG.info("%s: window calls left as they are", self._name)
            if window is not None:
                events = getattr(window, "events", None)
                if events is not None:
                    self.events.attach_to(events)
            return window

    @property
    def window(self):
        """The window if it exists already; never creates one."""
        return self._window

    def is_open(self) -> bool:
        return self._window is not None and not self._closed_by_app

    # -- the surface the engine uses -------------------------------------
    def show(self):
        window = self.ensure()
        return getattr(window, "show", lambda: None)() if window else None

    def hide(self):
        """Mark the pane closed. The window itself is left alone.

        Closing the real window here is what used to destroy a session before
        its cookies could be read; a hidden pane simply means "not on screen".
        """
        self._closed_by_app = True

    def load_url(self, url: str):
        window = self.ensure()
        return window.load_url(url) if window is not None else False

    def evaluate_js(self, script: str, *a, **kw):
        window = self._window
        if window is None:
            # Nothing to run a script in, and creating a browser window just to
            # evaluate one expression would repeat the very problem this class
            # exists to fix.
            return None
        return window.evaluate_js(script, *a, **kw)

    def run_js(self, script: str, *a, **kw):
        return self.evaluate_js(script, *a, **kw)

    def get_cookies(self, *a, **kw):
        window = self._window
        if window is None:
            return []
        return window.get_cookies(*a, **kw)

    def cookie_tuples(self, *a, **kw):
        """Reading the jar is a real reason to have a window."""
        window = self.ensure()
        return window.cookie_tuples(*a, **kw) if window is not None else []

    def clear_cookies(self):
        window = self._window
        if window is None:
            return False
        return window.clear_cookies()

    @property
    def ephemeral(self) -> bool:
        """True when the real window is a single-use one.

        The engine asks this to decide whether to close the window or merely
        hide it, and it asks before the window exists -- a single-use window is
        the only kind that is *never* reused, so the honest answer is yes.
        """
        window = self._window
        if window is not None:
            return getattr(window, "ephemeral", False) is True
        return self._ephemeral_factory

    def close_and_forget(self):
        """Close the real window and let it delete its profile."""
        window = self._window
        if window is None:
            self._closed_by_app = True
            return
        closer = getattr(window, "close_and_forget", None)
        if callable(closer):
            closer()
        else:
            window.hide()
        self._closed_by_app = True
        self.forget()

    def forget(self) -> None:
        """Drop the real window so that the next ask creates a new one.

        A single-use window is not reusable by design: its profile is deleted
        the moment it closes. Handing the dead object back meant `ensure()`
        returned a window whose browser had already exited, and the second
        sign-in opened nothing at all.
        """
        window = self._window
        self._window = None
        self._closed_by_app = False
        if window is None:
            return
        events = getattr(window, "events", None)
        if events is not None:
            try:
                self.events.detach_from(events)
            except Exception:
                LOG.info("%s: could not detach from the old window", self._name)

    def resize(self, width: int, height: int):
        window = self._window
        return window.resize(width, height) if window is not None else None

    def move(self, x: int, y: int):
        window = self._window
        return window.move(x, y) if window is not None else None

    def restore(self):
        window = self._window
        return window.restore() if window is not None else None

    def destroy(self):
        window = self._window
        if window is not None:
            try:
                window.destroy()
            except Exception:
                LOG.info("%s: destroy failed", self._name, exc_info=True)
        self._window = None
        self._closed_by_app = True

    def wait_built(self, timeout: float = 8.0) -> bool:
        """Always true: a window that has not been asked for is not broken.

        The startup path uses this to decide whether to fall back. For a lazy
        window the honest answer is "there is nothing wrong yet" -- the failure,
        if any, shows up when the person presses the button, and `state()`
        carries it.
        """
        window = self._window
        if window is None:
            return True
        return bool(getattr(window, "wait_built", lambda t=timeout: True)(timeout))

    # -- introspection ---------------------------------------------------
    @property
    def native(self):
        window = self._window
        return getattr(window, "native", None) if window is not None else None

    @property
    def is_browser(self) -> bool:
        """True once the real window is a browser, not pywebview.

        The engine asks this to know whether a `shown` event will ever arrive.
        Before the window exists the honest answer is "no": nothing has been
        created, so nothing has been shown either.
        """
        window = self._window
        return bool(getattr(window, "is_browser", False)) if window is not None else False

    @property
    def webview(self):
        window = self._window
        return getattr(window, "webview", None) if window is not None else None

    @property
    def host(self):
        window = self._window
        if window is None:
            return ""
        value = getattr(window, "host", "")
        return value() if callable(value) else value

    def is_ready(self) -> bool:
        window = self._window
        return bool(getattr(window, "is_ready", lambda: False)()) if window else False

    def state(self) -> dict:
        window = self._window
        inner = {}
        if window is not None:
            try:
                inner = dict(window.state() or {})
            except Exception:
                inner = {}
        return {
            "deferred": window is None,
            "opened": window is not None and not self._closed_by_app,
            "closed_by_app": self._closed_by_app,
            **inner,
        }
