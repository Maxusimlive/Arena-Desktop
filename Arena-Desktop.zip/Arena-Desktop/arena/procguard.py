"""Keep every child process inside one kill-on-close Job Object.

PyInstaller's one-file bootloader unpacks the app into ``%TEMP%\\_MEIxxxxx``
and deletes that folder when the child process ends. WebView2 runs the actual
browser in separate ``msedgewebview2.exe`` processes that load DLLs straight
out of that folder, so if they outlive the app — which is exactly what happens
after a hard crash, or when the app exits through ``os._exit`` — the files stay
locked and the bootloader pops up "Failed to remove temporary directory".

Putting the app in a Job Object with ``JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE``
makes Windows kill every descendant the moment the app's process goes away, no
matter how it goes away. The browser processes die with it, the folder is
released, and the dialog cannot appear.
"""

from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import sys

_JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000
_JobObjectExtendedLimitInformation = 9


class _IO_COUNTERS(ctypes.Structure):
    _fields_ = [("ReadOperationCount", ctypes.c_ulonglong),
                ("WriteOperationCount", ctypes.c_ulonglong),
                ("OtherOperationCount", ctypes.c_ulonglong),
                ("ReadTransferCount", ctypes.c_ulonglong),
                ("WriteTransferCount", ctypes.c_ulonglong),
                ("OtherTransferCount", ctypes.c_ulonglong)]


class _JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [("PerProcessUserTimeLimit", ctypes.c_longlong),
                ("PerJobUserTimeLimit", ctypes.c_longlong),
                ("LimitFlags", wt.DWORD),
                ("MinimumWorkingSetSize", ctypes.c_size_t),
                ("MaximumWorkingSetSize", ctypes.c_size_t),
                ("ActiveProcessLimit", wt.DWORD),
                ("Affinity", ctypes.c_size_t),
                ("PriorityClass", wt.DWORD),
                ("SchedulingClass", wt.DWORD)]


class _JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [("BasicLimitInformation", _JOBOBJECT_BASIC_LIMIT_INFORMATION),
                ("IoInfo", _IO_COUNTERS),
                ("ProcessMemoryLimit", ctypes.c_size_t),
                ("JobMemoryLimit", ctypes.c_size_t),
                ("PeakProcessMemoryUsed", ctypes.c_size_t),
                ("PeakJobMemoryUsed", ctypes.c_size_t)]


_handle = None  # kept alive for the whole run on purpose


def keep_children_inside_job() -> bool:
    """Best effort; a failure here must never stop the app from starting."""
    global _handle
    if not sys.platform.startswith("win") or _handle is not None:
        return _handle is not None
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateJobObjectW.restype = wt.HANDLE
        job = kernel32.CreateJobObjectW(None, None)
        if not job:
            return False
        info = _JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
        info.BasicLimitInformation.LimitFlags = _JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        if not kernel32.SetInformationJobObject(
                wt.HANDLE(job), _JobObjectExtendedLimitInformation,
                ctypes.byref(info), ctypes.sizeof(info)):
            return False
        if not kernel32.AssignProcessToJobObject(wt.HANDLE(job),
                                                 kernel32.GetCurrentProcess()):
            # Older Windows refuses to nest jobs; the app still runs, it just
            # loses the guarantee, so this is not fatal.
            return False
        _handle = job  # closing the handle would kill us; hold it forever
        return True
    except Exception:
        return False
