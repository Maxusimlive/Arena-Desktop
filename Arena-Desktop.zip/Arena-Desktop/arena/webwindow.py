"""A Windows window for the Google pane that does not use pywebview.

Why this exists
---------------
Three attempts to fix the pywebview-based Google window all failed on real
machines, and every failure had the same shape: a call made from a request
thread, blocked on pywebview's internal `shown` event while holding the GIL,
with the UI thread parked inside `app.Run()`. The shipped thread dumps say it
in one line:

    THREAD DUMP: window.load_url не возвращается уже 10 с
    --- поток Dummy-18 ---
      File "webview\\platforms\\winforms.py", line 808, in create   ... app.Run()

Patching individual calls cannot fix that, because the deadlock lives in the
library's design: `@_shown_call` gates `load_url`/`hide`/`resize` on an event
that only the message loop can set, and a hidden window may never set it. Each
patched call revealed the next one.

So this module owns the window outright:

* it runs its own STA thread with its own WinForms message loop, created after
  the main process loop is already running, so it never competes for the app's
  single `Application.Run()`;
* every public method is safe to call from any thread and returns immediately —
  the work is marshalled with `BeginInvoke` and nothing ever waits while
  holding the GIL;
* there is no `shown` gate anywhere, so a hidden window can still navigate,
  read its host and run scripts;
* WebView2 is awaited asynchronously instead of being assumed to exist.

What it deliberately does NOT do
--------------------------------
It does not replace pywebview for the main window or the arena.ai pane. Those
have worked in the field; rebuilding them would trade a known-good component
for an unproven one. This is scoped to the pane that is broken.

The object it hands out satisfies the same small surface the engines already
use (`events.loaded`, `evaluate_js`, `load_url`, `show`, `hide`, `native`,
`get_cookies`, `clear_cookies`), so it drops into `GoogleEngine.attach()`
without touching the rest of the Google code.
"""

from __future__ import annotations

import json
import logging
import os
import queue
import sys
import threading
import time
from typing import Any, Callable

LOG = logging.getLogger("arena.webwindow")

IS_WINDOWS = sys.platform == "win32"


# ---------------------------------------------------------------------------
# The event object the engines subscribe to
# ---------------------------------------------------------------------------
class WindowEvent:
    """A thread-safe event with pywebview's tiny surface.

    The engines only ever use `+=` to subscribe and `wait()`/`set()` in a few
    places. Keeping the same shape means no call site has to change.
    """

    def __init__(self, name: str = "event"):
        self.name = name
        self._lock = threading.Lock()
        self._handlers: list[Callable[..., Any]] = []
        self._set = threading.Event()

    def __iadd__(self, handler: Callable[..., Any]):
        with self._lock:
            self._handlers.append(handler)
        return self

    def __isub__(self, handler: Callable[..., Any]):
        with self._lock:
            if handler in self._handlers:
                self._handlers.remove(handler)
        return self

    def set(self) -> None:
        self._set.set()
        with self._lock:
            handlers = list(self._handlers)
        for handler in handlers:
            try:
                handler()
            except Exception:
                LOG.info("event %s handler failed", self.name, exc_info=True)

    def clear(self) -> None:
        self._set.clear()

    def is_set(self) -> bool:
        return self._set.is_set()

    def wait(self, timeout: float | None = None) -> bool:
        return self._set.wait(timeout)


def _looks_like_task(value) -> bool:
    """True when ``value`` is a .NET ``Task`` rather than its finished value.

    The distinction is the whole bug in ``cookie_tuples``: on a real Windows
    build ``CookieManager.GetCookiesAsync(url)`` hands back an *already
    resolved* ``List[CoreWebView2Cookie]`` through pythonnet, not a pending
    task. Code that assumes a task reads ``.IsCompleted`` on a list, gets an
    ``AttributeError``, swallows it, and reports "the jar is empty" for ever.

    Checked on the *type* where possible: reading a .NET property off its
    apartment can raise instead of returning, and ``hasattr`` turns that into a
    quiet False -- which is how the original check misfired.
    """
    if value is None:
        return False
    if hasattr(type(value), "IsCompleted"):
        return True
    try:
        return "IsCompleted" in object.__getattribute__(value, "__dict__")
    except Exception:
        return False


def _is_collection(value) -> bool:
    """True for a finished collection of cookies (a .NET list counts).

    pythonnet's ``List[CoreWebView2Cookie]`` is NOT a ``list``: ``isinstance``
    is False, ``__iter__`` is True. That mismatch is what sent a finished jar
    down the "still pending" path.
    """
    if isinstance(value, (list, tuple)):
        return True
    if isinstance(value, (str, bytes, dict)):
        return False
    return not _looks_like_task(value) and hasattr(value, "__iter__")


class _BrowserShim:
    """Stands in for pywebview's Edge layer on a plain WinForms form.

    Only `syncContextTaskScheduler` is ever read from it, and the engine already
    tolerates a missing value; the attribute exists so the *lookup* succeeds.
    """

    syncContextTaskScheduler = None


class WindowEvents:
    """The handful of events `attach()` reaches for."""

    def __init__(self):
        self.loaded = WindowEvent("loaded")
        self.shown = WindowEvent("shown")
        self.closing = WindowEvent("closing")
        self.closed = WindowEvent("closed")


# ---------------------------------------------------------------------------
# The window itself
# ---------------------------------------------------------------------------
class WebViewWindow:
    """A WinForms + WebView2 window driven entirely by this class.

    Construct it on any thread; the UI thread is started immediately and the
    window is built inside it. Nothing here blocks the caller: not creation,
    not navigation, not script evaluation.
    """

    def __init__(self, title: str, url: str = "about:blank", *, width: int = 1100,
                 height: int = 820, x: int | None = None, y: int | None = None,
                 hidden: bool = True, user_data_dir: str | None = None):
        self.title = title
        self.url = url
        self.width = width
        self.height = height
        self.x = x
        self.y = y
        self.hidden = hidden
        self.user_data_dir = user_data_dir

        self.events = WindowEvents()
        self.native = None          # the WinForms form, once built
        self.webview = None         # the WebView2 control
        self.core = None            # CoreWebView2, once initialised

        self._ready = threading.Event()      # window built and shown/hidden
        self._core_ready = threading.Event()  # WebView2 browser process up
        self._form: Any = None
        self._control: Any = None
        self._thread: threading.Thread | None = None
        self._closed = False
        # Kept so callers can tell "not built yet" from "cannot be built".
        # Without this the app looked healthy while the pane was dead.
        self.build_error: str | None = None
        self._init_task = None

    # -- creation --------------------------------------------------------
    def start(self, ui_queue: "queue.Queue[Callable[[], Any]] | None" = None) -> bool:
        """Build the window on its own STA thread. Returns at once.

        `ui_queue` is the *shared* UI dispatcher the rest of the app pumps: the
        window registers itself there so existing `_on_ui` helpers keep working
        against this window without knowing it is not pywebview.
        """
        if not IS_WINDOWS:
            LOG.info("no window on this platform; the pane will use plain HTTPS")
            return False
        if self._thread is not None:
            return True

        self._thread = threading.Thread(target=self._run_ui_thread,
                                        name="google-window-ui", daemon=True)
        self._thread.start()
        return True

    def _run_ui_thread(self) -> None:
        """Own STA thread, own message pump.

        This is the part pywebview gets wrong for a second window: it builds
        every extra window by calling `Invoke` into the *main* window's thread
        and only then runs `Application.Run()`. Here the thread exists for this
        window alone, so nothing can park it behind another window's loop.
        """
        try:
            import clr  # noqa: F401  (pythonnet; loads the CLR for this thread)
            # Both namespaces are needed: WinForms for the form and its
            # controls, System.Drawing for the Point/Size types their
            # properties take. `import System` alone does not bind the
            # sub-namespace, so the import has to name it.
            import System.Drawing
            import System.Windows.Forms as WinForms
            from System.Threading import Thread as NetThread, ThreadStart, ApartmentState

            # WebView2 interop assemblies ship with pywebview; point the loader
            # at them before the types are touched, exactly as it does.
            try:
                from webview.util import interop_dll_path
                for platform in ("win-arm64", "win-x64", "win-x86"):
                    try:
                        os.environ["Path"] = os.environ.get("Path", "") + ";" + \
                            interop_dll_path(platform)
                    except Exception:
                        pass
                clr.AddReference(interop_dll_path("Microsoft.Web.WebView2.Core.dll"))
                clr.AddReference(interop_dll_path("Microsoft.Web.WebView2.WinForms.dll"))
            except Exception:
                LOG.info("WebView2 interop assemblies not found next to pywebview",
                         exc_info=True)

            self._form = WinForms.Form()
            self._form.Text = self.title
            self._form.Width = self.width
            self._form.Height = self.height
            if self.x is not None and self.y is not None:
                self._form.StartPosition = WinForms.FormStartPosition.Manual
                self._form.Location = System.Drawing.Point(self.x, self.y)

            from Microsoft.Web.WebView2.WinForms import WebView2
            self._control = WebView2()
            self._control.Dock = WinForms.DockStyle.Fill
            self._form.Controls.Add(self._control)

            # The engines read `window.native` and expect `.webview` on it.
            self._form.webview = self._control
            # `google_ai._read_edge_host_on_ui` also reads `.browser` (pywebview
            # keeps its Edge layer there) and takes `syncContextTaskScheduler`
            # from it. A raw WinForms form has no such attribute, so the engine
            # gave up looking for CoreWebView2 and every cookie read returned an
            # empty jar. The scheduler is only a hint there, never required.
            self._form.browser = _BrowserShim()
            self.native = self._form
            self.webview = self._control

            self._form.Shown += self._on_shown
            self._form.FormClosing += self._on_closing

            self._ready.set()

            if self.hidden:
                self._form.Opacity = 0
                self._form.Show()
                self._form.Hide()
                self._form.Opacity = 1
            else:
                self._form.Show()

            self._ensure_core()
            self._pump(WinForms)
        except Exception as exc:
            LOG.exception("the window could not be built")
            self.build_error = f"{type(exc).__name__}: {exc}"
            self._ready.set()

    def wait_built(self, timeout: float = 8.0) -> bool:
        """True once the form exists; False if it never will.

        Called once at startup, where a short wait is free: it buys the
        difference between a working window and a pane that silently does
        nothing for the rest of the session.
        """
        # `_thread` is deliberately not consulted: a window can be built
        # without it (tests, or a future host that builds inline), and asking
        # "does a form exist" is the only question that matters here.
        self._ready.wait(timeout)
        return self.native is not None and self.build_error is None

    def _pump(self, WinForms) -> None:
        """Run this window's message loop until it closes."""
        try:
            WinForms.Application.Run(self._form)
        except Exception:
            LOG.info("window message loop ended", exc_info=True)

    def _ensure_core(self) -> None:
        """Start WebView2 initialisation and report when it is usable."""
        try:
            # Subscribe first, start second. A completed initialisation fires on
            # the same thread while the pump is running, so a subscription made
            # after the call can miss a failure notification entirely.
            self._control.CoreWebView2InitializationCompleted += \
                self._on_core_initialized
            # The returned task is kept on purpose. WebView2 documents that if
            # the task is collected before it completes, the host can terminate
            # with a native error and no traceback -- a failure mode that looks
            # exactly like "the window never appeared".
            self._init_task = self._control.EnsureCoreWebView2Async(None)
        except Exception:
            LOG.info("WebView2 initialisation could not be started", exc_info=True)

    def _on_core_initialized(self, sender, args) -> None:
        try:
            if args.IsSuccess:
                self.core = self._control.CoreWebView2
                self.core.NavigationCompleted += self._on_navigation_completed
                self._core_ready.set()
                LOG.info("window: WebView2 is ready")
                if self.url and self.url != "about:blank":
                    self.load_url(self.url)
            else:
                LOG.warning("window: WebView2 failed to initialise: %s",
                            getattr(args, "InitializationException", ""))
        except Exception:
            LOG.info("window: WebView2 init handler failed", exc_info=True)

    def _on_navigation_completed(self, sender, args) -> None:
        # A failed navigation is still an answer: whatever waits on `loaded`
        # has to learn that the page will not appear, or it waits for ever
        # while the user sees nothing happen.
        try:
            if not args.IsSuccess:
                LOG.info("window: navigation failed: %s",
                         getattr(args, "WebErrorStatus", ""))
        except Exception:
            pass
        self.events.loaded.set()

    def _on_shown(self, *a) -> None:
        self.events.shown.set()

    def _on_closing(self, sender=None, args=None) -> None:
        """Close means hide: the session in the profile must survive."""
        if args is not None:
            try:
                args.Cancel = True
            except Exception:
                pass
        self.hide()

    # -- marshalling -----------------------------------------------------
    def _post(self, action: Callable[[], Any]) -> bool:
        """Run `action` on the UI thread without ever blocking the caller.

        `BeginInvoke` is asynchronous by contract: it queues the delegate and
        returns. Nothing here waits, so the GIL is never held across the hop —
        which is the entire reason the app used to freeze.
        """
        if self.build_error is not None:
            return False
        form = self._form
        if form is None:
            return False
        try:
            if not form.InvokeRequired:
                action()
                return True
            from System.Windows.Forms import MethodInvoker
            form.BeginInvoke(MethodInvoker(lambda: self._guard(action)))
            return True
        except Exception:
            LOG.info("window: call could not be queued", exc_info=True)
            return False

    @staticmethod
    def _guard(action: Callable[[], Any]) -> None:
        try:
            action()
        except Exception:
            LOG.info("window: call failed on the UI thread", exc_info=True)

    # -- the surface the engines use -------------------------------------
    def load_url(self, url: str) -> bool:
        """Navigate. Safe from any thread, at any time, in any order.

        Two cases, and the second is the one that used to break: if the browser
        is up, the navigation is queued and done; if it is not (pywebview
        creates WebView2 asynchronously, so the first navigation almost always
        arrives first), a daemon thread waits for the browser and navigates
        then. The caller is never parked either way.
        """
        url = str(url)

        def navigate():
            if self.core is not None:
                self.core.Navigate(url)
                return True
            return False

        if self._core_ready.is_set():
            self._post(navigate)
            return True
        if self.build_error is not None:
            LOG.info("window: no window to load %s into", url)
            return False

        def later():
            if self._core_ready.wait(30.0):
                self._post(navigate)
            else:
                LOG.warning("window: never became ready to load %s", url)

        threading.Thread(target=later, daemon=True,
                         name="window-deferred-load").start()
        return True

    def evaluate_js(self, script: str, timeout: float = 8.0):
        """Run a script and wait (bounded) for its JSON result.

        The wait happens here, on the caller's thread, after the queue hop —
        never inside the UI thread, whose message pump is what completes the
        WebView2 task in the first place.
        """
        if not self._core_ready.is_set():
            return None
        box: dict = {}
        done = threading.Event()

        def start():
            try:
                box["task"] = self.core.ExecuteScriptAsync(str(script))
            except Exception as exc:
                box["error"] = exc
            finally:
                done.set()

        if not self._post(start):
            return None
        if not done.wait(timeout):
            LOG.info("window: script was not queued within %.1fs", timeout)
            return None
        if "error" in box:
            LOG.info("window: script failed to start: %s", box["error"])
            return None
        task = box.get("task")

        def decode(raw):
            if raw is None:
                return None
            text = str(raw)
            try:
                return json.loads(text)
            except ValueError:
                return text

        if not _looks_like_task(task):
            # A backend that answers with the value itself. Reading it as a
            # task used to end in "script result unreadable" and a None that
            # every caller silently accepted.
            return decode(task)

        end = time.time() + timeout
        while time.time() < end:
            try:
                if task.IsCompleted:
                    return decode(task.Result)
            except Exception:
                LOG.info("window: script result unreadable", exc_info=True)
                return None
            time.sleep(0.02)
        LOG.info("window: script did not finish within %.1fs", timeout)
        return None

    def run_js(self, script: str, timeout: float = 8.0):
        return self.evaluate_js(script, timeout)

    def get_cookies(self, *a, **kw):
        """Kept for call sites that still ask the window for its jar."""
        return self.cookie_tuples()

    def cookie_tuples(self, limit: float = 8.0) -> list[tuple[str, str, str]]:
        """The jar as plain tuples, read on the UI thread."""
        if not self._core_ready.is_set():
            return []
        box: dict = {}
        done = threading.Event()

        def flatten(cookies) -> list:
            """Read the COM fields. UI thread only, by contract."""
            out = []
            try:
                for item in cookies:
                    try:
                        out.append((str(item.Name), str(item.Value),
                                    str(item.Domain)))
                    except Exception:
                        continue
            except Exception:
                LOG.info("window: cookie collection was not iterable", exc_info=True)
                return []
            return out

        def start():
            try:
                box["task"] = self.core.CookieManager.GetCookiesAsync(
                    "https://www.google.com/")
                # A finished collection may arrive instead of a task. Its
                # fields are COM: reading them on any thread but this one
                # blocks for ever with the GIL held, so they are read HERE,
                # while we are already on the UI thread.
                value = box["task"]
                if value is not None and not _looks_like_task(value):
                    box["cookies"] = flatten(value)
            except Exception as exc:
                box["error"] = exc
            finally:
                done.set()

        if not self._post(start) or not done.wait(limit):
            return []
        if "cookies" in box:
            return box["cookies"]
        task = box.get("task")
        if task is None:
            return []

        end = time.time() + limit
        while time.time() < end:
            try:
                if task.IsCompleted:
                    jar = task.Result
                    break
            except Exception:
                return []
            time.sleep(0.02)
        else:
            return []
        # The task finished on its own thread; unpacking its COM result is a
        # cross-apartment call, so it goes back to the UI thread.
        out_box: dict = {}
        unpacked = threading.Event()

        def unpack():
            try:
                out_box["cookies"] = flatten(jar)
            except Exception:
                out_box["cookies"] = []
            finally:
                unpacked.set()

        if self._post(unpack) and unpacked.wait(min(limit, 4.0)):
            return out_box.get("cookies", [])
        return []

    def clear_cookies(self) -> bool:
        if not self._core_ready.is_set():
            return False
        return bool(self._post(lambda: self.core.CookieManager.DeleteAllCookies()))

    def show(self) -> None:
        def bring_up():
            if self._form is not None:
                self._form.Show()
                self._form.Activate()
        if not self._post(bring_up):
            # Not built yet: do it as soon as the window exists.
            def later():
                # Bounded, not endless: if the window never gets built the
                # caller must not leave a thread pining for it for the rest of
                # the session.
                if self._ready.wait(30.0):
                    self._post(bring_up)
                else:
                    LOG.warning("window: was never built; show() dropped")
            threading.Thread(target=later, daemon=True, name="window-show").start()

    def hide(self) -> None:
        self._post(lambda: self._form.Hide() if self._form is not None else None)

    def resize(self, width: int, height: int) -> None:
        def apply():
            if self._form is not None:
                self._form.Width = int(width)
                self._form.Height = int(height)
        self._post(apply)

    def move(self, x: int, y: int) -> None:
        def apply():
            if self._form is not None:
                self._form.Left = int(x)
                self._form.Top = int(y)
        self._post(apply)

    def restore(self) -> None:
        def apply():
            if self._form is not None and self._form.WindowState != 0:
                self._form.WindowState = 0
        self._post(apply)

    def destroy(self) -> None:
        """Tear the window down and let the title bar's X do the same."""
        def close():
            if self._form is not None:
                self._form.FormClosing -= self._on_closing
                self._form.Close()
        self._post(close)
        self._closed = True
        self.events.closed.set()

    # -- introspection ---------------------------------------------------
    def host(self) -> str:
        value = self.evaluate_js("location.host")
        return str(value or "")

    def is_ready(self) -> bool:
        return self._core_ready.is_set()

    def state(self) -> dict:
        return {
            "platform": "windows-direct" if IS_WINDOWS else "unavailable",
            "built": self._ready.is_set(),
            "core_ready": self._core_ready.is_set(),
            "thread": self._thread.name if self._thread else None,
            "build_error": self.build_error,
        }

# ---------------------------------------------------------------------------
# Adapter for the engines
# ---------------------------------------------------------------------------
class EngineWindow:
    """Presents a `WebViewWindow` in the shape `GoogleEngine` already expects.

    The engines were written against pywebview and use exactly this much of it:
    ``events.loaded`` / ``events.closing`` / ``events.shown``, ``evaluate_js``,
    ``load_url``, ``show``, ``hide``, ``resize``, ``move``, ``restore``,
    ``native`` and ``host``. Everything else they used to need (`shown` gates,
    twenty-second waits) exists only because of pywebview, and is gone here.

    Keeping this adapter separate means the Google code keeps working even if
    the window implementation changes again: only this class has to follow.
    """

    def __init__(self, window: "WebViewWindow"):
        self._window = window
        self.events = window.events
        self.native = None          # set below, on the UI thread
        window.start()

    # `native` must reflect the form once it exists (the engines read
    # `native.webview.CoreWebView2`), so it is a property, not a snapshot.
    @property
    def native(self):               # noqa: D401 - see note above
        return self._window.native

    @native.setter
    def native(self, value):        # the constructor assigns; keep it harmless
        pass

    def evaluate_js(self, script: str, *a, **kw):
        return self._window.evaluate_js(script, *a, **kw)

    def run_js(self, script: str, *a, **kw):
        return self._window.run_js(script, *a, **kw)

    def load_url(self, url: str):
        return self._window.load_url(url)

    def show(self):
        return self._window.show()

    def hide(self):
        return self._window.hide()

    def resize(self, width, height):
        return self._window.resize(width, height)

    def move(self, x, y):
        return self._window.move(x, y)

    def restore(self):
        return self._window.restore()

    def destroy(self):
        return self._window.destroy()

    def get_cookies(self, *a, **kw):
        return self._window.get_cookies(*a, **kw)

    def clear_cookies(self):
        return self._window.clear_cookies()

    @property
    def host(self):
        return self._window.host()

    @property
    def webview(self):
        return self._window.webview

    def wait_built(self, timeout: float = 8.0) -> bool:
        return self._window.wait_built(timeout)

    def state(self):
        return self._window.state()


def create_google_window(user_data_dir: str | None = None) -> "EngineWindow | None":
    """The Google pane's window, or None where there is no GUI.

    Returning None is the honest answer on Linux and in tests: the pane then
    runs over plain HTTPS, which is what it already does before sign-in.
    """
    if not IS_WINDOWS:
        return None
    window = WebViewWindow("Google AI mode - Arena Desktop", "about:blank",
                           width=1100, height=820, x=160, y=110, hidden=True,
                           user_data_dir=user_data_dir)
    return EngineWindow(window)
