"""Test clients carry the same per-instance token as the desktop UI."""
import pytest


@pytest.fixture(autouse=True)
def poll_ticks_are_free(monkeypatch):
    """Polling loops must not cost wall-clock time in tests.

    `_wait_for` (questions, permits, challenges) and `_collect_webdev_previews`
    are written as "check, then wait a tick, then check again". A two-second
    timeout therefore costs two real seconds per run, and one test asked the
    question four times.

    Only the tick is shortened, not `time.sleep` in general: a test that makes
    a fake stream sleep for three seconds is testing exactly that, and
    shortening it would answer a different question.
    """
    from arena.web import app as web

    monkeypatch.setattr(web, "POLL_TICK", 0.001)


@pytest.fixture(autouse=True)
def authenticated_test_client(monkeypatch):
    from arena.web import app as web
    original = web.app.test_client

    def create(*args, **kwargs):
        client = original(*args, **kwargs)
        client.environ_base['HTTP_X_ARENA_TOKEN'] = web._API_TOKEN
        return client

    monkeypatch.setattr(web.app, 'test_client', create)

import sys
from pathlib import Path

# Tests import helpers that live beside them (gilprobe.py) by plain name.
_TESTS_DIR = str(Path(__file__).resolve().parent)
if _TESTS_DIR not in sys.path:
    sys.path.insert(0, _TESTS_DIR)


import sys as _sys
import types as _types

import pytest as _pytest


class _FakeForms(_types.ModuleType):
    """``System.Windows.Forms`` stand-in (the real one only exists on Windows)."""

    class MethodInvoker:
        def __init__(self, fn):
            self.fn = fn

        def __call__(self, *a):
            return self.fn(*a)


@_pytest.fixture()
def fake_winforms(monkeypatch):
    module = _FakeForms("System.Windows.Forms")
    monkeypatch.setitem(_sys.modules, "System.Windows.Forms", module)
    return module
