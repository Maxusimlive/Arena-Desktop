"""A real GIL probe, and the harness that catches "the whole app froze".

Why this file exists
--------------------
The user's freeze could not be reproduced by running the app on Linux: it
needs WebView2 and a live WinForms message pump. But the *cause* is portable.
It is always the same shape:

    a call that pythonnet performs while holding the GIL

While such a call runs, no other Python thread executes a single bytecode:
not the log watchdog, not the heartbeat, not the Flask worker that asked.
The app looks dead, writes nothing, raises nothing, and leaves an empty crash
file — exactly what the user reported.

An honest simulation needs a call that actually holds the GIL. Verified:
``ctypes.CDLL`` releases the GIL (a counter keeps ticking) while
``ctypes.PyDLL`` does not (the counter stops). PyDLL is therefore the faithful
stand-in for a blocking .NET call made through pythonnet, and it is what this
module uses to tell "bounded" code from "freezing" code.

The rule these tests enforce: anything called from a request handler must
finish with other threads still alive. When someone reintroduces
``Task.Wait()``, ``.Invoke()`` or any other GIL-holding call on a worker
thread, these tests fail in seconds on Linux — long before a build is handed
to the user.
"""

from __future__ import annotations

import ctypes
import ctypes.util
import sys
import threading
import time

import pytest


def _libc():
    name = ctypes.util.find_library("c") or "libc.so.6"
    return ctypes.PyDLL(name)          # PyDLL keeps the GIL, like pythonnet


class GilProbe:
    """Counts how often another thread gets to run. Zero means the GIL is held.

    Usage::

        with GilProbe() as probe:
            some_suspicious_call()
        assert probe.moved, "that call froze every other thread"
    """

    def __init__(self, interval: float = 0.02):
        self.interval = interval
        self.ticks = 0
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True,
                                        name="gil-probe")
        self.elapsed = 0.0

    def _run(self):
        while not self._stop.is_set():
            self.ticks += 1
            time.sleep(self.interval)

    def __enter__(self):
        self.ticks = 0
        self._t0 = time.monotonic()
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self.elapsed = time.monotonic() - self._t0
        self._stop.set()
        self._thread.join(timeout=2)
        return False

    @property
    def moved(self) -> bool:
        """True when other threads ran during the block."""
        return self.ticks >= 3

    def describe(self) -> str:
        return (f"{self.ticks} ticks in {self.elapsed:.2f}s "
                f"(expected ~{self.elapsed / self.interval:.0f})")


@pytest.fixture(scope="module")
def gil_probe_sanity():
    """Prove the probe can tell the two cases apart, or the suite is worthless.

    If PyDLL ever stopped holding the GIL (different ctypes build), the other
    tests here would pass no matter what the code does. This fixture makes that
    failure mode impossible to miss.
    """
    libc = _libc()
    with GilProbe() as held:
        libc.usleep(400_000)            # holds the GIL: nothing else runs
    with GilProbe() as released:
        time.sleep(0.4)                 # releases the GIL: others run
    assert not held.moved, (
        "PyDLL no longer holds the GIL, so these tests cannot detect a freeze: "
        + held.describe())
    assert released.moved, (
        "the probe cannot see other threads at all, so it proves nothing: "
        + released.describe())
    return True


def test_probe_detects_a_gil_holding_call(gil_probe_sanity):
    """Sanity check that the detector works, kept next to its users."""
    libc = _libc()
    with GilProbe() as probe:
        libc.usleep(300_000)
    assert not probe.moved, "a GIL-holding call went undetected: " + probe.describe()
