"""The boot gate's sign-in buttons must actually move the gate forward.

The bug this pins down: "Sign in to Arena" called the API, showed a toast and
stopped. The gate kept rendering the accounts step as failed, so a person who
had just signed in still saw "not signed in" and had no way past the screen.
Nothing threw, so no unit test caught it — only a browser did. That is exactly
the class of failure the tests below have to catch.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

APP_JS = Path(__file__).resolve().parents[1] / "arena" / "web" / "static" / "app.js"


@pytest.fixture(scope="module")
def source() -> str:
    return APP_JS.read_text(encoding="utf-8")


def _function_body(source: str, name: str) -> str:
    """The text of ``function name(...) { ... }`` up to its closing brace."""
    start = source.index(f"function {name}(")
    depth = 0
    for i in range(source.index("{", start), len(source)):
        if source[i] == "{":
            depth += 1
        elif source[i] == "}":
            depth -= 1
            if depth == 0:
                return source[start:i + 1]
    raise AssertionError(f"unbalanced braces in {name}")


def test_gate_actions_exist(source: str) -> None:
    body = _function_body(source, "bootAddActions")
    assert "API.login()" in body, "the accounts step lost its Arena sign-in"
    assert "API.googleSignIn()" in body, "the accounts step lost its Google sign-in"


def test_arena_sign_in_waits_for_the_session(source: str) -> None:
    """Opening the window is not signing in.

    ``/api/login`` only shows the window; the session becomes real when the
    person finishes inside it, and the only endpoint that notices that — and
    closes the window — is ``/api/login/poll``. The gate used to stop at
    "window opened", so it kept reporting "not signed in" while the window sat
    open forever. That is the reported bug, so the poll is pinned here.
    """
    body = _function_body(source, "bootAddActions")
    arena = body[body.index("API.login()"):]
    arena = arena[:arena.index("runBootGate()")] if "runBootGate()" in arena else arena
    assert "API.loginPoll()" in arena, (
        "the gate opens the Arena window but never polls for the session, so a "
        "completed sign-in is never noticed and the window never closes"
    )
    assert "done" in arena, "the poll result is not checked for completion"


def test_arena_sign_in_rechecks_the_gate(source: str) -> None:
    """Signing in changes the account check's verdict, so it must re-run."""
    body = _function_body(source, "bootAddActions")
    arena = body[body.index("API.login()"):]
    arena = arena[:arena.index("box.appendChild")] if "box.appendChild" in arena else arena
    assert "runBootGate()" in arena, (
        "a successful Arena sign-in does not re-run the gate: the screen stays "
        "stuck on the old verdict"
    )


def test_google_sign_in_does_not_pretend_to_fix_accounts(source: str) -> None:
    """A Google session is not an Arena session: the step cannot turn green.

    Re-running the gate right after opening the Google window made the screen
    flash like a reload that achieved nothing, which is exactly how the bug was
    reported. The button must say that the Google window is separate instead.
    """
    body = _function_body(source, "bootAddActions")
    google = body[body.index("API.googleSignIn()"):]
    google = google[:google.index("box.appendChild")] if "box.appendChild" in google else google
    assert "separate" in google.lower() or "own window" in google.lower(), (
        "the Google button does not explain that it is a different account"
    )
    assert "runBootGate()" not in google, (
        "the Google button re-runs the gate, which looks like a reload that changes nothing"
    )


def test_failed_sign_in_does_not_recheck(source: str) -> None:
    """On failure the button must come back, not silently re-run the gate."""
    body = _function_body(source, "bootAddActions")
    for api in ("API.login()", "API.googleSignIn()"):
        chunk = body[body.index(api):]
        chunk = chunk[:chunk.index("box.appendChild")] if "box.appendChild" in chunk else chunk
        catch = chunk[chunk.index("catch"):]
        assert "return;" in catch, (
            f"{api}: the error path falls through to the gate re-check"
        )


def test_every_api_reference_in_the_gate_is_defined(source: str) -> None:
    """A call to a missing API method is invisible until someone clicks it."""
    body = _function_body(source, "bootAddActions")
    for name in sorted(set(re.findall(r"API\.(\w+)\(", body))):
        assert re.search(rf"\b{name}\s*\(", source), f"API.{name} is never defined"
        assert re.search(rf"^\s*{name}\s*[:(]", source, re.MULTILINE), (
            f"API.{name}() is called by the gate but is not a method of API"
        )


def test_boot_gate_actions_match_new_design():
    from pathlib import Path
    app_js = Path("arena/web/static/app.js").read_text(encoding="utf-8")
    index_html = Path("arena/web/static/index.html").read_text(encoding="utf-8")

    assert "Sign in to Arena" in app_js
    assert "Sign in to Google" in app_js
    assert "Use cookies" not in app_js.split("function bootAddActions")[1][:1200]
    assert 'id="bootRetry"' not in index_html
    assert "boot-step-reload" in app_js
