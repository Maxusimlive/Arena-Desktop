"""`_safe_profile`: the Chrome profile must survive the app's second launch.

What the person saw
-------------------
They pressed "Sign in to Google" and *nothing happened*: no window, no
message, and a tick afterwards. The tick was one bug (fixed in round 6); the
silent button was another, and this is it.

What was wrong
--------------
`_WEBVIEW2_MARKERS` listed `Default/Cache` and `Default/Network` as signs of a
live WebView2 store. Those are **ordinary Chrome folders**: every Chromium
profile has them. The app passes `--user-data-dir=<data>/google-browser`, so:

* first launch: the folder is empty, no marker matches, the profile is used,
  Chrome writes `Default/Cache` and `Default/Network` inside it;
* every launch after that: the folder now contains those markers, so the
  profile is refused and `_safe_profile` returns None;
* no `--user-data-dir` means the new process is *not* an independent browser.
  It hands its command line to the Chrome that is already running and exits.
  So no window appears, no debugging port opens, and the app has nothing to
  drive. Under Wine the same thing looks like "process exited with 0".

The fix keeps the real marker (`EBWebView`, which only WebView2 creates) and
drops the two that only meant "this is a Chromium profile".

The second half of the file pins the *reporting*: a browser that exits at once
must fill `build_error`, because an empty reason is indistinguishable on screen
from "the button is broken".
"""

from __future__ import annotations

import pytest

from arena import browserwindow as bw


def _chrome_profile(root):
    """A profile folder exactly as Chrome leaves it after one run."""
    (root / "Default" / "Cache").mkdir(parents=True)
    (root / "Default" / "Network").mkdir(parents=True)
    (root / "Default" / "Local Storage").mkdir(parents=True)
    (root / "Local State").write_text("{}")
    return root


def test_the_chrome_profile_is_reused_on_every_later_launch(tmp_path):
    profile = _chrome_profile(tmp_path / "google-browser")
    assert bw._safe_profile(str(profile)) == str(profile), (
        "the app's own Chrome profile was refused after its first use, so "
        "Chrome started without --user-data-dir and exited into the running "
        "instance: no window, no port, no message")


def test_a_webview2_store_is_still_refused(tmp_path):
    profile = tmp_path / "webview"
    (profile / "EBWebView").mkdir(parents=True)
    assert bw._safe_profile(str(profile)) is None


def test_the_main_windows_profile_folder_is_refused_by_name(tmp_path):
    profile = tmp_path / "webview"
    profile.mkdir()
    assert bw._safe_profile(str(profile)) is None


def test_the_markers_only_name_webview2():
    """The tuple is the fix; a well-meaning addition would bring the bug back."""
    flat = [part for marker in bw._WEBVIEW2_MARKERS for part in marker]
    assert "EBWebView" in flat
    assert "Cache" not in flat and "Network" not in flat, (
        "Default/Cache and Default/Network belong to every Chromium profile, "
        "not to WebView2 -- listing them refuses the app's own profile")


# -- a browser that exits at once must say why ----------------------------

def test_a_browser_that_dies_on_startup_reports_it(monkeypatch, tmp_path):
    """`build_error` used to stay empty when the process exited immediately."""
    win = bw.BrowserWindow("https://www.google.com/", user_data_dir=str(tmp_path / "p"))

    class Dead:
        def __init__(self):
            self.returncode = 0

        def poll(self):
            return 0

        def terminate(self):
            pass

        def wait(self, *a):
            return 0

    monkeypatch.setattr(bw.BrowserWindow, "_candidates",
                        lambda self: [("C:\\chrome.exe", "chrome")])
    monkeypatch.setattr(bw, "free_port", lambda: 1234)
    monkeypatch.setattr(bw, "wait_for_debugger", lambda port, timeout=25.0: False)
    monkeypatch.setattr(bw.Path, "name",
                        property(lambda self: "chrome.exe"), raising=False)
    monkeypatch.setattr(bw.subprocess, "Popen",
                        lambda *a, **kw: Dead())

    win._launch()

    assert win.build_error, "a browser that exited at once left no reason"
    assert "exited" in win.build_error.lower()
    assert "close" in win.build_error.lower(), (
        "the reason must tell the person what to do -- an already-open Chrome "
        "is the cause")


# -- opening a window no matter what --------------------------------------

def test_the_next_browser_is_tried_when_the_first_will_not_start(monkeypatch, tmp_path):
    """Chrome first, but a sign-in in Edge beats a dead button in Chrome."""
    win = bw.BrowserWindow("https://www.google.com/",
                           user_data_dir=str(tmp_path / "p"))
    tried = []

    monkeypatch.setattr(bw.BrowserWindow, "_candidates",
                        lambda self: [("C:\\chrome.exe", "chrome"),
                                      ("C:\\msedge.exe", "edge")])

    def attempt(self, path, how):
        tried.append(how)
        return how == "edge"          # chrome refuses, edge works

    monkeypatch.setattr(bw.BrowserWindow, "_try_browser", attempt)
    win._launch()
    assert tried == ["chrome", "edge"], (
        "the app gave up after the first browser instead of trying the next")


def test_an_unreadable_browser_is_closed_and_the_next_one_tried(monkeypatch, tmp_path):
    """A window the app cannot read is not a window it should keep.

    desktop-23.log: Edge started, the window appeared, the debugging port never
    answered -- and the app kept it, so no cookies could ever be read. Retrying
    the same browser cannot help (it reuses its running instance), so the next
    candidate gets a turn and the unreadable process is closed first.
    """
    win = bw.BrowserWindow("https://www.google.com/",
                           user_data_dir=str(tmp_path / "p"))
    tried, closed = [], []

    class Alive:
        def poll(self):
            return None

    monkeypatch.setattr(bw.BrowserWindow, "_candidates",
                        lambda self: [("C:\\chrome.exe", "chrome"),
                                      ("C:\\msedge.exe", "edge")])

    def attempt(self, path, how):
        tried.append(how)
        self._proc = Alive()
        self._debug_ok = False
        self.build_error = "open but its debugging port never answered"
        self._close_proc()
        closed.append(how)
        return False

    monkeypatch.setattr(bw.BrowserWindow, "_try_browser", attempt)
    win._launch()
    assert tried == ["chrome", "edge"], (
        "an unreadable browser ended the attempt instead of passing the turn")
    assert closed == ["chrome", "edge"], (
        "a browser the app cannot read was left running")


def test_a_browser_that_hands_its_command_line_on_is_reported(monkeypatch, tmp_path):
    """No port *and* still alive is the "already running" case, and it must say so."""
    win = bw.BrowserWindow("https://www.google.com/",
                           user_data_dir=str(tmp_path / "p"))

    class Alive:
        def poll(self):
            return None

        def terminate(self):
            pass

        def wait(self, *a, **k):
            return 0

    monkeypatch.setattr(bw, "free_port", lambda: 4321)
    monkeypatch.setattr(bw, "wait_for_debugger", lambda port, timeout=None: False)
    monkeypatch.setattr(bw.subprocess, "Popen", lambda *a, **kw: Alive())
    win._try_browser("C:\\msedge.exe", "edge")
    assert "debugging port never answered" in (win.build_error or ""), (
        "an unreadable window was reported without a reason")


def test_the_last_resort_opens_the_page_without_reading_it(monkeypatch, tmp_path):
    """If nothing readable can start, the page still has to open somewhere."""
    win = bw.BrowserWindow("https://www.google.com/",
                           user_data_dir=str(tmp_path / "p"))
    opened = []
    monkeypatch.setattr(bw.BrowserWindow, "_candidates", lambda self: [])
    monkeypatch.setattr(bw, "find_browser", lambda: (None, "none"))
    win._launch()
    # No browser is a *reported* state, not a silent one: the pane stays on
    # HTTPS with saved cookies, which is what the rest of the app already does.
    assert win.build_error, "no browser at all was left without a reason"


def test_the_candidate_list_is_ordered_and_deduplicated(monkeypatch):
    win = bw.BrowserWindow("https://www.google.com/")
    monkeypatch.setenv("ARENA_BROWSER", "edge")
    monkeypatch.setattr(bw, "_by_name",
                        lambda name: {"chrome": "C:\\chrome.exe",
                                      "edge": "C:\\msedge.exe"}.get(name))
    names = [how for _path, how in win._candidates()]
    assert names[0] == "edge", "ARENA_BROWSER must stay in charge of the order"
    assert names.count("edge") == 1 and "chrome" in names
