"""The Google window as a real browser.

The whole appeal of this change is that a browser has none of WebView2's
failure modes: no message loop to obey, no COM apartment, no `shown` gate that
never opens. What can still go wrong is narrower, and these tests pin exactly
that down:

* which executable is picked, and what happens when the default browser cannot
  be driven at all (Firefox);
* whether a window that answered is ever confused with one that did not;
* whether closing the app can kill a browser window the app did not open;
* whether the cookie jar and the page scripts come back in the shape the
  engine expects.

Nothing here starts a browser: the transport is `websocket` + HTTP, so the
logic is tested against stand-ins and the Win32 calls are stubbed.
"""

from __future__ import annotations

import json
import subprocess

import pytest

from arena import browserwindow as bw


# -- finding the browser ---------------------------------------------------

def test_the_configured_browser_is_preferred_over_the_windows_default(monkeypatch):
    """Chrome by default, whatever Windows has registered for links.

    The default browser can be anything -- including a Store build whose command
    line never reaches the process, or a browser that cannot be read at all.
    The app asks for a browser it can drive instead.
    """
    monkeypatch.setattr(bw, "_user_choice_browser", lambda: r"C:\Edge\msedge.exe")
    monkeypatch.setattr(bw, "_by_name", lambda name: r"C:\Chrome\chrome.exe")
    path, how = bw.find_browser()
    assert path == r"C:\Chrome\chrome.exe", (
        "the Windows default was used although a driveable browser exists")
    assert how == "chrome"


def test_a_firefox_default_falls_back_to_what_can_be_driven(monkeypatch):
    """Firefox cannot be asked for its cookies, so signing in there is a dead end.

    The person would sign in successfully and the app would then have no way to
    read the session -- the worst outcome, because it looks like success.
    """
    monkeypatch.setattr(bw, "_user_choice_browser", lambda: None)
    monkeypatch.setattr(bw, "chromium_fallback", lambda: r"C:\Chrome\chrome.exe")
    monkeypatch.setattr(bw, "_by_name", lambda name: r"C:\Chrome\chrome.exe")
    path, how = bw.find_browser()
    assert path == r"C:\Chrome\chrome.exe"
    assert how == "chrome", "Chrome is chosen by name, not by being installed"


def test_no_browser_at_all_is_reported_not_guessed(monkeypatch):
    monkeypatch.setattr(bw, "_user_choice_browser", lambda: None)
    monkeypatch.setattr(bw, "chromium_fallback", lambda: None)
    monkeypatch.setattr(bw, "_by_name", lambda name: None)
    assert bw.find_browser() == (None, "none")


def test_a_quoted_command_line_yields_its_executable(monkeypatch):
    monkeypatch.setattr(bw.os.path, "isfile", lambda p: True)
    assert bw._exe_from_command(
        r'"C:\Program Files\Microsoft\Edge\Application\msedge.exe" -- "%1"'
    ) == r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"


def test_a_firefox_progid_is_not_accepted(monkeypatch):
    """The ProgId lookup must reject Firefox rather than hand it to the app."""
    monkeypatch.setattr(bw, "_exe_from_command",
                        lambda cmd: r"C:\Firefox\firefox.exe")
    # `_exe_for_progid` needs winreg; on Linux it fails closed, which is fine,
    # so the contract being tested is the one in `_exe_for_progid` itself.
    import types
    fake = types.SimpleNamespace(
        HKEY_CURRENT_USER=1, HKEY_CLASSES_ROOT=2,
        OpenKey=lambda *a, **k: (_ for _ in ()).throw(OSError("no key")),
        QueryValueEx=lambda *a, **k: ("", 0),
    )
    monkeypatch.setitem(__import__("sys").modules, "winreg", fake)
    assert bw._exe_for_progid("FirefoxURL") is None


# -- the window ------------------------------------------------------------

class FakeProc:
    """A browser that is running, or not."""

    def __init__(self, running=True):
        self._running = running
        self.terminated = False

    def poll(self):
        return None if self._running else 0

    def terminate(self):
        self.terminated = True
        self._running = False


def test_a_window_is_ready_only_when_its_port_answers(monkeypatch):
    win = bw.BrowserWindow("https://www.google.com/")
    win._proc = FakeProc()
    assert win.is_ready() is False
    win._debug_ok = True
    assert win.is_ready() is True


def test_wait_built_says_no_when_the_browser_died(monkeypatch):
    """A closed window must not be reported as a working one.

    The startup path uses this answer to decide whether to keep the browser or
    fall back; "created" was never the same thing as "works".
    """
    win = bw.BrowserWindow("https://www.google.com/")
    win._proc = FakeProc(running=False)
    assert win.wait_built(0.3) is False


def test_wait_built_says_yes_once_the_port_answers():
    win = bw.BrowserWindow("https://www.google.com/")
    win._proc = FakeProc()
    win._debug_ok = True
    assert win.wait_built(0.3) is True


def test_destroy_closes_only_the_window_the_app_opened():
    """The person's other windows must survive the app closing.

    The app is not the owner of their browser; it owns one process it started,
    and `terminate()` is the most it may do.
    """
    win = bw.BrowserWindow("https://www.google.com/")
    proc = FakeProc()
    win._proc = proc
    closed = []
    win.events.closed += lambda: closed.append(1)
    win.destroy()
    assert proc.terminated is True
    assert closed == [1]


def test_hide_does_not_touch_the_browser():
    """Closing the window on sign-in destroyed the session before it was read.

    Hiding used to be the engine's way of tidying up; with a real browser the
    window is the person's, and the jar still has to be read out of it.
    """
    win = bw.BrowserWindow("https://www.google.com/")
    proc = FakeProc()
    win._proc = proc
    win.hide()
    assert proc.terminated is False


def test_a_window_with_no_debugging_port_reports_no_cookies():
    """Silently returning zero made every failed read look like "signed out"."""
    win = bw.BrowserWindow("https://www.google.com/")
    win._debug_ok = False
    assert win.cookie_tuples() == []
    assert win.clear_cookies() is False


def test_a_failed_launch_is_reported_not_hidden(monkeypatch):
    monkeypatch.setattr(bw, "find_browser", lambda: (None, "none"))
    win = bw.BrowserWindow("https://www.google.com/")
    win._launch()
    assert win.build_error
    assert win.wait_built(0.1) is False
    assert win.state()["build_error"]


# -- the transport ---------------------------------------------------------

def test_cookies_come_back_as_the_triples_the_engine_expects(monkeypatch):
    win = bw.BrowserWindow("https://www.google.com/")
    win._debug_ok = True
    monkeypatch.setattr(bw, "page_tab",
                        lambda port, domains: {"webSocketDebuggerUrl": "ws://x"})
    monkeypatch.setattr(bw, "all_cookies_raw", lambda url: [
        {"name": "SID", "value": "abc", "domain": ".google.com"},
        {"name": "SSID", "value": "def", "domain": ".google.com"}])
    assert win.cookie_tuples() == [("SID", "abc", ".google.com"),
                                  ("SSID", "def", ".google.com")]


def test_cookies_of_another_site_are_left_alone(monkeypatch):
    """One transport now serves two sites; the jars must not mix.

    Reading every cookie in the browser profile and handing all of them to one
    site would send arena's cookies to Google and the reverse.
    """
    win = bw.BrowserWindow("https://www.google.com/", domains=bw.GOOGLE_DOMAINS)
    win._debug_ok = True
    monkeypatch.setattr(bw, "page_tab",
                        lambda port, domains: {"webSocketDebuggerUrl": "ws://x"})
    monkeypatch.setattr(bw, "all_cookies_raw", lambda url: [
        {"name": "SID", "value": "google", "domain": ".google.com"},
        {"name": "arena-auth-prod-v1.0", "value": "arena", "domain": ".arena.ai"}])
    assert win.cookie_tuples() == [("SID", "google", ".google.com")]


def test_an_arena_window_reads_arena_cookies(monkeypatch):
    win = bw.BrowserWindow("https://arena.ai/", domains=bw.ARENA_DOMAINS)
    win._debug_ok = True
    monkeypatch.setattr(bw, "page_tab",
                        lambda port, domains: {"webSocketDebuggerUrl": "ws://x"})
    monkeypatch.setattr(bw, "all_cookies_raw", lambda url: [
        {"name": "SID", "value": "google", "domain": ".google.com"},
        {"name": "arena-auth-prod-v1.0", "value": "arena", "domain": ".arena.ai"}])
    assert win.cookie_tuples() == [
        ("arena-auth-prod-v1.0", "arena", ".arena.ai")]


def test_cdp_returns_none_instead_of_raising(monkeypatch):
    """A closed browser mid-command must not take down the caller."""
    def boom(*a, **kw):
        raise OSError("connection refused")

    import types
    fake = types.SimpleNamespace(create_connection=boom)
    monkeypatch.setitem(__import__("sys").modules, "websocket", fake)
    assert bw.cdp("ws://x", "Network.getAllCookies") is None


def test_evaluate_decodes_the_value_and_survives_an_exception(monkeypatch):
    replies = {"ok": {"result": {"result": {"value": "www.google.com"}}},
               "boom": {"result": {"exceptionDetails": {"text": "nope"}}}}
    monkeypatch.setattr(bw, "cdp", lambda *a, **kw: replies["ok"])
    assert bw.evaluate("ws://x", "location.host") == "www.google.com"
    monkeypatch.setattr(bw, "cdp", lambda *a, **kw: replies["boom"])
    assert bw.evaluate("ws://x", "throw 1") is None


def test_host_is_read_from_the_page_url(monkeypatch):
    win = bw.BrowserWindow("https://www.google.com/")
    win._debug_ok = True
    monkeypatch.setattr(bw, "page_tab", lambda port, domains: {
        "webSocketDebuggerUrl": "ws://x",
        "url": "https://accounts.google.com/signin",
    })
    assert win.host() == "accounts.google.com"


# -- what the engine needs from `native` ----------------------------------

def test_native_is_none_so_the_engine_skips_webview2(monkeypatch):
    """`google_ai` branches on `window.native`; None means "no COM here"."""
    win = bw.BrowserWindow("https://www.google.com/")
    assert win.native is None
    monkeypatch.setattr(bw.BrowserWindow, "start", lambda self: True)
    adapter = bw.EngineBrowserWindow(win)
    assert adapter.native is None
    assert adapter.webview is None


def test_the_adapter_exposes_what_attach_subscribes_to(monkeypatch):
    monkeypatch.setattr(bw.BrowserWindow, "start", lambda self: True)
    adapter = bw.EngineBrowserWindow(bw.BrowserWindow("https://x/"))
    for name in ("loaded", "shown", "closing", "closed"):
        assert hasattr(adapter.events, name), name


def test_the_engine_switch_still_reaches_the_old_host(monkeypatch):
    """`ARENA_GOOGLE_WINDOW=webview2` must bypass the browser entirely."""
    from arena import desktop
    called = []
    monkeypatch.setenv("ARENA_GOOGLE_WINDOW", "webview2")
    monkeypatch.setattr("arena.browserwindow.create_google_window",
                        lambda **kw: called.append("browser"))

    class Host:
        def wait_built(self, t=8.0):
            return True

        def state(self):
            return {}

    monkeypatch.setattr("arena.webwindow.create_google_window",
                        lambda **kw: Host())
    win = desktop.make_google_window("dir")
    assert called == []
    assert isinstance(win, Host)


# -- the name lookup that stopped every window from opening -----------------

def test_short_names_find_the_browser(monkeypatch, tmp_path):
    """`_by_name("chrome")` looked up a key that does not exist.

    desktop-23.log: "no browser found to open Google in" on a machine with both
    Chrome and Edge installed, and neither window ever opened. The table is
    keyed by display name ("Google Chrome"), while the switch and the fallback
    list use short names -- so the lookup answered None for every browser.
    """
    chrome = tmp_path / "chrome.exe"
    chrome.write_text("x")
    monkeypatch.setitem(bw.CHROMIUM_CANDIDATES, "Google Chrome", [str(chrome)])
    monkeypatch.setitem(bw.CHROMIUM_CANDIDATES, "others", [])
    for name in ("chrome", "Chrome", "google chrome", "Google Chrome"):
        assert bw._by_name(name) == str(chrome), f"short name {name!r} found nothing"


def test_the_registry_is_consulted_for_a_store_build(monkeypatch, tmp_path):
    """A Store (MSIX) browser has no plain file, but it does register a path."""
    real = tmp_path / "msedge.exe"
    real.write_text("x")
    monkeypatch.setattr(bw, "_exe_from_app_paths",
                        lambda exe: str(real) if exe == "msedge.exe" else None)
    monkeypatch.setitem(bw.CHROMIUM_CANDIDATES, "Microsoft Edge", [])
    assert bw._by_name("edge") == str(real)


def test_the_debugger_listens_on_loopback_only():
    """The flags must make a real loopback listener, not just ask politely."""
    from pathlib import Path
    source = Path(bw.__file__).read_text()
    assert "--remote-debugging-address=127.0.0.1" in source, (
        "without an explicit bind address the debugging port is refused or "
        "never opened, and the window stays unreadable")
