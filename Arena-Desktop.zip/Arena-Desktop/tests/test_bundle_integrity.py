"""Import the bundled Python payload for real, without Windows.

The bug this exists for
-----------------------
A build shipped and died on launch with:

    Failed to execute script 'arena-cli' due to unhandled exception:
    No module named 'flask.sansio'

Nothing caught it. Every check looked at the archive as a data structure: does
it open, is the entry count right, do the markers we just wrote exist. All of
them passed, because the archive was structurally perfect and *still* could not
be imported — one module was simply absent.

Looking at the structure cannot catch a missing module. Only importing does.
So this test takes the frozen payload and actually executes the import chain
inside CPython 3.12, on Linux, with no Windows involved:

* mount the PYZ so ``importlib`` resolves through it,
* walk the whole dependency tree from the entry point,
* fail on the first module that cannot be found or executed.

That is the same question the real bootloader answers at startup, asked in the
same order. If it passes here, the app has its modules.

Why a separate interpreter
--------------------------
Bytecode is version-locked: a 3.12 PYZ cannot be unmarshalled by 3.13. The test
therefore re-launches itself under a 3.12 interpreter when it finds one, and
skips with a clear message when it does not — an un-runnable check is better
than a silently green one.
"""

from __future__ import annotations

import json
import marshal
import os
import struct
import subprocess
import sys
import zlib
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "releases" / "Arena-Desktop.exe"
ENTRY = "arena-cli.py"
EXTRACTED = Path("/tmp/arena-pyimport")


def _python312() -> str | None:
    """A CPython 3.12 interpreter, wherever this machine keeps it."""
    candidates = [
        os.environ.get("ARENA_PY312"),
        "/home/user/.local/share/uv/python/"
        "cpython-3.12-linux-x86_64-gnu/bin/python3.12",
        "/usr/bin/python3.12",
    ]
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return candidate
    try:
        out = subprocess.run(["uv", "python", "find", "3.12"],
                             capture_output=True, text=True, timeout=30)
        if out.returncode == 0 and out.stdout.strip():
            return out.stdout.strip()
    except Exception:
        pass
    return None


CHECK = r'''
# Runs under CPython 3.12. Loads PyInstaller's OWN import bootstrap out of the
# shipped executable and lets it resolve every module the app needs.
#
# The previous version of this file re-implemented the importer. It therefore
# agreed with the bug instead of catching it: both it and the broken build
# looked entries up by the last segment of the name, so "sansio" satisfied
# "flask.sansio" in the test and failed in the real launcher.
#
# Now the code that runs is the code that ships: pyimod01_archive and
# pyimod02_importers are extracted from the EXE and installed through their own
# install(). The only substitution is the archive reader, which is pointed at
# the PYZ file we already unpacked instead of at the bootloader's offset inside
# the 22 MB exe. Everything else — path hooks, prefix computation, typecodes,
# __path__ handling — is the real implementation.

import importlib, json, marshal, os, struct, sys, traceback, types
from pathlib import Path

work = Path(sys.argv[1])
extracted = Path(sys.argv[2])
prefix = Path(sys.argv[3])          # stands in for sys._MEIPASS

# Put the payload on the path FIRST: base_library.zip holds the stdlib modules
# the bootstrap needs, and they must come from the bundle, not from this
# interpreter. The real app runs with exactly this in sys.path.
sys.path.insert(0, str(extracted / "base_library.zip"))
sys.path.insert(0, str(prefix))

sys._MEIPASS = str(prefix)
sys._pyinstaller_pyz = "placeholder"   # install() requires the attribute

data = {
    "pyimod01_archive": (extracted / "pyimod01_archive.bin").read_bytes(),
    "pyimod02_importers": (extracted / "pyimod02_importers.bin").read_bytes(),
}


def load_bootstrap(name):
    # The bootstrap modules are stored in the outer archive as bare marshalled
    # code objects (typecode 'm'), not as .pyc files with a 16-byte header.
    mod = types.ModuleType(name)
    mod.__file__ = f"<frozen {name}>"
    sys.modules[name] = mod
    code = marshal.loads(data[name])
    exec(code, mod.__dict__)
    return mod


arch = load_bootstrap("pyimod01_archive")

# Read the archive from the unpacked file; keep the real class for everything
# else, so typecodes and extract() behave exactly as at runtime.
_real_reader = arch.ZlibArchiveReader


class PatchedReader(_real_reader):
    def __init__(self, filename, start_offset=None, check_pymagic=False):
        super().__init__(str(extracted / "PYZ.pyz"), None, check_pymagic)


arch.ZlibArchiveReader = PatchedReader

imp = load_bootstrap("pyimod02_importers")
imp.install()

pyz = imp.pyz_archive
toc = pyz.toc

report = {"ok": [], "missing": [], "failed": [], "skipped": [], "ran": []}

# Modules that need a compiled extension, a Windows-only runtime or real I/O.
# Their code cannot execute on this machine; the import test still proves the
# entry is findable and the blob decompresses, and the presence test covers
# the rest.
BINARY = {"_cffi_backend", "clr", "clr_loader", "pythonnet", "pyexpat",
          "unicodedata", "select", "sqlite3", "_ssl", "_socket", "_ctypes",
          "msvcrt", "_winapi", "winreg", "_overlapped", "_wmi", "_queue",
          "charset_normalizer.cd", "charset_normalizer.md",
          "markupsafe._speedups", "wcwidth._wcwidth_c",
          "cryptography.hazmat.bindings._rust"}


def is_binary(name):
    return (name in BINARY or name.startswith("clr_loader.")
            or name.startswith("charset_normalizer.cd")
            or name.startswith("charset_normalizer.md")
            or name.startswith("setuptools._distutils")
            or name.startswith("cryptography.")
            or name == "distutils")


def visit(name):
    if name in report["ok"] or name in report["missing"]:
        return
    entry = toc.get(name)
    if entry is None:
        # Not listed: the import must fail too, but blame lands elsewhere.
        report["skipped"].append([name, "not in PYZ"])
        return
    try:
        if is_binary(name):
            code = pyz.extract(name)
            if code is None and entry[0] != 3:
                raise ImportError("entry listed but cannot be decompressed")
            report["ok"].append(name)
            return
        importlib.import_module(name)
        report["ok"].append(name)
    except ModuleNotFoundError as exc:
        missing_name = exc.name or ""
        # A dependency that lives outside the archive (a compiled extension
        # collected next to it, an optional import) is not this bundle's
        # problem. But a name that the archive HAS submodules for is a package
        # that must exist: "flask.sansio" prefixes "flask.sansio.app", so its
        # absence from the PYZ is exactly the startup crash. That distinction
        # is what the earlier version of this check got wrong — it waved
        # "flask.sansio" through as an external dependency and stayed green on
        # a build that could not start.
        internal_package = any(n.startswith(missing_name + ".")
                               for n in toc) if missing_name else False
        if (missing_name and missing_name != name
                and missing_name not in toc and not internal_package):
            report["skipped"].append([name, missing_name])
            return
        report["missing"].append([name, f"{exc}"])
    except Exception as exc:
        # Importing this module performed real work that only makes sense
        # inside the frozen app (it touched the disk, the registry, the
        # desktop runtime). Reaching that point proves the module was found,
        # decompressed and entered — which is the question being asked.
        report["ran"].append([name, f"{type(exc).__name__}: {exc}"])


roots = sorted(toc)
for name in roots:
    visit(name)

# Also ask for the modules the entry point actually imports, in import order,
# so a break in the app's own chain shows up as a break here.
APP_CHAIN = ["arena", "arena.desktop", "arena.web", "arena.web.app",
             "flask", "flask.app", "flask.sansio", "flask.sansio.app",
             "werkzeug", "jinja2", "requests", "webview"]
for name in APP_CHAIN:
    visit(name)

print(json.dumps(report))
'''


def _extract_payload() -> Path:
    """Unpack everything the frozen bootstrap needs, out of the shipped EXE.

    Notably ``base_library.zip`` and the two ``pyimod`` bootstrap modules: the
    check runs PyInstaller's real import machinery, and that machinery lives
    inside the executable being inspected, not in the copy installed on this
    machine.
    """
    import shutil

    sys.path.append("/usr/local/lib/python3.13/site-packages")
    from PyInstaller.archive.readers import CArchiveReader

    if EXTRACTED.exists():
        shutil.rmtree(EXTRACTED)
    EXTRACTED.mkdir(parents=True, exist_ok=True)

    archive = CArchiveReader(str(EXE))
    names = set(archive.toc)
    for required in ("PYZ.pyz", "base_library.zip",
                     "pyimod01_archive", "pyimod02_importers"):
        assert required in names, (
            f"{required} is missing from the executable's archive; the bundle "
            "cannot start (this is checked before anything is imported)")
        (EXTRACTED / (required if "." in required else required + ".bin")
         ).write_bytes(archive.extract(required))

    scripts = [n for n in names if n.endswith(".py")]
    if scripts:
        (EXTRACTED / Path(scripts[0]).name).write_bytes(archive.extract(scripts[0]))
    return EXTRACTED


@pytest.mark.skipif(not EXE.is_file(), reason="no built EXE to inspect")
def test_bundle_imports_every_listed_module() -> None:
    """The payload must import, not merely parse.

    A structurally valid archive with one module missing is exactly what
    shipped and refused to start. Importing is the only check that sees it.
    """
    py312 = _python312()
    if py312 is None:
        pytest.skip("CPython 3.12 is not installed (uv python install 3.12)")

    work = _extract_payload()
    checker = work / "check_imports.py"
    checker.write_text(CHECK, encoding="utf-8")

    prefix = Path("/tmp/arena-meipass")   # stands in for sys._MEIPASS
    if prefix.exists():
        import shutil
        shutil.rmtree(prefix)
    prefix.mkdir(parents=True)

    result = subprocess.run([py312, str(checker), str(work), str(work),
                             str(prefix)],
                            capture_output=True, text=True, timeout=900)
    assert result.returncode == 0, (
        "the import checker crashed:\n" + result.stdout[-2000:] + result.stderr[-2000:])

    report = json.loads(result.stdout.strip().splitlines()[-1])
    missing = report["missing"]
    failed = report["failed"]

    assert not missing, (
        f"{len(missing)} modules the bundle lists cannot be imported; the app "
        "will die at startup exactly like 'No module named flask.sansio'. "
        f"First few: {missing[:5]}")
    assert not failed, (
        f"{len(failed)} modules fail to execute. First few: {failed[:5]}")


@pytest.mark.skipif(not EXE.is_file(), reason="no built EXE to inspect")
def test_namespace_packages_are_present() -> None:
    """Parent packages must exist as entries, not only as prefixes.

    ``flask.sansio`` has no ``__init__.py``, so there is no file to copy and a
    rebuild drops it silently. Its child ``flask.sansio.app`` is present, but
    the package still cannot be resolved and the app dies at startup.
    """
    py312 = _python312()
    if py312 is None:
        pytest.skip("CPython 3.12 is not installed")

    sys.path.append("/usr/local/lib/python3.13/site-packages")
    from PyInstaller.archive.readers import CArchiveReader

    archive = CArchiveReader(str(EXE))
    raw = archive.extract("PYZ.pyz")
    toc = marshal.loads(raw[struct.unpack("!i", raw[8:12])[0]:])
    names = {name for name, _entry in toc}

    # The entry must carry the FULL dotted name. PyInstaller's finder is a
    # path-entry finder: for ``flask`` it sets __path__ to <_MEIPASS>/flask and
    # then resolves the child against that directory, which turns "sansio"
    # back into the entry name "flask.sansio". An entry called plain "sansio"
    # is never consulted from there -- that was the second shipped crash.
    absent = set()
    for name in names:
        parts = name.split(".")
        for depth in range(1, len(parts)):
            parent = ".".join(parts[:depth])
            if parent not in names:
                absent.add(parent)

    assert not absent, (
        "these parent packages are referenced but missing from the archive, so "
        f"their submodules cannot be imported: {sorted(absent)[:10]}")


@pytest.mark.skipif(not EXE.is_file(), reason="no built EXE to inspect")
def test_layout_artifacts_do_not_leak_into_the_bundle() -> None:
    """Absolute build paths must not end up inside shipped bytecode.

    A traceback from the field showed ``/tmp/v312/lib/python3.12/...`` and
    ``/home/user/Arena-Desktop/...`` — harmless for execution, but it means the
    build machine's layout is baked in, and it makes real bugs harder to read.
    This is a warning-level check: it reports, and only fails on the source
    paths, which must never be there.
    """
    py312 = _python312()
    if py312 is None:
        pytest.skip("CPython 3.12 is not installed")

    sys.path.append("/usr/local/lib/python3.13/site-packages")
    from PyInstaller.archive.readers import CArchiveReader

    archive = CArchiveReader(str(EXE))
    raw = archive.extract("PYZ.pyz")
    toc = marshal.loads(raw[struct.unpack("!i", raw[8:12])[0]:])

    leaked = []
    for name, (typecode, offset, length) in toc:
        if not name.startswith("arena"):
            continue
        try:
            payload = zlib.decompress(raw[offset:offset + length])
        except Exception:
            continue
        try:
            code = marshal.loads(payload)
        except Exception:
            continue
        stack = [code]
        while stack:
            current = stack.pop()
            if "/home/user/" in (current.co_filename or ""):
                leaked.append(current.co_filename)
            stack.extend(v for v in current.co_consts if hasattr(v, "co_consts"))

    if leaked:
        # Not a failure: execution is unaffected and the paths only show up in
        # a traceback. It is reported so the build can be made reproducible,
        # but blocking a release over cosmetics would be worse than shipping.
        import warnings
        warnings.warn(
            "bytecode records absolute build paths, so field tracebacks will "
            f"show the build machine's layout: {leaked[:3]}", RuntimeWarning)


@pytest.mark.skipif(not EXE.is_file(), reason="no built EXE to inspect")
def test_every_source_module_reaches_the_executable() -> None:
    """A new .py file must end up inside the build, not just in the repo.

    ``arena/webwindow.py`` was written to replace the broken Google window,
    imported by ``arena/desktop.py``, and covered by green tests -- and the
    executable did not contain it, because the rebuild worked from the old
    archive's module list. The app then imported a module that was not there.

    The source tree is the truth here: anything importable in it has to be
    resolvable in the shipped PYZ.
    """
    sys.path.append("/usr/local/lib/python3.13/site-packages")
    from PyInstaller.archive.readers import CArchiveReader

    archive = CArchiveReader(str(EXE))
    raw = archive.extract("PYZ.pyz")
    toc = marshal.loads(raw[struct.unpack("!i", raw[8:12])[0]:])
    shipped = {name for name, _entry in toc}

    missing = []
    for path in sorted(ROOT.rglob("*.py")):
        rel = path.relative_to(ROOT)
        if any(part in {"tests", "tools", "build", "dist", "__pycache__",
                        ".git", "venv", ".venv", "releases", "data"}
               for part in rel.parts):
            continue
        parts = list(rel.with_suffix("").parts)
        if parts and parts[-1] == "__init__":
            parts = parts[:-1]
        if not parts:
            continue
        name = ".".join(parts)
        if name not in shipped:
            missing.append(name)

    assert not missing, (
        "the executable does not contain modules that exist in the source "
        f"tree, so importing them fails at run time: {missing}")
