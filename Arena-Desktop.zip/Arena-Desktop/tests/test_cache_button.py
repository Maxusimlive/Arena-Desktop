"""The cache button, and the two bugs behind "the button did nothing".

Three separate complaints from the person, each with its own cause:

* "add a clear-cache button" -- and they were right about why: a stale Google
  account, a half-finished browser profile and a catalog remembered as empty
  each broke a build that was otherwise fine;
* "the Google button opened nothing and then showed a tick";
* "the text on that screen is unreadable" -- a note placed in the 22px icon
  column of a grid, so every word got its own line.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from arena import appcache, browserwindow as bw

ROOT = Path(__file__).resolve().parent.parent


# -- what the cache wipe may and may not touch -----------------------------

def _populate(tmp_path):
    """A data folder with both cache and irreplaceable data in it."""
    (tmp_path / "google-browser").mkdir()
    (tmp_path / "google-browser" / "Cookies").write_text("x" * 2000)
    (tmp_path / "arena-browser").mkdir()
    (tmp_path / "arena-browser" / "Cookies").write_text("y" * 500)
    (tmp_path / "models_cache.json").write_text("{}")
    (tmp_path / "desktop-3.log").write_text("old run")
    # data, not cache:
    (tmp_path / "chats").mkdir()
    (tmp_path / "chats" / "chat.json").write_text('{"title": "keep me"}')
    (tmp_path / "cookies.txt").write_text("arena session")
    (tmp_path / "config.json").write_text('{"setting": 1}')
    (tmp_path / "workspace").mkdir()
    (tmp_path / "workspace" / "notes.md").write_text("my work")
    return tmp_path


def test_the_cache_wipe_reports_what_it_removed(tmp_path):
    data = _populate(tmp_path)
    result = appcache.clear(data)
    assert "google-browser" in result["removed"]
    assert "arena-browser" in result["removed"]
    assert "models_cache.json" in result["removed"]
    assert result["freed"] >= 2500
    assert result["skipped"] == []


def test_the_cache_wipe_never_touches_the_persons_data(tmp_path):
    """The user was explicit: the cache *inside the app*, not their folder.

    Deleting a chat history to fix a stuck window would be a catastrophe
    dressed up as a fix, so this is pinned rather than assumed.
    """
    data = _populate(tmp_path)
    appcache.clear(data)
    assert (data / "chats" / "chat.json").read_text() == '{"title": "keep me"}'
    assert (data / "cookies.txt").read_text() == "arena session"
    assert (data / "config.json").read_text() == '{"setting": 1}'
    assert (data / "workspace" / "notes.md").read_text() == "my work"


def test_a_profile_in_use_can_be_kept(tmp_path):
    data = _populate(tmp_path)
    result = appcache.clear(data, keep=("google-browser",))
    assert (data / "google-browser").exists(), (
        "a profile a live window is using must survive the wipe")
    assert "arena-browser" in result["removed"]


def test_the_summary_lists_the_cache_and_its_size(tmp_path):
    data = _populate(tmp_path)
    summary = appcache.summary(data)
    ids = [item["id"] for item in summary["items"]]
    assert "google-browser" in ids and "models_cache.json" in ids
    assert summary["bytes"] >= 2500
    # data is not cache, so it is not offered for deletion
    assert "chats" not in ids and "cookies.txt" not in ids


def test_the_live_log_is_never_deleted(tmp_path, monkeypatch):
    """Deleting the log being written stops the log for the rest of the run.

    On Linux the unlink even *succeeds*, and the app keeps writing into a
    deleted file: the worst kind of quiet failure.
    """
    data = _populate(tmp_path)
    live = data / "desktop.log"
    live.write_text("current run")
    monkeypatch.setattr("arena.diag.log_path", lambda: live)
    appcache.clear(data)
    assert live.exists(), "the current run's log was deleted"


def test_clearing_a_missing_folder_is_not_an_error(tmp_path):
    result = appcache.clear(tmp_path / "does-not-exist")
    assert result["removed"] == [] and result["skipped"] == []


# -- why the Google button opened nothing ---------------------------------

def test_a_real_chrome_profile_is_not_mistaken_for_webview2(tmp_path):
    """This is the bug that made the button silently do nothing.

    `Default/Cache` and `Default/Network` are ordinary Chrome folders, and they
    were listed as WebView2 markers. So from the **second** launch on, the
    app's own `google-browser` profile was refused, the browser was started
    without `--user-data-dir`, and Chrome -- already running for the person --
    took the command line and exited. No window, no port, no message.
    """
    profile = tmp_path / "google-browser"
    (profile / "Default" / "Cache").mkdir(parents=True)
    (profile / "Default" / "Network").mkdir(parents=True)
    assert bw._safe_profile(str(profile)) == str(profile), (
        "an ordinary Chrome profile was refused, so Chrome starts without "
        "--user-data-dir and the sign-in window never appears")


def test_a_real_webview2_store_is_still_refused(tmp_path):
    profile = tmp_path / "whatever"
    (profile / "EBWebView").mkdir(parents=True)
    assert bw._safe_profile(str(profile)) is None


def test_a_browser_that_exits_at_once_says_so():
    """A chrome that forwards to a running instance must not be silent."""
    source = (ROOT / "arena" / "browserwindow.py").read_text()
    assert "the browser exited at once" in source, (
        "a browser that dies on startup leaves build_error empty, so the UI "
        "cannot tell the person why nothing opened")


def test_the_sign_in_answer_carries_the_diagnosis():
    source = (ROOT / "arena" / "web" / "app.py").read_text()
    assert '"diagnosis": _google_window_diagnosis(engine)' in source, (
        "the sign-in endpoint still answers a bare 'pending', so the screen "
        "cannot say why no window appeared")


def test_the_diagnosis_names_the_three_failure_modes():
    source = (ROOT / "arena" / "web" / "app.py").read_text()
    for state in ('"state": "none"', '"state": "failed"', '"state": "unreadable"'):
        assert state in source, f"the diagnosis never reports {state}"


def test_a_closed_window_does_not_count_as_an_open_sign_in():
    """`visible` is "we asked once", not "there is a window".

    After the person closed the browser, every later sign-in click returned
    early because the engine still believed a window was up. That is exactly
    "the button does nothing".
    """
    from arena import google_ai

    engine = google_ai.GoogleEngine()

    class Closed:
        running = False

        def state(self):
            return {"platform": "browser", "running": False}

    class Lazy:
        window = Closed()

    engine.window = Lazy()
    engine.visible = True                     # left over from the first click
    assert engine._window_is_live() is False, (
        "a closed window still counted as an open sign-in, so the click "
        "returned early and nothing appeared")


def test_sign_in_proceeds_when_the_old_window_is_gone():
    """The call site, not just the helper.

    `visible` stayed True after the person closed the browser, and open_sign_in
    returned early on it: no wipe, no navigation, no window. Pressing the
    button did visibly nothing, twice.
    """
    from arena import google_ai

    engine = google_ai.GoogleEngine()

    class Closed:
        def state(self):
            return {"platform": "browser", "running": False}

    class Lazy:
        window = Closed()

    engine.window = Lazy()
    engine.visible = True
    engine._shown_evt.set()               # the old gate would say "already open"

    cleared, loaded = [], []
    engine.clear_cookies = lambda: cleared.append(True)
    engine.load = lambda url: loaded.append(url)
    engine.show = lambda: None

    engine.open_sign_in(fresh=True)
    assert loaded and "google.com" in loaded[0], (
        "signing in after the window was closed did not navigate anywhere")


def test_a_running_window_still_counts_as_open():
    from arena import google_ai

    engine = google_ai.GoogleEngine()

    class Running:
        def state(self):
            return {"platform": "browser", "running": True, "build_error": None}

    class Lazy:
        window = Running()

    engine.window = Lazy()
    assert engine._window_is_live() is True


# -- the unreadable text on the sign-in screen ----------------------------

def test_the_step_note_spans_the_whole_row():
    """One word per line was a grid-placement bug, not a long sentence."""
    css = (ROOT / "arena" / "web" / "static" / "style.css").read_text()
    start = css.index(".boot-step-note {")
    block = css[start:css.index("}", start)]
    assert "grid-column: 2 / -1" in block, (
        "the note falls into the 22px icon column, so every word gets its own "
        "line -- the wall of words in the screenshot")


def test_the_note_tells_the_person_about_the_cache():
    app_js = (ROOT / "arena" / "web" / "static" / "app.js").read_text()
    start = app_js.index("Google signs in inside its own window")
    text = app_js[start:start + 400]
    assert "clear the cache" in text.lower(), (
        "the screen does not mention the one thing that fixes a stuck window")


# -- the button itself -----------------------------------------------------

def test_the_boot_screen_has_the_cache_button():
    html = (ROOT / "arena" / "web" / "static" / "index.html").read_text()
    assert 'id="bootCache"' in html
    # left of the title, inside the card, above the head
    assert html.index('id="bootCache"') < html.index('class="boot-head"')


def test_settings_have_a_cache_section_in_both_modes():
    app_js = (ROOT / "arena" / "web" / "static" / "app.js").read_text()
    assert app_js.count("{ id: 'cache', label: 'Cache'") == 2, (
        "the cache section must exist for both Arena and Google AI mode")
    assert "function renderCachePanel()" in app_js
    assert "API.clearCache()" in app_js


def test_the_button_reports_what_it_cleared():
    """A button that says "done" without saying what changed is the same
    dishonesty that made the sign-in tick untrustworthy."""
    app_js = (ROOT / "arena" / "web" / "static" / "app.js").read_text()
    assert "function cacheResultText(" in app_js
    start = app_js.index("function cacheResultText(")
    body = app_js[start:start + 900]
    assert "freed" in body and "not touched" in body


# -- the app must not answer "no browser" on a Windows machine -------------

def test_no_window_ever_opened_because_the_lookup_used_the_wrong_key():
    """The round-7 regression, pinned by its symptom.

    desktop-23.log has both lines:
        browser window: no browser found to open Google in
        arena window: could not be created   (NameError: contracts)

    Chrome and Edge were both installed. The lookup table is keyed by display
    names and the callers pass short ones, so every browser "was not found" and
    both windows refused to open with a message about browsers that were there.
    """
    source = (ROOT / "arena" / "browserwindow.py").read_text()
    assert "_NAME_ALIASES" in source, (
        "short names are not mapped to the candidate table, so every lookup "
        "misses and no window opens")
    assert '"chrome": "Google Chrome"' in source
    assert "_exe_from_app_paths" in source, (
        "the registry is not consulted, so a Store build of Edge is invisible")


def test_the_arena_fallback_can_import_contracts():
    """NameError: name 'contracts' is not defined -- desktop-crash-7.log."""
    source = (ROOT / "arena" / "desktop.py").read_text()
    start = source.index("def make_arena_window")
    body = source[start:start + 2000]
    assert "from arena import contracts" in body, (
        "make_arena_window uses contracts.ORIGIN but relies on main() to "
        "import it, so the fallback raises NameError when it is reached")


def test_a_browser_window_does_not_wait_for_a_shown_event():
    """8 s of dead wait on every press, and the jar never became readable."""
    source = (ROOT / "arena" / "google_ai.py").read_text()
    fakes: list[str] = []
    assert 'getattr(self.window, "is_browser", False) is True' in source, (
        "the engine still waits for pywebview's `shown` event on a browser "
        "window, which never fires")
    assert "def _cookies_from_browser" in source, (
        "nothing reads the jar of the browser window that is actually running")


def test_the_engine_reads_the_browser_jar():
    from arena import google_ai

    engine = google_ai.GoogleEngine()

    class Browserish:
        is_browser = True

        def cookie_tuples(self, *a, **kw):
            return [("SID", "abc", ".google.com"), ("NID", "x", ".google.com"),
                    ("other", "no", ".example.com")]

    engine.window = Browserish()
    pairs = engine._cookies_from_browser()
    assert ("SID", "abc") in pairs and ("NID", "x") in pairs
    assert all(name != "other" for name, _ in pairs), (
        "cookies of another site leaked into the Google jar")
    assert engine.jar_signed_in() is True, (
        "a browser jar holding SID was not recognised as a session")


# -- the first click must actually do something ----------------------------

def test_the_first_click_wipes_and_navigates():
    """`_window_is_live()` was true from the moment the object existed.

    So `open_sign_in` concluded "sign-in is already open", returned early, and
    did nothing: no wipe, no navigation, no window -- on the very first press.
    That is the reported "the button opens nothing", still present after the
    profile bug was fixed.
    """
    from arena import google_ai

    engine = google_ai.GoogleEngine()

    class Browserish:
        is_browser = True

        def __init__(self):
            self.cleared = 0
            self.loads = []

        def show(self):
            pass

        def load_url(self, url):
            self.loads.append(url)
            return True

        def clear_cookies(self):
            self.cleared += 1
            return True

        def cookie_tuples(self):
            return []

        def state(self):
            return {"platform": "browser", "running": True, "build_error": None}

    window = Browserish()
    engine.window = window

    engine.open_sign_in(fresh=True)
    assert engine._window_is_live() is True, "the window is running"
    assert window.cleared == 1, "the jar was not wiped on the first click"
    assert window.loads and "google.com" in window.loads[0], (
        "the window was never sent to Google")

    # ... and the second click, now that a sign-in really is on screen, keeps it
    engine.open_sign_in(fresh=True)
    assert window.cleared == 1, (
        "a second click mid-password wiped the jar under the person again")
    assert len(window.loads) == 1


def test_a_closed_window_starts_over():
    """After the person closes the browser, the next click must start a new one."""
    from arena import google_ai

    engine = google_ai.GoogleEngine()

    class Browserish:
        is_browser = True

        def __init__(self):
            self.cleared = 0
            self.loads = []

        def show(self):
            pass

        def load_url(self, url):
            self.loads.append(url)
            return True

        def clear_cookies(self):
            self.cleared += 1
            return True

        def cookie_tuples(self):
            return []

        def state(self):
            return {"platform": "browser", "running": False, "build_error": None}

    window = Browserish()
    engine.window = window
    engine.open_sign_in(fresh=True)
    assert window.loads, "nothing was opened"
    # the person closed the browser
    engine._window_is_live = lambda: False
    engine.open_sign_in(fresh=True)
    assert len(window.loads) == 2, "a closed window was never reopened"


def test_the_diagnosis_carries_a_code_and_one_button():
    """The page must not read English prose to decide what to offer.

    A window the app cannot read has three causes -- a browser already running
    without its port, a port blocked by policy, a build that never took the
    flags -- and all three used to arrive as one sentence for the person to
    parse. `code` says which; `action` says what to do about it.
    """
    from arena.web import app as web

    class Inner:
        def __init__(self, state):
            self._state = state

        def state(self):
            return self._state

    class Engine:
        def __init__(self, state, host="www.google.com"):
            self.window = type("Lazy", (), {"window": Inner(state)})()
            self.host = host

    cases = {
        "already_running": "the browser exited at once (code 1)",
        "port_blocked_or_store_edge": "edge is open but its debugging port never answered",
    }
    for code, message in cases.items():
        got = web._google_window_diagnosis(
            Engine({"running": False, "build_error": message, "build_code": code}))
        assert got["state"] == "failed" and got["code"] == code, got
        assert got["action"] == {"kind": "cookies", "label": "Use cookies"}, (
            f"{code} must offer the cookie paste: it is the only road left")

    readable = web._google_window_diagnosis(
        Engine({"running": True, "debuggable": True, "build_error": None,
                "build_code": None}))
    assert readable["state"] == "open" and readable["code"] == "open", readable
    assert readable["action"] is None, "a working window needs no repair button"

    blind = web._google_window_diagnosis(
        Engine({"running": True, "debuggable": False, "build_error": None,
                "build_code": None}))
    assert blind["state"] == "unreadable" and blind["code"] == "unreadable", blind
    assert blind["action"]["kind"] == "cookies", blind
