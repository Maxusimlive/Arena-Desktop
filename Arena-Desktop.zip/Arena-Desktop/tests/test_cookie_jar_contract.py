"""What WebView2 actually hands back on a real Windows build.

The shipped crash reports and `desktop-22.log` describe one shape over and over:

    type=List[CoreWebView2Cookie] | has_is_completed=False
    status=unreadable(AttributeError: 'List[CoreWebView2Cookie]' object has
                      no attribute 'Status')

pythonnet does not give back a pending `Task` there — it gives back the finished
`List[CoreWebView2Cookie]`. That object is not a Python `list` either
(`isinstance(...) == False`), has no `IsCompleted`, no `Result`, and no
`Status`. Code written for a task reads a property that does not exist, the
`AttributeError` is swallowed by a broad `except`, and the caller is told "the
jar is empty" — for ever, on every poll.

These tests pin down the three places that made that mistake, using stand-ins
with exactly the .NET shape the logs record.
"""

from __future__ import annotations

import pytest

from arena import google_ai
from arena import webwindow
from arena.webwindow import _looks_like_task, _is_collection


class NetCookie:
    """One CoreWebView2Cookie: COM property getters, not plain fields."""

    def __init__(self, name, value, domain=".google.com"):
        self._n, self._v, self._d = name, value, domain

    @property
    def Name(self):
        return self._n

    @property
    def Value(self):
        return self._v

    @property
    def Domain(self):
        return self._d


class NetList:
    """`System.Collections.Generic.List[T]` as pythonnet exposes it.

    Deliberately NOT a Python list: that is the whole point. It is iterable,
    it has `.Count`, and it has no `IsCompleted`/`Result`/`Status`.
    """

    def __init__(self, items):
        self._items = list(items)

    def __iter__(self):
        return iter(self._items)

    @property
    def Count(self):
        return len(self._items)


# -- the shape helpers -----------------------------------------------------

def test_a_net_collection_is_not_mistaken_for_a_task():
    jar = NetList([NetCookie("SID", "abc")])
    assert _looks_like_task(jar) is False
    assert _is_collection(jar) is True


def test_a_real_task_is_still_recognised():
    class Task:
        IsCompleted = True
        Result = NetList([])

    assert _looks_like_task(Task()) is True
    assert _is_collection(Task()) is False


# -- arena/webwindow.py: cookie_tuples -------------------------------------

def test_cookie_tuples_reads_a_finished_jar(monkeypatch):
    """The regression: a ready jar must not be read as "still pending"."""
    jar = NetList([NetCookie("SID", "abc"), NetCookie("SSID", "def")])
    win = webwindow.WebViewWindow("t")
    win._core_ready.set()

    class Manager:
        @staticmethod
        def GetCookiesAsync(_url):
            return jar          # a finished collection, not a task

    class Core:
        CookieManager = Manager()

    win.core = Core()
    # Run the queued work at once, as the UI thread would. The real `_post`
    # hops threads; here the call itself is the thing under test.
    win._post = lambda action: (action(), True)[1]

    result = win.cookie_tuples()
    assert result == [("SID", "abc", ".google.com"),
                      ("SSID", "def", ".google.com")], (
        "a finished List[CoreWebView2Cookie] produced an empty jar")


def test_cookie_tuples_still_handles_a_task():
    """A task that really is pending must still be awaited, not dropped."""
    jar = NetList([NetCookie("SID", "abc")])

    class Task:
        IsCompleted = True
        Result = jar

    win = webwindow.WebViewWindow("t")
    win._core_ready.set()

    class Manager:
        @staticmethod
        def GetCookiesAsync(_url):
            return Task()

    class Core:
        CookieManager = Manager()

    win.core = Core()
    win._post = lambda action: (action(), True)[1]
    assert win.cookie_tuples() == [("SID", "abc", ".google.com")]


# -- arena/webwindow.py: evaluate_js ---------------------------------------

def test_evaluate_js_decodes_a_direct_answer():
    """ExecuteScriptAsync may hand back the string itself, not a task."""
    win = webwindow.WebViewWindow("t")
    win._core_ready.set()

    class Core:
        @staticmethod
        def ExecuteScriptAsync(_script):
            return '"www.google.com"'      # finished value, JSON-encoded

    win.core = Core()
    win._post = lambda action: (action(), True)[1]
    assert win.evaluate_js("location.host") == "www.google.com"


def test_evaluate_js_decodes_a_task_answer():
    class Task:
        IsCompleted = True
        Result = '"www.google.com"'

    win = webwindow.WebViewWindow("t")
    win._core_ready.set()

    class Core:
        @staticmethod
        def ExecuteScriptAsync(_script):
            return Task()

    win.core = Core()
    win._post = lambda action: (action(), True)[1]
    assert win.evaluate_js("location.host") == "www.google.com"


# -- arena/google_ai.py: the same shape, second half ----------------------

def test_await_task_treats_a_finished_value_as_the_answer():
    """`_await_task` used to return (False, None) for a ready collection."""
    jar = NetList([NetCookie("SID", "abc")])
    ok, value = google_ai._await_task(jar, 0.1)
    assert ok is True
    assert value is jar


def test_session_cookies_ready_understands_a_net_collection():
    assert google_ai._session_cookies_ready(NetList([NetCookie("SID", "a")])) is True
    assert google_ai._session_cookies_ready(NetList([])) is False


def test_on_ui_converts_a_net_collection_to_a_list():
    """`isinstance(result, list)` in _cookies_direct has to become True."""
    jar = NetList([NetCookie("SID", "abc")])
    assert isinstance(jar, list) is False

    engine = google_ai.GoogleEngine()
    engine.window = type("W", (), {"native": None})()

    class FakeNative:
        InvokeRequired = False
        webview = None

    engine.window.native = FakeNative()
    engine._edge_host = lambda: (object(), None, FakeNative())

    converted = google_ai._is_net_collection(jar)
    assert converted is True
    assert list(jar) == [jar._items[0]]


# -- arena/webwindow.py: native.browser shim ------------------------------

def test_browser_shim_satisfies_the_engine_lookup():
    """`google_ai._read_edge_host_on_ui` reads `native.browser`."""
    shim = webwindow._BrowserShim()
    assert shim.syncContextTaskScheduler is None
    # the engine tolerates None; what it cannot tolerate is a missing attribute
    assert hasattr(shim, "syncContextTaskScheduler")
