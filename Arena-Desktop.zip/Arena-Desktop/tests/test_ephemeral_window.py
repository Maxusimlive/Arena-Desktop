"""The single-use sign-in window: throwaway profile, one page, closed after.

What these tests are about
--------------------------
The person asked for "the one-time-window format -- what Arena uses for Google
sign-in: it starts fast and signs in normally". Behind that request are four
separate failures from earlier rounds, and each has a test here:

* the window was created blank and then navigated, so it took seconds to show
  anything -- now the page is on the command line;
* the same URL was loaded twice, which is what made the arena window appear
  twice -- now a page is created *at* the address and not navigated again;
* a finished sign-in stayed alive in its profile, so the next attempt landed
  inside it -- now the profile is deleted with the window;
* the sign-in never counted because `loaded` never rose on a browser window --
  covered in `test_google_ai.py`, not repeated here.
"""

from __future__ import annotations

import os
import pathlib
import sys
import time

import pytest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from arena import ephemeral                      # noqa: E402
from arena import browserwindow as bw            # noqa: E402


@pytest.fixture()
def fake_windows(monkeypatch):
    """A Windows-shaped environment with a browser that never really opens."""
    monkeypatch.setattr(bw, "IS_WINDOWS", True)
    root = pathlib.Path(os.environ.get("PYTEST_TMP", "/tmp")) / "eph-test-browser"
    root.mkdir(parents=True, exist_ok=True)
    exe = root / "chrome.exe"
    exe.write_text("not really a browser")
    monkeypatch.setitem(bw.CHROMIUM_CANDIDATES, "Google Chrome", [str(exe)])
    for other in ("Microsoft Edge", "Brave", "Vivaldi"):
        monkeypatch.setitem(bw.CHROMIUM_CANDIDATES, other, [])
    started: list[list[str]] = []
    killed: list[bool] = []

    class Proc:
        """A browser process that stays alive until it is killed.

        `wait()` must honour that too: the exit watcher runs `proc.wait()` on a
        thread, and a stand-in that returns from `wait()` at once is
        indistinguishable from a browser the person just closed -- the window
        was marked closed a millisecond after it opened.
        """

        alive = True

        def poll(self):
            return None if self.alive else 0

        def terminate(self):
            self.alive = False
            killed.append(True)

        def wait(self, *a, **kw):
            while self.alive:
                time.sleep(0.01)
            return 0

    monkeypatch.setattr(bw.subprocess, "Popen",
                        lambda args, **kw: (started.append(list(args)), Proc())[1])
    monkeypatch.setattr(bw, "wait_for_debugger", lambda port, timeout=None: True)
    monkeypatch.setattr(bw, "_tabs", lambda port: [
        {"type": "page", "url": "https://www.google.com/",
         "webSocketDebuggerUrl": "ws://page"}])

    # A live browser answers `location.host`; this stand-in used to answer
    # nothing at all, so every page check failed until the full twenty-second
    # wait ran out. That is a property of the stand-in, not of the code under
    # test, and it turned four tests into a twenty-second crawl.
    monkeypatch.setattr(
        bw.BrowserWindow, "evaluate_js",
        lambda self, script, *a, **kw: (
            "www.google.com" if "location.host" in script
            else "https://www.google.com/"))
    return started, killed


def wait_for(predicate, timeout: float = 5.0) -> bool:
    """The window starts on its own thread; the tests wait for it."""
    end = time.time() + timeout
    while time.time() < end:
        if predicate():
            return True
        time.sleep(0.02)
    return False


def test_the_page_is_on_the_command_line(fake_windows):
    """No blank start, no later navigation: the window opens on its page."""
    started, _ = fake_windows
    window = ephemeral.EphemeralSignIn()
    window._window.start()
    assert wait_for(lambda: bool(started)), "the browser was never started"
    assert started[0][-1] == bw.HOME_URL
    assert not any(a == "about:blank" for a in started[0])


def test_the_profile_is_throwaway_and_deleted_afterwards(fake_windows):
    """One sign-in, one profile, and nothing left behind after it.

    The folder is made before the browser is started -- `mkdtemp` is what hands
    Chromium its `--user-data-dir` -- so this must not depend on the launch
    thread having got as far as creating files inside it.
    """
    window = ephemeral.EphemeralSignIn()
    profile = window._window.user_data_dir
    assert pathlib.Path(profile).name.startswith("arena-signin-")
    window._window.start()
    assert wait_for(lambda: bool(window._window._proc) or window._window._thread)
    # Something inside it, as a signed-in browser would leave behind.
    pathlib.Path(profile, "Cookies").write_text("session")
    window.close_and_forget()
    assert not os.path.isdir(profile), "the single-use profile survived the window"


def test_closing_ends_the_browser_it_started(fake_windows):
    _, killed = fake_windows
    window = ephemeral.EphemeralSignIn()
    window._window.start()
    assert wait_for(lambda: bool(killed) or window._window._proc is not None)
    window.close_and_forget()
    assert killed, "the browser process was left running"
    assert window._closed is True
    window.close_and_forget()          # idempotent: a second close is harmless
    assert len(killed) == 1


def test_a_page_is_created_at_the_address_not_navigated_afterwards(fake_windows, monkeypatch):
    """The doubling: /json/new?about:blank plus a navigation loaded the same URL twice."""
    created: list[str] = []
    navigated: list[str] = []
    monkeypatch.setattr(bw.BrowserWindow, "_open_tab",
                        lambda self, url: (created.append(url),
                                           {"webSocketDebuggerUrl": "ws://p"})[1])
    monkeypatch.setattr(bw.BrowserWindow, "_navigate",
                        lambda self, tab, url: navigated.append(url) or True)
    monkeypatch.setattr(bw, "_tabs", lambda port: [])
    window = ephemeral.create_arena_sign_in_window()
    window._window.start()
    assert wait_for(lambda: bool(created)), "no page was created"
    assert created == [bw.ARENA_URL]
    assert navigated == [], "the page was navigated on top of being created"


def test_the_engine_closes_the_window_once_the_cookies_are_out():
    from arena import google_ai

    closed = {}

    class Window:
        is_browser = True
        ephemeral = True

        def close_and_forget(self):
            closed["done"] = True

    engine = google_ai.GoogleEngine()
    engine.window = Window()
    engine.visible = True
    engine.loaded = True
    engine.close_sign_in_window()
    assert closed.get("done") is True
    assert engine.visible is False and engine.loaded is False


def test_a_persistent_window_is_left_alone():
    from arena import google_ai

    class Window:
        is_browser = True
        ephemeral = False

    engine = google_ai.GoogleEngine()
    engine.window = Window()
    engine.close_sign_in_window()      # no attribute, no exception, no change
    assert engine.window is not None


# -- the second sign-in ----------------------------------------------------
# The bug these cover was reported as "the button does nothing", and it had
# three layers: the window kept the thread of a dead browser, the engine kept
# "the window is already on screen", and the lazy wrapper kept handing back the
# dead object. Each one alone is enough to stop the second sign-in.

def test_a_new_window_starts_after_the_old_one_is_gone(fake_windows):
    """Second press after the browser was closed must start a browser again."""
    from arena import lazywindow

    started, killed = fake_windows
    windows = []

    real = ephemeral.EphemeralSignIn

    def factory():
        window = real()
        windows.append(window)
        return window

    lazy = lazywindow.LazyWindow(factory, name="google window", ephemeral=True)
    lazy.show()
    assert wait_for(lambda: bool(started)), "the first window never started"

    first = windows[0]
    first._window._proc.terminate()          # the person closed the browser
    first._window.events.closed.set()        # what _watch_exit does
    # The wrapper is what the engine talks to, so it is what has to forget.
    lazy.close_and_forget()

    before = len(started)
    lazy.show()
    assert wait_for(lambda: len(started) > before), (
        "the second sign-in did not start a browser at all -- this is exactly "
        "the report 'the button does nothing'")
    assert len(windows) == 2, "the dead window was handed back instead of a new one"


def test_the_engine_stops_believing_in_a_closed_window(fake_windows):
    """`_shown_evt` was set once and never cleared, so show() became a no-op."""
    from arena import google_ai, lazywindow

    started, _ = fake_windows
    windows = []
    real = ephemeral.EphemeralSignIn

    def factory():
        window = real()
        windows.append(window)
        return window

    engine = google_ai.GoogleEngine()
    engine.attach(lazywindow.LazyWindow(factory, name="g", ephemeral=True), None)
    engine.open_sign_in(fresh=True)
    assert wait_for(lambda: bool(started))
    assert engine.shown_once() is True

    windows[0]._window._proc.terminate()
    engine._on_window_closed()          # what the window's `closed` event calls

    assert engine.shown_once() is False, (
        "the engine still believes a window is on screen, so ensure_visible() "
        "returns before asking for a new one")
    assert engine.visible is False


def test_closing_forgets_the_window_and_its_handlers(fake_windows):
    """Handlers live in the wrapper, so a dead window must not keep them."""
    from arena import lazywindow

    started, _ = fake_windows
    seen = []
    real = ephemeral.EphemeralSignIn

    lazy = lazywindow.LazyWindow(lambda: real(), name="g", ephemeral=True)
    lazy.events.closed += lambda *a: seen.append("closed")
    lazy.show()
    assert wait_for(lambda: bool(started))

    assert lazy.window is not None
    lazy.window._window.events.closed.set()
    assert seen == ["closed"], "the handler never reached the real window"

    lazy.close_and_forget()
    assert lazy.window is None, "a single-use window was kept after closing"

    # A second window must not fire the first window's handlers twice over.
    lazy.events.closed += lambda *a: seen.append("closed-2")
    lazy.show()
    assert wait_for(lambda: len(seen) >= 2)


def test_arena_closes_its_single_use_window_after_signing_in(monkeypatch):
    from arena import engine as engine_module
    import arena.ephemeral as ephemeral_module

    monkeypatch.setattr(ephemeral_module, "IS_WINDOWS", True, raising=False)

    eng = engine_module.BrowserEngine()
    class FakeWin:
        ephemeral = True
        def __init__(self):
            self.closed = False
        def close_and_forget(self):
            self.closed = True
    win = FakeWin()
    monkeypatch.setattr(ephemeral_module, "create_arena_sign_in_window", lambda: win)
    eng.window = win
    eng.login_open = True
    eng.loaded = True

    eng.finish_login()
    assert eng.login_open is False
    assert win.closed is True


def test_load_url_does_not_navigate_during_startup(fake_windows, monkeypatch):
    """The start URL is on the command line already: no second load."""
    started, _ = fake_windows
    navigated = []
    monkeypatch.setattr(bw.BrowserWindow, "_navigate",
                        lambda self, tab, url: navigated.append(url) or True)

    window = ephemeral.EphemeralSignIn()
    window.show()
    assert wait_for(lambda: bool(started))
    window.load_url(bw.HOME_URL)
    assert navigated == [], (
        "the page was navigated again while the command line was still "
        "loading it -- a second load of the same URL")


# ---------------------------------------------------------------------------
# One press, one page
# ---------------------------------------------------------------------------
# The guard that was supposed to prevent a second navigation compared whole
# URLs character for character, and so never matched:
#   Arena:  "https://arena.ai/"        vs  "https://arena.ai"
#   Google: "https://www.google.com/"  vs  "https://www.google.com/?authuser=0&hl=ru"
# Every match failed, every press went down the navigation path, and a tab that
# had not yet appeared in /json was answered with /json/new -- one more window.

def test_the_same_page_is_not_loaded_twice_over_a_trailing_slash():
    from arena.ephemeral import _same_origin

    assert _same_origin("https://arena.ai/", "https://arena.ai") is True
    assert _same_origin("https://www.google.com/",
                        "https://www.google.com/?authuser=0&hl=ru") is True
    assert _same_origin("https://arena.ai/", "https://arena.ai/#top") is True
    assert _same_origin("HTTPS://Arena.AI/", "https://arena.ai") is True
    assert _same_origin("https://arena.ai/", "https://google.com/") is False


def test_a_single_use_window_ignores_a_second_request_for_its_own_page():
    """`load_url` must answer "already there" instead of navigating again."""
    from arena import ephemeral

    loads = []

    class Window:
        open_url_on_start = "https://arena.ai/"
        domains = ("arena.ai",)

        def is_ready(self):
            return False                     # the port has not answered yet

        def load_url(self, url):
            loads.append(url)
            return True

    window = ephemeral.EphemeralSignIn.__new__(ephemeral.EphemeralSignIn)
    window.url = "https://arena.ai/"
    window._window = Window()
    window._closed = False

    assert window.load_url("https://arena.ai") is True
    assert loads == [], (
        "the page is already on the command line; a second navigation is what "
        "opened the extra window")

    window.load_url("https://arena.ai/agent")
    assert loads == ["https://arena.ai/agent"], (
        "a genuinely different page must still be loaded")


def test_a_signed_in_page_on_a_subdomain_counts_as_ours():
    """`current in self.url` missed 'www.arena.ai' -- the case it existed for."""
    from arena import ephemeral

    loads = []

    class Window:
        open_url_on_start = "https://arena.ai/"
        domains = ("arena.ai",)

        def is_ready(self):
            return True

        def host(self):
            return "www.arena.ai"

        def load_url(self, url):
            loads.append(url)
            return True

    window = ephemeral.EphemeralSignIn.__new__(ephemeral.EphemeralSignIn)
    window.url = "https://arena.ai/"
    window._window = Window()
    window._closed = False

    assert window.load_url("https://arena.ai/") is True
    assert loads == [], (
        "the window is already on arena.ai; navigating again threw away a "
        "sign-in that was in progress")


def test_open_tab_does_not_open_another_when_a_page_exists(monkeypatch):
    """The docstring said "when there is none yet"; the code never checked.

    `PUT /json/new` opens a tab whatever the browser is already showing, so
    every caller that guessed wrong about `/json` left an extra page behind.
    """
    from arena import browserwindow as bw

    page = {"type": "page", "url": "https://arena.ai/",
            "webSocketDebuggerUrl": "ws://page"}
    monkeypatch.setattr(bw, "_tabs", lambda port: [page])
    monkeypatch.setattr(bw, "page_tab", lambda port, domains: page)

    created = []

    def no_new_tab(request, *a, **kw):
        created.append(getattr(request, "full_url", request))
        raise AssertionError(f"a new tab was opened although one existed: {created}")

    monkeypatch.setattr(bw.urllib.request, "urlopen", no_new_tab)

    window = bw.BrowserWindow("https://arena.ai/", user_data_dir=None)
    window._port = 4321

    assert window._open_tab("https://arena.ai/") is page
    assert created == [], "the existing page must be reused, not duplicated"


def _tab_window(monkeypatch, listed, on_create=None):
    """A BrowserWindow whose `/json` the test controls."""
    import json as _json
    from arena import browserwindow as bw

    pages, created = list(listed), []

    class Response:
        def __init__(self, payload):
            self._payload = payload

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def read(self):
            return self._payload.encode()

    def urlopen(request, timeout=None):
        url = getattr(request, "full_url", request)
        if "/json/new" in url:
            created.append(url)
            page = {"type": "page", "url": "https://arena.ai/",
                    "webSocketDebuggerUrl": f"ws://{len(created)}"}
            if on_create:
                on_create(pages, page)
            return Response(_json.dumps(page))
        return Response(_json.dumps(list(pages)))

    monkeypatch.setattr(bw.urllib.request, "urlopen", urlopen)
    monkeypatch.setattr(bw, "_tabs", lambda port: list(pages))
    monkeypatch.setattr(bw, "page_tab", lambda port, domains: pages[0] if pages else None)
    window = bw.BrowserWindow("https://arena.ai/", user_data_dir=None)
    window._port = 4242
    return window, pages, created


def test_the_browser_lists_a_new_tab_late_and_that_does_not_make_a_second(monkeypatch):
    """The real cause of "two or three pages at once".

    `/json/new` returns before the browser lists the tab in `/json`, so for a
    moment the list still looks empty. The launch thread and the navigation
    thread both asked, both saw nothing, and both created a page.
    """
    def late(pages, page):
        pass                                  # the browser is slow to list it

    window, pages, created = _tab_window(monkeypatch, [], on_create=late)

    first = window._open_tab("https://arena.ai/")
    second = window._open_tab("https://arena.ai/")

    assert first is not None and second is not None
    assert len(created) == 1, (
        f"a second tab was created while the first was still being listed: {created}")
    assert first["webSocketDebuggerUrl"] == second["webSocketDebuggerUrl"]


def test_a_tab_the_person_closed_is_not_handed_back(monkeypatch):
    """Remembering the tab must not outlive it."""
    def listed(pages, page):
        pages.append(page)

    window, pages, created = _tab_window(monkeypatch, [], on_create=listed)

    window._open_tab("https://arena.ai/")
    window._open_tab("https://arena.ai/")
    assert len(created) == 1

    pages.clear()                             # the person closed it
    fresh = window._open_tab("https://arena.ai/")

    assert len(created) == 2, "the closed tab was reused instead of replaced"
    assert fresh is not None and fresh["webSocketDebuggerUrl"] == "ws://2"
