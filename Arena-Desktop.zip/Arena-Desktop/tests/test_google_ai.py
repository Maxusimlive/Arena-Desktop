"""Unit tests for the Google AI mode driver (window + answer reading)."""
import json
import sys
import threading
import time
import types

import pytest

from arena import google_ai


class FakeWindow:
    """Minimal WebView stand-in: answers the scripts the driver evaluates."""

    def __init__(self, host="www.google.com", body="", submit="submitted"):
        self.host = host
        self.body = body
        self.submit_result = submit
        self.loaded_urls = []
        self.shown = 0
        self.hidden = 0

    def evaluate_js(self, script):
        if script == "location.host":
            return self.host
        if script == "document.title":
            return "Google"
        if "querySelector('textarea[name=\"q\"]" in script or 'name="q"' in script:
            return self.submit_result
        if "#rcnt" in script:
            return self.body
        if "SignOutOptions" in script:
            return json.dumps({"signed_in": True, "email": "me@gmail.com",
                               "name": "Me", "has_signin_link": False})
        if "document.cookie = k" in script:
            return 2
        return ""

    def load_url(self, url):
        self.loaded_urls.append(url)

    def show(self):
        self.shown += 1

    def hide(self):
        self.hidden += 1

    def resize(self, *a):
        pass

    def move(self, *a):
        pass

    def restore(self):
        pass


def _engine(window):
    engine = google_ai.GoogleEngine()
    engine.window = window
    engine.loaded = True
    engine.host = window.host
    return engine


def test_search_url_targets_ai_mode():
    url = google_ai.GoogleEngine.search_url("что нового в AI?", "ru")
    assert url.startswith("https://www.google.com/search?")
    assert "udm=50" in url and "hl=ru" in url
    assert "q=%D1%87%D1%82%D0%BE" in url  # url-encoded query


def test_clean_answer_drops_page_chrome():
    raw = ("AI Mode is a generative answer\n\n"
           "Москва — столица России.\n"
           "Share\n"
           "Export to Docs\n"
           "copy\n\n\n"
           "Население — 13 млн.")
    clean = google_ai.GoogleEngine.clean_answer(raw, "столица россии")
    assert clean.startswith("Москва — столица России.")
    assert "Share" not in clean and "Export to Docs" not in clean
    assert "Население — 13 млн." in clean
    assert "\n\n\n" not in clean


def test_ask_returns_the_rendered_answer(monkeypatch):
    window = FakeWindow(body="Ответ Google AI mode про Москву.")
    engine = _engine(window)
    monkeypatch.setattr(google_ai, "POLL", 0.01)
    monkeypatch.setattr(google_ai, "LOAD_WAIT", 0.0)
    events = list(engine.ask("столица россии", first=True))
    kinds = [e["type"] for e in events]
    assert kinds[0] == "stage" and kinds[-1] == "done"
    assert any(e["type"] == "text" and "Москв" in e["text"] for e in events)
    assert events[-1]["text"]
    # A first turn opens the real search URL in the window.
    assert any("udm=50" in url for url in window.loaded_urls)


def test_ask_reports_no_answer_instead_of_inventing_one(monkeypatch):
    engine = _engine(FakeWindow(body=""))
    monkeypatch.setattr(google_ai, "POLL", 0.01)
    monkeypatch.setattr(google_ai, "LOAD_WAIT", 0.0)
    monkeypatch.setattr(google_ai, "MAX_WAIT", 0.05)
    events = list(engine.ask("привет", first=True))
    assert any(e["type"] == "error" and e["code"] == "google_no_answer" for e in events)
    assert not any(e["type"] == "text" for e in events)


def test_ask_requires_the_window():
    engine = google_ai.GoogleEngine()
    events = list(engine.ask("hi"))
    assert events[0]["type"] == "error" and events[0]["code"] == "google_window"


def test_follow_up_is_typed_into_the_page(monkeypatch):
    window = FakeWindow(body="Ответ на уточнение.")
    engine = _engine(window)
    monkeypatch.setattr(google_ai, "POLL", 0.01)
    monkeypatch.setattr(google_ai, "LOAD_WAIT", 0.0)
    list(engine.ask("уточнение", first=False))
    # A follow-up continues the thread in the page instead of reloading search.
    assert window.loaded_urls == []
    assert engine.host == "www.google.com"


def test_apply_cookies_and_account_read(monkeypatch):
    window = FakeWindow()
    engine = _engine(window)
    # apply_cookies still goes through the page, so it keeps the old path.
    engine.run_script_safe = lambda script, limit=6.0: engine.window.evaluate_js(script)
    written = engine.apply_cookies("SID=abc; HSID=def; bad")
    assert written == 2
    # The identity read uses WebView2's ExecuteScriptAsync on a real build.
    monkeypatch.setattr(engine, "script_result", lambda script: engine.window.evaluate_js(script))
    info = engine.account()
    assert info["signed_in"] is True and info["email"] == "me@gmail.com"


def test_desktop_wires_the_google_window(monkeypatch, tmp_path):
    """The frozen build's entry point must create and attach the Google window."""
    import sys
    import types
    from arena import desktop

    created = []

    class _Event:
        def __iadd__(self, fn):
            return self

    class Win:
        def __init__(self, title, url, **kw):
            self.title, self.url, self.kw = title, url, kw
            # pywebview exposes events as "+="-able event objects.
            self.events = types.SimpleNamespace(closed=_Event(), closing=_Event())
            created.append(self)

        def show(self):
            pass

        def restore(self):
            pass

        def evaluate_js(self, *_a):
            return None

    fake_webview = types.SimpleNamespace(
        settings={}, create_window=lambda *a, **k: Win(*a, **k),
        start=lambda **k: (_ for _ in ()).throw(SystemExit(0)),
    )
    monkeypatch.setitem(sys.modules, "webview", fake_webview)
    monkeypatch.setattr(desktop, "start_flask", lambda port: None)
    monkeypatch.setattr(desktop, "wait_port", lambda port, timeout=10.0: True)
    monkeypatch.setattr(desktop, "find_free_port", lambda: 43210)
    monkeypatch.setattr(desktop, "_ensure_webview2", lambda: True)
    monkeypatch.setattr(desktop, "_switch_profile", lambda port, wanted: None)

    from arena import deep_links
    monkeypatch.setattr(deep_links, "find_deep_link_arg", lambda argv: None)
    monkeypatch.setattr(deep_links, "register_protocol", lambda: False)
    monkeypatch.setattr(deep_links, "write_instance", lambda port, token: None)
    # Keep the real profile untouched: desktop.main() logs into CONFIG_DIR.
    monkeypatch.setattr("arena.config.CONFIG_DIR", tmp_path / "cfg")

    from arena.engine import ENGINE
    monkeypatch.setattr(ENGINE, "attach", lambda win, main: setattr(ENGINE, "window", win))
    from arena import google_ai
    monkeypatch.setattr(google_ai.ENGINE, "attach",
                        lambda win, main: setattr(google_ai.ENGINE, "window", win))

    try:
        desktop.main()
    except SystemExit:
        pass

    # The Google window must NOT be created at startup any more. It used to be
    # free (a hidden WebView2 form), but a real browser window on google.com
    # opens on launch -- before the person asked for anything. What startup has
    # to produce is a window that will be created when it is first needed.
    titles = [w.title for w in created]
    assert "Google AI mode - Arena Desktop" not in titles, (
        "the Google window was opened at launch instead of on demand")
    from arena.web import app as web_app
    assert web_app.GOOGLE_ENGINE is google_ai.ENGINE
    from arena.lazywindow import LazyWindow
    assert isinstance(google_ai.ENGINE.window, LazyWindow)
    # ...and the pane is still reachable: pressing the button opens it.
    assert web_app._google_window_present() is True

    # Asking for it must create a real window, not silently do nothing. Which
    # one depends on the host: the browser by default, pywebview when the
    # environment says so, and -- when no browser can be started -- nothing at
    # all, which is a working state rather than a reason to start WebView2.
    monkeypatch.setenv("ARENA_GOOGLE_WINDOW", "pywebview")
    google_ai.ENGINE.window.show()
    assert "Google AI mode - Arena Desktop" in [w.title for w in created]
    google_win = next(w for w in created if w.title == "Google AI mode - Arena Desktop")
    # Chats go over plain HTTPS, so the window starts blank and only navigates
    # to Google when a person signs in or must pass a check.
    assert google_win.url == "about:blank"
    assert google_win.kw.get("hidden") is True


# --- the sign-in window regressions of 2026-11-18 --------------------------
# The whole failure was one root cause: pywebview refuses calls on a window
# that was created hidden and never shown, and says so with "Main window
# failed to start". These tests pin the fixes.

class HiddenWindow:
    """A window that was created hidden and never shown."""

    def __init__(self):
        self.calls = []
        self.native = None

        class _Events:
            shown = type("Evt", (), {"wait": staticmethod(lambda t=None: False)})()

        self.events = _Events()

    def show(self):
        self.calls.append("show")

    def hide(self):
        self.calls.append("hide")

    def load_url(self, url):
        self.calls.append(("load", url))

    def clear_cookies(self):
        raise google_ai_WebViewException("Main window failed to start")

    def get_cookies(self):
        raise google_ai_WebViewException("Main window failed to start")


from webview.errors import WebViewException as google_ai_WebViewException  # noqa: E402


def test_shown_once_false_before_the_window_is_on_screen():
    engine = google_ai.GoogleEngine()
    engine.window = HiddenWindow()
    assert engine.shown_once() is False
    assert engine._ever_shown is False


def test_shown_event_marks_the_window_as_usable():
    engine = google_ai.GoogleEngine()
    engine.window = HiddenWindow()
    engine._on_shown()
    assert engine.shown_once() is True


def test_clear_cookies_does_not_raise_on_a_hidden_window():
    """The old code called pywebview, which waits 20 s and then throws.

    Here nothing can be cleared (no WebView2 in the test process), so the
    honest answer is False — but it must come back immediately, not blow up.
    """
    engine = google_ai.GoogleEngine()
    window = HiddenWindow()
    engine.window = window
    assert engine.clear_cookies() is False
    assert not any(call == "hide" for call in window.calls)


def test_load_never_blocks_on_a_hidden_window():
    """Navigating must not try to *show* the window from a request thread.

    Window.show() is gated on the same `shown` event as everything else: on a
    hidden window it waits 20 s and then throws, and callers are HTTP threads,
    so the app looked frozen. Loading now just sets the URL.
    """
    engine = google_ai.GoogleEngine()
    window = HiddenWindow()
    engine.window = window
    started = time.time()
    engine.load("https://www.google.com/")
    assert time.time() - started < 1.0
    assert "show" not in window.calls
    assert ("load", "https://www.google.com/") in window.calls


def test_show_returns_promptly_when_the_window_never_comes_up():
    """A window that refuses to start must not hold the caller for 20 s."""
    engine = google_ai.GoogleEngine()
    engine.window = HiddenWindow()
    started = time.time()
    engine.show()
    assert time.time() - started < 8.0


def test_cookie_read_never_uses_pywebview_when_webview2_exists(monkeypatch):
    """pywebview's get_cookies ends in an unbounded semaphore wait."""
    engine = google_ai.GoogleEngine()
    engine.window = HiddenWindow()
    monkeypatch.setattr(engine, "_edge_manager", lambda: object())
    called = []
    engine.window.get_cookies = lambda: called.append(1) or []
    assert engine._cookies_from_pywebview() == []
    assert called == []


def test_cookies_returns_empty_without_a_window():
    assert google_ai.GoogleEngine().cookies() == ""


def test_cookies_waits_for_the_jar_to_fill():
    """WebView2 writes the session a moment after the page settles."""
    engine = google_ai.GoogleEngine()
    engine.window = HiddenWindow()
    attempts = []

    def fake_edge():
        attempts.append(1)
        return [("SID", "abc")] if len(attempts) >= 2 else []

    engine._cookies_from_edge = fake_edge
    engine._cookies_from_pywebview = lambda: []
    assert engine.cookies(tries=3, wait=0.01) == "SID=abc"
    assert len(attempts) >= 2


def test_account_accepts_the_jar_when_the_dom_anchor_is_missing(monkeypatch):
    """A restyled header must not read as "signed out"."""
    engine = google_ai.GoogleEngine()
    engine.window = HiddenWindow()
    monkeypatch.setattr(engine, "script_result", lambda script: None)
    monkeypatch.setattr(engine, "run_script", lambda script: None)
    monkeypatch.setattr(engine, "jar_signed_in", lambda: True)
    monkeypatch.setattr(engine, "_email_via_http", lambda: "me@gmail.com")
    info = engine.account()
    assert info["signed_in"] is True
    assert info["email"] == "me@gmail.com"


def test_account_stays_signed_out_without_any_session(monkeypatch):
    engine = google_ai.GoogleEngine()
    engine.window = HiddenWindow()
    monkeypatch.setattr(engine, "script_result", lambda script: None)
    monkeypatch.setattr(engine, "run_script", lambda script: None)
    monkeypatch.setattr(engine, "jar_signed_in", lambda: False)
    assert engine.account()["signed_in"] is False


def test_verify_does_not_navigate_away_from_a_google_page(monkeypatch):
    """Verifying mid-sign-in must not reload the page under the person."""
    engine = google_ai.GoogleEngine()
    window = HiddenWindow()
    engine.window = window
    monkeypatch.setattr(engine, "page_url", lambda: "https://accounts.google.com/signin")
    monkeypatch.setattr(engine, "account", lambda: {"signed_in": True, "email": "a@b.c"})
    info = engine.verify()
    assert info["signed_in"] is True
    assert not [c for c in window.calls if isinstance(c, tuple) and c[0] == "load"]


# --- "switching to Google mode froze the app" (2026-11-18, desktop-7.log) ---
# The window calls pywebview exposes end in unbounded waits; any of them called
# from a request thread hangs the UI. These tests pin "never wait" as a rule.

class FrozenWindow:
    """Every call blocks forever, exactly like a wedged WebView."""

    native = None

    def __getattr__(self, name):
        def hang(*_a, **_k):
            time.sleep(600)
        return hang


def test_account_does_not_call_pywebview_when_webview2_is_absent(monkeypatch):
    """A wedged window must not be able to freeze a status poll."""
    engine = google_ai.GoogleEngine()
    engine.window = FrozenWindow()
    monkeypatch.setattr(engine, "script_result", lambda script: None)
    started = time.time()
    info = engine.account()
    assert time.time() - started < 2.0
    assert info["signed_in"] is False


def test_pywebview_cookie_reader_is_never_used():
    """get_cookies() ends in semaphore.acquire() with no timeout."""
    engine = google_ai.GoogleEngine()
    engine.window = FrozenWindow()
    started = time.time()
    assert engine._cookies_from_pywebview() == []
    assert time.time() - started < 0.5


def test_cookies_returns_fast_when_the_window_is_wedged(monkeypatch):
    engine = google_ai.GoogleEngine()
    engine.window = FrozenWindow()
    monkeypatch.setattr(engine, "_cookies_from_edge", lambda: [])
    started = time.time()
    assert engine.cookies(tries=2, wait=0.01) == ""
    assert time.time() - started < 1.0


def test_hide_does_not_block_the_caller():
    engine = google_ai.GoogleEngine()
    engine.window = FrozenWindow()
    started = time.time()
    engine.hide()
    assert time.time() - started < 0.5


def test_quiet_window_is_not_touched_in_the_background():
    engine = google_ai.GoogleEngine()
    engine.window = FrozenWindow()
    engine.quiet(30)
    assert engine.quiet_now() is True


class _FakeTask:
    """Minimal stand-in for a WinRT ``IAsyncOperation``."""

    def __init__(self, value):
        self._value = value
        self.waited = 0

    @property
    def IsCompleted(self):
        return True

    def Wait(self, ms):
        # Kept as an alarm: the engine must never call it (it blocks while
        # holding the GIL and freezes every Python thread at once).
        self.waited += 1
        return True

    @property
    def Result(self):
        return self._value


class _FakeCookie:
    def __init__(self, name, value, domain):
        self.Name, self.Value, self.Domain = name, value, domain


class _FakeManager:
    def __init__(self, cookies):
        self._cookies = cookies
        self.calls = 0

    def GetCookiesAsync(self, url):
        self.calls += 1
        return _FakeTask([_FakeCookie(n, v, d) for n, v, d in self._cookies])


class _FakeCore:
    def __init__(self, manager):
        self.CookieManager = manager


class _FakeControl:
    def __init__(self, core):
        self.CoreWebView2 = core


class _FakeNative:
    """WinForms form double: records the thread each WebView2 touch came from."""

    def __init__(self, core, ui_thread):
        self.webview = _FakeControl(core)
        self.browser = None
        self.InvokeRequired = True
        self._ui_thread = ui_thread
        self.invoked = 0
        self.wrong_thread_calls = 0

    def Invoke(self, action):
        self.invoked += 1
        if threading.current_thread() is self._ui_thread:
            self.wrong_thread_calls += 0   # legitimately on the UI thread
        action()

    def BeginInvoke(self, action):
        """What real WinForms offers, and what the engine must prefer.

        BeginInvoke returns at once, so a wedged UI thread cannot hold the
        caller (or the GIL) hostage; Invoke blocks until the UI thread is free,
        which is the deadlock that froze the whole app.
        """
        self.invoked += 1
        action()


class _FakeForms(types.ModuleType):
    """``System.Windows.Forms`` stand-in (the real one only exists on Windows)."""

    class MethodInvoker:
        def __init__(self, fn):
            self.fn = fn

        def __call__(self, *a):
            return self.fn(*a)


@pytest.fixture()
def fake_winforms(monkeypatch):
    module = _FakeForms("System.Windows.Forms")
    monkeypatch.setitem(sys.modules, "System.Windows.Forms", module)
    return module


def test_google_cookies_are_read_on_the_window_ui_thread(fake_winforms):
    """Reading WebView2 from a worker thread is a native crash, not an error.

    WinForms and WebView2 are apartment-bound: a CookieManager or
    ExecuteScriptAsync call from a Flask thread is an access violation, so the
    app disappears with no traceback and leaves a "Failed to remove temporary
    directory" dialog behind. Every call has to be marshalled through Invoke.
    """
    ui_thread = threading.current_thread()
    manager = _FakeManager([("SID", "abc", ".google.com")])
    native = _FakeNative(_FakeCore(manager), ui_thread)

    class Win:
        def __init__(self):
            self.native = native

    seen = []
    original = _FakeManager.GetCookiesAsync

    def tracking(self, url):
        seen.append(threading.current_thread())
        return original(self, url)

    _FakeManager.GetCookiesAsync = tracking
    try:
        engine = google_ai.GoogleEngine()
        engine.window = Win()
        # A hidden window's renderer is frozen, so WebView2 never runs the
        # tasks it is handed. The engine skips the read in that state; pin the
        # window as on-screen so this test exercises the reading path itself.
        engine.visible = True
        engine._shown_evt.set()
        pairs = engine._cookies_direct("https://www.google.com/")
    finally:
        _FakeManager.GetCookiesAsync = original

    assert pairs == [("SID", "abc", ".google.com")]
    # Two hops on purpose: one to START the read, one to UNPACK the COM objects
    # it returns. The second hop is the fix — reading cookie.Name off the UI
    # thread is a cross-apartment COM call that blocks forever while pythonnet
    # holds the GIL, which is the freeze reported when Google mode is opened.
    assert native.invoked == 2, (
        "the read must be started AND unpacked on the UI thread; "
        f"got {native.invoked} hop(s)")
    assert seen == [ui_thread], "cookie read must happen on the UI thread"


def test_google_cookie_read_never_waits_inside_the_ui_call(fake_winforms):
    """``task.Wait()`` inside Invoke deadlocks the window's message pump.

    WebView2 completes its tasks through the UI thread, so waiting for one
    from inside the UI call blocks the very pump that has to finish it. The
    call must only start the operation; the wait belongs to the caller.
    """
    manager = _FakeManager([])
    task = _FakeTask([_FakeCookie("SID", "v", ".google.com")])
    waited_inside = []
    manager.GetCookiesAsync = lambda url: task

    ui_thread = threading.current_thread()
    native = _FakeNative(_FakeCore(manager), ui_thread)

    class Win:
        def __init__(self):
            self.native = native

    engine = google_ai.GoogleEngine()
    engine.window = Win()
    engine.visible = True
    engine._shown_evt.set()
    engine._cookies_direct("https://www.google.com/")

    # Nothing may call the blocking .NET Wait(): it holds the GIL, and every
    # other Python thread (watcher, heartbeat, Flask workers) stops with it.
    assert task.waited == 0


# ---------------------------------------------------------------------------
# The three ways a cookie read can fail, each pinned separately.
#
# The bug was reported as "signing in to Google reloads the screen and does
# nothing". Every one of these three failures looks identical from the outside:
# the jar comes back empty, so the watcher never sees a session. They are
# tested apart so a regression names the actual cause instead of repeating
# "cookies did not arrive".
# ---------------------------------------------------------------------------


def test_hidden_window_is_not_polled_for_cookies():
    """Cause (c): a hidden WebView2 never runs the tasks it is handed.

    Asking anyway produced "task did not complete in time" on every tick,
    forever, and buried the real problem. A hidden window must be reported as
    the reason, immediately, with no wait.
    """
    engine = google_ai.GoogleEngine()

    class Win:
        native = None

    engine.window = Win()
    engine.visible = False

    # Count real UI hops: the point is that NO WebView2 call is made at all,
    # not merely that the answer comes back empty. Without this the test also
    # passed with the guard removed, because a window with no native control
    # returns None from _on_ui anyway.
    hops = []
    engine._on_ui = lambda start, limit=5.0: hops.append(1)

    started = time.time()
    assert engine._cookies_direct("https://www.google.com/") == []
    assert time.time() - started < 1.0, "a hidden window must not be waited on"
    assert hops == [], "a hidden window must not be asked for cookies at all"
    assert engine.cookies_readable() is False


def test_visible_window_is_considered_readable():
    """The complement: nothing may block a read just because it is slow."""
    engine = google_ai.GoogleEngine()

    class Win:
        native = None

    engine.window = Win()
    engine.visible = True
    assert engine.cookies_readable() is True


def test_empty_task_result_is_retried_once(fake_winforms):
    """An empty list from a completed task is not an answer.

    The first read routinely races the window's first navigation and returns
    zero cookies. Believing it made a live session look signed out, which is
    the "Google sign-in does nothing" report. Driven through the real read
    path — only the manager's answers are doubles — so the retry, the COM
    flattening hop and the tuple shape are all exercised together.
    """
    cookies = [_FakeCookie("SID", "abc", ".google.com")]
    answers = [[], cookies]           # first read empty, second one real
    calls = {"n": 0}

    class FlakyManager:
        def GetCookiesAsync(self, url):
            index = min(calls["n"], len(answers) - 1)
            calls["n"] += 1
            return _FakeTask(answers[index])

    native = _FakeNative(_FakeCore(FlakyManager()), threading.current_thread())

    class Win:
        def __init__(self):
            self.native = native

    engine = google_ai.GoogleEngine()
    engine.window = Win()
    engine.visible = True
    engine._shown_evt.set()

    pairs = engine._cookies_direct("https://www.google.com/")
    assert pairs == [("SID", "abc", ".google.com")], (
        "an empty first read must be retried instead of reported as no session")
    assert calls["n"] == 2, "the read must be retried exactly once"


def test_cookie_probe_reports_the_window_state():
    """Diagnostics must answer "why" without a debugger attached."""
    engine = google_ai.GoogleEngine()

    class Win:
        native = None

    engine.window = Win()
    engine.visible = True
    engine._shown_evt.set()
    engine.host = "www.google.com"
    probe = engine.cookie_probe()
    assert probe["window"] is True
    assert probe["visible"] is True
    assert probe["shown_once"] is True
    assert probe["host"] == "www.google.com"


def test_second_sign_in_click_does_not_wipe_the_started_session():
    """A second click mid-password used to clear the jar under the person.

    From the outside that is "the screen reloaded and nothing happened", which
    is exactly how the bug was reported.
    """
    engine = google_ai.GoogleEngine()

    class Win:
        native = None

    engine.window = Win()
    engine.visible = True
    engine._shown_evt.set()

    cleared = []
    loaded = []
    engine.clear_cookies = lambda: cleared.append(True)
    engine.load = lambda url: loaded.append(url)
    engine.show = lambda: None

    engine.open_sign_in(fresh=True)
    assert cleared == [], "an already-open sign-in must keep its cookies"
    assert loaded == [], "an already-open sign-in must not be reloaded"


def test_first_sign_in_click_still_wipes_and_loads():
    """The guard above must not disable the fresh-start behaviour entirely."""
    engine = google_ai.GoogleEngine()

    class Win:
        native = None

    engine.window = Win()
    engine.visible = False

    cleared, loaded = [], []
    engine.clear_cookies = lambda: cleared.append(True)
    engine.load = lambda url: loaded.append(url)
    engine.show = lambda: None

    engine.open_sign_in(fresh=True)
    assert cleared == [True], "a fresh sign-in must start from an empty jar"
    assert loaded and "google.com" in loaded[0]


# ---------------------------------------------------------------------------
# The Google window must reach the screen
# ---------------------------------------------------------------------------
# pywebview 6.x gates load_url/evaluate_js/hide/resize on the `shown` event:
# _api_call waits 20 s and then raises WebViewException("Main window failed to
# start"). A window created with hidden=True is created as Show(); Hide(), so
# whether `shown` ever fires depends on the order in which the app touches it.
#
# The engine used to call load_url() BEFORE showing the window, so the load
# burned its 20-second wait on an event that could not arrive yet, and the
# sign-in window never appeared. That is the reported bug: "the window does not
# open on Google sign-in". These tests pin the order down.

def test_sign_in_cannot_touch_the_window_before_showing_it():
    """Opening sign-in must not call a shown-gated method on a hidden window."""
    engine = google_ai.GoogleEngine()
    calls = []

    class Win:
        native = None

        def load_url(self, url):
            calls.append(("load_url", url))

        def show(self):
            calls.append(("show", None))

    engine.window = Win()
    engine.visible = False
    engine._ever_shown = False
    engine._shown_evt = threading.Event()
    engine.wipes_on_sign_in = False      # isolate the ordering, not the wipe

    engine.open_sign_in(fresh=True)

    names = [name for name, _arg in calls]
    assert "load_url" not in names or names.index("show") < names.index("load_url"), (
        "load_url ran before show(); pywebview blocks every load_url on a "
        f"window that was never shown, so sign-in never appears: {names}")


def test_sign_in_shows_the_window_even_when_the_jar_is_kept():
    """Whatever else happens, sign-in ends with the window on screen."""
    engine = google_ai.GoogleEngine()
    calls = []

    class Win:
        native = None

        def load_url(self, url):
            calls.append("load_url")

        def show(self):
            calls.append("show")

    engine.window = Win()
    engine.visible = False
    engine._ever_shown = False
    engine._shown_evt = threading.Event()

    engine.open_sign_in(fresh=True)

    assert "show" in calls, (
        "sign-in never asked the window to come up, so nothing can appear")


def test_load_falls_back_to_webview_when_pywebview_refuses():
    """A window that never reported `shown` must still be able to navigate.

    pywebview raises "Main window failed to start" after its 20 s wait, and
    every later load_url repeats that wait. Going to WebView2 directly is the
    only way such a window can show a page at all.
    """
    engine = google_ai.GoogleEngine()
    navigated = []

    class Win:
        native = object()

        def load_url(self, url):
            raise RuntimeError("Main window failed to start")

    engine.window = Win()
    engine._navigate_direct = lambda url: (navigated.append(url), True)[1]

    assert engine.load("https://www.google.com/") is True
    assert navigated == ["https://www.google.com/"]


def test_load_still_reports_failure_when_nothing_works():
    """No silent success: if neither path works, the caller hears about it."""
    engine = google_ai.GoogleEngine()

    class Win:
        native = None

        def load_url(self, url):
            raise RuntimeError("Main window failed to start")

    engine.window = Win()
    engine._navigate_direct = lambda url: False

    assert engine.load("https://www.google.com/") is False


# ---------------------------------------------------------------------------
# Waiting must end when waiting cannot help
# ---------------------------------------------------------------------------
# These are about time, and a test that measures time by sleeping is a test
# that is slow on purpose. Each one asserts the count of probes instead.

def test_a_window_with_no_js_bridge_is_not_asked_eighty_times():
    """The twenty-second stall: polling a window that cannot answer.

    `_wait_for_page` used to spin for its full timeout whatever the window did.
    A stand-in with no `evaluate_js` failed every probe identically, so the
    loop was twenty seconds of the same failure -- on every sign-in, and in
    every test that opened one.
    """
    engine = google_ai.GoogleEngine()
    engine.window = type("Blind", (), {"is_browser": True})()
    assert engine._window_cannot_answer() is True
    started = time.time()
    assert engine._wait_for_page("https://www.google.com/", timeout=20) is False
    spent = time.time() - started
    assert spent < 1.0, f"waited {spent:.1f}s for a window that cannot answer"


def test_a_slow_page_is_still_given_its_time():
    """The opposite mistake: declaring a loading page dead.

    A page that answers "nothing yet" is loading, not broken, and the wait has
    to cover it. Only a window that cannot answer at all may be abandoned.
    """
    engine = google_ai.GoogleEngine()
    started = time.time()

    class Loading:
        is_browser = True

        def evaluate_js_value(self, script, timeout=None):
            if time.time() - started < 0.6:
                return ""                       # painted nothing yet
            return "www.google.com" if "location.host" in script else "https://www.google.com/"

    engine.window = Loading()
    assert engine._wait_for_page("https://www.google.com/", timeout=10) is True
    assert engine.host == "www.google.com"


def test_a_window_that_reports_no_events_is_not_waited_for():
    """`shown` can only arrive from a window that has an event surface."""
    engine = google_ai.GoogleEngine()
    engine.window = type("Bare", (), {"is_browser": False, "show": lambda self: None})()
    engine.visible = False
    started = time.time()
    engine.ensure_visible()
    assert time.time() - started < 2.0, "waited for a `shown` event that cannot exist"
