"""Which window the Google pane gets, and what happens when none can start.

The policy changed in the field. It used to be "browser, else WebView2, else
pywebview", and that fallback is what killed the app: on a machine where no
browser could be found, the WebView2 host started and the process died with an
empty log. Now the only automatic choice is the browser (the component that has
never frozen this app), WebView2 is reachable only by asking for it, and "no
window" is a real, working outcome -- Google chats go over plain HTTPS with
saved cookies either way.
"""

from __future__ import annotations

import pytest

from arena import desktop


class FakeHost:
    """Stands in for a window host."""

    def __init__(self, builds: bool, error: str | None = None):
        self.builds = builds
        self.error = error
        self.destroyed = False

    def wait_built(self, timeout=8.0):
        return self.builds

    def state(self):
        return {"build_error": self.error}

    def destroy(self):
        self.destroyed = True


@pytest.fixture
def pywebview_used(monkeypatch):
    """Record pywebview's window creation instead of making one."""
    from types import SimpleNamespace
    calls = []

    def fake_create_window(*a, **kw):
        calls.append((a, kw))
        return "pywebview-window"

    monkeypatch.setattr(desktop, "_pywebview",
                        lambda: SimpleNamespace(create_window=fake_create_window))
    return calls


@pytest.fixture(autouse=True)
def clean_env(monkeypatch):
    monkeypatch.delenv("ARENA_GOOGLE_WINDOW", raising=False)


# -- the browser is the only automatic choice ------------------------------

def test_a_browser_that_answers_is_used(monkeypatch):
    host = FakeHost(builds=True)
    monkeypatch.setattr("arena.browserwindow.create_google_window",
                        lambda **kw: host)
    assert desktop.make_google_window("dir") is host


def test_a_browser_that_never_answers_leaves_no_window(monkeypatch,
                                                       pywebview_used):
    """No silent fall into WebView2 -- that is the component that crashed.

    The window is also released: a host that never answered must not be left
    running in the background where nothing can see or close it.
    """
    host = FakeHost(builds=False, error="RuntimeError: no browser")
    monkeypatch.setattr("arena.browserwindow.create_google_window",
                        lambda **kw: host)
    assert desktop.make_google_window("dir") is None
    assert host.destroyed is True
    assert pywebview_used == []


def test_a_browser_that_raises_leaves_no_window(monkeypatch, pywebview_used):
    def explode(**kw):
        raise ImportError("no websocket-client")

    monkeypatch.setattr("arena.browserwindow.create_google_window", explode)
    assert desktop.make_google_window("dir") is None
    assert pywebview_used == []


def test_no_gui_means_no_window(monkeypatch, pywebview_used):
    """On Linux `create_google_window` returns None; the pane still works."""
    monkeypatch.setattr("arena.browserwindow.create_google_window",
                        lambda **kw: None)
    assert desktop.make_google_window("dir") is None
    assert pywebview_used == []


# -- the old hosts are reachable, but only when asked ----------------------

def test_the_webview2_switch_still_works(monkeypatch, pywebview_used):
    monkeypatch.setenv("ARENA_GOOGLE_WINDOW", "webview2")
    host = FakeHost(builds=True)
    monkeypatch.setattr("arena.webwindow.create_google_window",
                        lambda **kw: host)
    called = []
    monkeypatch.setattr("arena.browserwindow.create_google_window",
                        lambda **kw: called.append(1))
    assert desktop.make_google_window("dir") is host
    assert called == [], "the browser must not be tried when WebView2 is asked for"


def test_the_pywebview_switch_still_works(monkeypatch, pywebview_used):
    monkeypatch.setenv("ARENA_GOOGLE_WINDOW", "pywebview")
    assert desktop.make_google_window("dir") == "pywebview-window"
    assert len(pywebview_used) == 1
