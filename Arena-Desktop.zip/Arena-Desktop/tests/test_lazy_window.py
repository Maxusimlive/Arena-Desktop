"""The Google window opens when it is asked for, and not before.

The regression this covers is small and very visible: the window used to be
built while the app started. With WebView2 that was free -- a hidden form, no
pixels -- but a real browser window cannot be hidden, so launching the app
threw google.com at the person immediately. They then closed it, and had
nothing left to press later.

These tests make "no window until something needs one" a property of the code
rather than a hope.
"""

from __future__ import annotations

import pytest

from arena.lazywindow import LazyWindow


class FakeEvent:
    """A real event object, as the wrapped window would carry."""

    def __init__(self):
        self.handlers = []

    def __iadd__(self, handler):
        self.handlers.append(handler)
        return self

    def __isub__(self, handler):
        self.handlers = [h for h in self.handlers if h is not handler]
        return self

    def set(self):
        for handler in list(self.handlers):
            handler()


class FakeEvents:
    def __init__(self):
        self.loaded = FakeEvent()
        self.shown = FakeEvent()
        self.closing = FakeEvent()
        self.closed = FakeEvent()


class FakeWindow:
    """Stands in for a browser window, recording what was asked of it."""

    def __init__(self):
        self.calls = []
        self.events = FakeEvents()
        self.native = object()
        self.webview = None

    def show(self):
        self.calls.append("show")

    def hide(self):
        self.calls.append("hide")

    def load_url(self, url):
        self.calls.append(("load_url", url))
        return True

    def evaluate_js(self, script, *a, **kw):
        self.calls.append(("evaluate_js", script))
        return "value"

    def get_cookies(self, *a, **kw):
        self.calls.append("get_cookies")
        return [("SID", "abc")]

    def cookie_tuples(self, *a, **kw):
        self.calls.append("cookie_tuples")
        return [("SID", "abc", ".google.com")]

    def clear_cookies(self):
        self.calls.append("clear_cookies")
        return True

    def resize(self, w, h):
        self.calls.append(("resize", w, h))

    def move(self, x, y):
        self.calls.append(("move", x, y))

    def restore(self):
        self.calls.append("restore")

    def destroy(self):
        self.calls.append("destroy")

    def wait_built(self, timeout=8.0):
        return True

    def is_ready(self):
        return True

    def state(self):
        return {"platform": "fake"}

    @property
    def host(self):
        return "www.google.com"


@pytest.fixture
def made():
    """The factory's output, and how many times it ran."""
    box = {"count": 0, "window": FakeWindow()}

    def factory():
        box["count"] += 1
        return box["window"]

    return box, factory


# -- nothing happens until it is needed -----------------------------------

def test_nothing_is_created_when_the_window_is_only_attached(made):
    """This is the launch case: attach() must not open a browser."""
    box, factory = made
    win = LazyWindow(factory)
    win.events.loaded += lambda: None       # what attach() does
    win.events.closing += lambda: None
    assert box["count"] == 0


def test_inspection_does_not_open_anything(made):
    """Status polls run constantly; they must stay free."""
    box, factory = made
    win = LazyWindow(factory)
    win.state()
    win.host
    win.is_ready()
    assert win.window is None
    assert box["count"] == 0


def test_show_opens_the_window(made):
    """Pressing the button is a real ask."""
    box, factory = made
    win = LazyWindow(factory)
    win.show()
    assert box["count"] == 1
    assert "show" in box["window"].calls


def test_sign_in_navigation_opens_the_window(made):
    """`open_sign_in` navigates first; that must bring the window up."""
    box, factory = made
    win = LazyWindow(factory)
    win.load_url("https://www.google.com/")
    assert box["count"] == 1
    assert ("load_url", "https://www.google.com/") in box["window"].calls


def test_reading_the_jar_opens_the_window(made):
    """Pasted cookies have to be written into a page, so a page is needed."""
    box, factory = made
    win = LazyWindow(factory)
    win.cookie_tuples()
    assert box["count"] == 1


def test_evaluating_a_script_alone_does_not_open_a_browser(made):
    """A stray poll must not be a reason to launch Chrome.

    Script evaluation happens inside sign-in and cookie work, both of which
    open the window by themselves. Doing it here would put a browser window on
    screen for something that was only a status check.
    """
    box, factory = made
    win = LazyWindow(factory)
    assert win.evaluate_js("location.host") is None
    assert box["count"] == 0


def test_the_window_is_created_once(made):
    box, factory = made
    win = LazyWindow(factory)
    win.show()
    win.load_url("https://www.google.com/")
    win.cookie_tuples()
    assert box["count"] == 1


# -- closing is not destroying --------------------------------------------

def test_hide_does_not_close_the_window(made):
    """Hiding used to destroy the session before its cookies were read."""
    box, factory = made
    win = LazyWindow(factory)
    win.show()
    win.hide()
    assert "destroy" not in box["window"].calls
    assert win.state()["opened"] is False
    # ...and asking again brings it back rather than opening a second one.
    win.show()
    assert box["count"] == 1


def test_destroy_releases_the_window_and_a_later_show_reopens_it(made):
    box, factory = made
    win = LazyWindow(factory)
    win.show()
    win.destroy()
    assert "destroy" in box["window"].calls
    win.show()
    assert box["count"] == 2, "a destroyed window must be built again, not reused"


# -- events survive the delay ---------------------------------------------

def test_handlers_attached_before_the_window_exists_still_fire(made):
    """`attach()` subscribes at startup, when the window does not exist yet."""
    box, factory = made
    fired = []
    win = LazyWindow(factory)
    win.events.loaded += lambda: fired.append("loaded")
    assert fired == []
    win.show()                                   # the window (and its events) appear
    real = box["window"].events
    real.loaded.set()
    assert fired == ["loaded"], "a pre-attached handler was lost"


def test_wait_built_says_yes_when_nothing_has_been_asked_for(made):
    """A window that has not been opened yet is not a broken window.

    Startup uses this answer to decide whether to fall back to WebView2;
    answering "no" would throw away a perfectly good build on every launch.
    """
    box, factory = made
    win = LazyWindow(factory)
    assert win.wait_built(0.1) is True
    assert box["count"] == 0


def test_the_state_says_the_window_is_deferred(made):
    box, factory = made
    win = LazyWindow(factory)
    state = win.state()
    assert state["deferred"] is True
    win.show()
    assert win.state()["deferred"] is False
