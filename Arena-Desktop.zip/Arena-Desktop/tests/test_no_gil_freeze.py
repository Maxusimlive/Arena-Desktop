"""Reproduce the "whole app freezes" bug without a Windows machine.

The failure the user reports cannot be reached on Linux by running the app:
it needs WebView2 and a real WinForms message pump. But the *bug itself* is
not Windows-specific — it is a bad interaction between Python threads and a
blocking call, and that reproduces exactly.

What went wrong, in order:

1. A Flask worker thread asked for Google cookies.
2. ``_cookies_from_edge`` reached into WebView2 through ``CoreWebView2``.
3. Getting there involved a blocking .NET call (``Task.Wait`` / ``Invoke``),
   which pythonnet performs **while holding the GIL**.
4. Every other Python thread stopped dead: the log watchdog, the heartbeat,
   the request workers. The process looked frozen, no exception, no traceback,
   and the crash file stayed empty because nothing actually crashed.

These tests encode the three rules that keep that from happening, and they
fail loudly if a future change breaks them. They run on Linux, in CI, in a
fraction of a second — which is the point: the bug should be caught here, not
on the user's machine after a rebuild.
"""

from __future__ import annotations

import sys
import threading
import time
import types

import pytest

from arena import google_ai
from gilprobe import GilProbe, _libc


# --------------------------------------------------------------------------
# A window whose UI thread never runs: the worst case in the real app.
# --------------------------------------------------------------------------

class DeadUiNative:
    """A WinForms form whose UI thread is wedged and runs nothing at all.

    ``BeginInvoke`` queues the delegate and returns — exactly like the real
    one. Nothing ever picks it up, which is what a busy or blocked UI thread
    looks like from the inside.
    """

    def __init__(self):
        self.InvokeRequired = True
        self.queued = []
        self.invoke_calls = 0

    def BeginInvoke(self, invoker):
        self.queued.append(invoker)  # accepted, never executed
        return None

    def Invoke(self, invoker):
        self.invoke_calls += 1
        raise AssertionError(
            "blocking Invoke() was called: it holds the GIL and freezes the "
            "whole process when the UI thread is busy")


class Core:
    class CookieManager:
        pass

    class Profile:
        @staticmethod
        def ClearBrowsingDataAsync():
            raise AssertionError("WebView2 was touched from a non-UI thread")


class Control:
    @property
    def CoreWebView2(self):
        return Core()


class DeadWindow:
    """pywebview Window stand-in backed by a wedged UI thread."""

    def __init__(self):
        self.native = DeadUiNative()
        self.native.webview = Control()
        self.native.browser = None
        self._on_top = False

    @property
    def on_top(self):
        return self._on_top

    @on_top.setter
    def on_top(self, value):
        self._on_top = value

    def hide(self):
        """pywebview's hide() is @_shown_call: it hops to the UI thread."""
        self.hidden = True

    def show(self):
        self.shown = True


@pytest.fixture()
def winforms(monkeypatch):
    """The real ``System.Windows.Forms`` only exists on Windows."""
    module = types.ModuleType("System.Windows.Forms")

    class MethodInvoker:
        def __init__(self, fn):
            self.fn = fn

        def __call__(self, *a):
            return self.fn(*a)

    module.MethodInvoker = MethodInvoker
    monkeypatch.setitem(sys.modules, "System.Windows.Forms", module)
    return module


def _live_counter(stop: threading.Event):
    """A thread that counts ticks. It only runs if the GIL is free."""
    ticks = []

    def run():
        while not stop.is_set():
            ticks.append(time.monotonic())
            time.sleep(0.02)

    thread = threading.Thread(target=run, daemon=True)
    thread.start()
    return ticks, thread


# --------------------------------------------------------------------------
# The three rules
# --------------------------------------------------------------------------

def test_cookie_read_never_holds_the_gil(winforms):
    """THE regression: reading cookies must not stop other Python threads.

    This is the exact shape of the reported freeze. If the cookie path makes a
    blocking .NET call while holding the GIL, this counter stops ticking and
    the assertion fails — on Linux, before any build is shipped.
    """
    engine = google_ai.GoogleEngine()
    engine.window = DeadWindow()
    engine._ever_shown = True    # a real window that has been on screen

    stop = threading.Event()
    ticks, thread = _live_counter(stop)
    try:
        started = time.monotonic()
        engine.cookies(tries=1)          # must return, however empty
        elapsed = time.monotonic() - started
    finally:
        stop.set()
        thread.join(timeout=2)

    # Sanity: the call must not block for long even with a dead UI thread.
    assert elapsed < 8.0, (
        f"cookie read took {elapsed:.1f}s against a wedged UI thread; "
        "a bounded wait is missing somewhere")

    # The real check: other threads kept running throughout.
    assert len(ticks) >= 3, (
        f"only {len(ticks)} ticks in {elapsed:.1f}s — other Python threads were "
        "starved, which means a blocking .NET call held the GIL")


def test_no_blocking_invoke_is_ever_used(winforms):
    """``Invoke`` waits for the UI thread; ``BeginInvoke`` does not.

    Refusing the blocking flavour is deliberate: calling it from a worker while
    the UI thread waits on that worker is a deadlock no timeout can break —
    the process simply stops.
    """
    native = DeadUiNative()
    engine = google_ai.GoogleEngine()
    engine.window = DeadWindow()
    engine.window.native = native

    # Anything that tries Invoke raises from inside the fake, so a green test
    # proves the blocking path was never taken.
    engine.cookies(tries=1)
    assert native.invoke_calls == 0


def test_cookie_read_gives_up_instead_of_waiting_forever(winforms):
    """A wedged UI thread must produce an empty answer, not a hung process."""
    native = DeadUiNative()
    engine = google_ai.GoogleEngine()
    engine.window = DeadWindow()
    engine.window.native = native

    started = time.monotonic()
    jar = engine.cookies(tries=1)
    elapsed = time.monotonic() - started

    assert jar == "", "no session is available when the UI never answers"
    assert elapsed < 8.0, f"gave up only after {elapsed:.1f}s"


def test_hide_does_not_block_on_a_wedged_ui_thread(winforms):
    """Closing the chats drawer calls hide() from its own thread.

    ``on_top`` is not marshalled by pywebview, so setting it from that thread
    is what used to freeze everything. It must go through the non-blocking hop.
    """
    from arena.engine import BrowserEngine

    window = DeadWindow()
    engine = BrowserEngine.__new__(BrowserEngine)
    engine.window = window
    engine.dock = None
    engine.visible = True

    stop = threading.Event()
    ticks, thread = _live_counter(stop)
    try:
        started = time.monotonic()
        engine.hide()
        elapsed = time.monotonic() - started
    finally:
        stop.set()
        thread.join(timeout=2)

    # hide() is fast by construction, so the count of ticks is not the measure
    # here: the elapsed time is. A GIL-holding version took seconds.
    assert elapsed < 1.0, (
        f"hide() blocked for {elapsed:.1f}s — it must not wait for the UI thread")
    assert window.native.invoke_calls == 0, "hide() used a blocking Invoke"

    # on_top is queued rather than awaited; once the UI thread gets to it, the
    # value must actually be applied.
    assert window.native.queued, "on_top was never handed to the UI thread"
    for invoker in window.native.queued:
        invoker()
    assert window.on_top is False, "the queued on_top call did not take effect"


def test_await_task_polls_without_blocking(winforms):
    """The waiting helper must poll, so the GIL is released between checks."""
    class Task:
        def __init__(self, delay):
            self.deadline = time.monotonic() + delay

        @property
        def IsCompleted(self):
            return time.monotonic() >= self.deadline

        @property
        def Result(self):
            return "done"

    stop = threading.Event()
    ticks, thread = _live_counter(stop)
    try:
        ok, value = google_ai._await_task(Task(0.4), 3.0)
    finally:
        stop.set()
        thread.join(timeout=2)

    assert ok and value == "done"
    assert len(ticks) >= 5, (
        "the counter barely moved while waiting — _await_task is holding the GIL")

def test_cookie_await_is_bounded_even_when_the_task_never_completes(winforms):
    """The exact reported case: a WebView2 task that never completes.

    Before the fix the code called ``Task.Wait()`` here. That holds the GIL, so
    the counter stops, the log stops, and the app is dead while the process is
    still alive — the crash file stays empty, which is what made this bug so
    hard to see. The bound must be enforced by polling, not by a blocking wait.
    """
    engine = google_ai.GoogleEngine()
    engine.window = DeadWindow()
    engine._ever_shown = True

    class NeverCompletes:
        IsCompleted = False
        Result = None
        # A blocking Wait() would be called here on the broken version:
        def Wait(self, ms):                      # pragma: no cover - must not run
            raise AssertionError("Task.Wait() blocks while holding the GIL")

    original = google_ai._await_task
    google_ai._await_task = lambda task, timeout: original(NeverCompletes(), 0.3)
    try:
        with GilProbe() as probe:
            started = time.monotonic()
            engine.cookies(tries=1)
            elapsed = time.monotonic() - started
    finally:
        google_ai._await_task = original

    assert elapsed < 8.0, f"never-completing task held the caller for {elapsed:.1f}s"
    assert probe.moved, (
        "other threads were starved while waiting: a GIL-holding call is back — "
        + probe.describe())

# --------------------------------------------------------------------------
# pywebview's own 20-second gate — the real cause of the reported freeze
# --------------------------------------------------------------------------

class InvokingWindow:
    """A window whose hide() does what pywebview's really does.

    From pywebview 6.2.1, ``winforms.BrowserView``::

        def hide(self):
            self.Invoke(Func[Type](self.Hide))          # no InvokeRequired check

        def show(self):
            def _show(): self.Show(); self.Activate()
            if self.InvokeRequired: self.Invoke(...)     # guarded
            else: _show()

    ``Invoke`` blocks until the UI thread runs the delegate, and pythonnet
    holds the GIL for the whole wait. ``InvokeRequired`` is always True here
    because the call comes from a worker thread — the normal case in this app.
    """

    def __init__(self, ui_busy_seconds=2.0):
        self.ui_busy_seconds = ui_busy_seconds
        self.hidden = False
        self.queued = []
        self.blocking_invokes = 0

        class Events:
            shown = threading.Event()
        self.events = Events()
        self.events.shown.set()          # window was on screen

        window = self

        class Native:
            InvokeRequired = True

            def BeginInvoke(self, invoker):
                window.queued.append(invoker)     # returns at once

            def Invoke(self, invoker):
                # The real thing: waits for the UI thread while holding the GIL.
                window.blocking_invokes += 1
                libc = _libc()
                libc.usleep(int(window.ui_busy_seconds * 1_000_000))
                invoker()

            def Hide(self):
                window.hidden = True

            def Show(self):
                window.hidden = False

        self.native = Native()

    # pywebview's own method — replaced by make_window_calls_non_blocking().
    def hide(self):
        self.native.Invoke(lambda: self.native.Hide())

    def show(self):
        self.native.Invoke(lambda: self.native.Show())


def test_pywebview_blocking_invoke_is_the_freeze():
    """Baseline: the real pywebview path starves every other thread.

    Without this control the following tests could pass for the wrong reason.
    """
    window = InvokingWindow(ui_busy_seconds=1.0)
    with GilProbe() as probe:
        window.hide()                    # exactly what pywebview does

    assert not probe.moved, (
        "the model is wrong: a blocking Invoke should hold the GIL — "
        + probe.describe())
    assert window.blocking_invokes == 1


def test_window_wrapper_removes_the_blocking_invoke():
    """With the wrapper in place the same hide() must not block at all."""
    from arena import diag

    window = InvokingWindow(ui_busy_seconds=1.0)
    diag.make_window_calls_non_blocking(window)

    with GilProbe() as probe:
        started = time.monotonic()
        window.hide()
        elapsed = time.monotonic() - started

    assert elapsed < 0.3, f"hide() still blocked for {elapsed:.2f}s"
    assert window.blocking_invokes == 0, (
        "the wrapper still used a blocking Invoke — that is the freeze")

    # The work must actually be handed to the UI thread.
    assert window.queued, "Hide() was never posted to the UI thread"
    for invoker in window.queued:
        invoker()
    assert window.hidden is True, "the posted Hide() did not take effect"


def test_google_engine_hide_returns_immediately():
    """Closing the chats drawer in Google mode calls exactly this."""
    engine = google_ai.GoogleEngine()
    engine.window = InvokingWindow(ui_busy_seconds=1.0)
    with GilProbe() as probe:
        started = time.monotonic()
        engine.hide()
        elapsed = time.monotonic() - started
    # Seconds, not ticks: a correct hide() returns in microseconds, far too
    # fast for the probe to count. The elapsed time is the real signal — the
    # broken version sat here for the full 2 s gate.
    assert elapsed < 0.5, f"GoogleEngine.hide() blocked for {elapsed:.1f}s"


def test_arena_engine_hide_returns_immediately():
    """The same for the arena pane when docking is unavailable."""
    from arena.engine import BrowserEngine

    engine = BrowserEngine.__new__(BrowserEngine)
    engine.window = InvokingWindow(ui_busy_seconds=1.0)
    engine.dock = None
    engine.visible = True

    with GilProbe() as probe:
        started = time.monotonic()
        engine.hide()
        elapsed = time.monotonic() - started
    assert elapsed < 0.5, f"BrowserEngine.hide() blocked for {elapsed:.1f}s"

# --------------------------------------------------------------------------
# COM objects must be read on the UI thread — the real reported freeze
# --------------------------------------------------------------------------

class ComCookie:
    """A cookie that behaves like a CoreWebView2Cookie COM proxy.

    Reading a property off the owning thread does not raise: it blocks, and
    pythonnet holds the GIL while it does. That is exactly what
    ``desktop-crash-2.log`` shows at ``google_ai.py line 630``.
    """

    def __init__(self, name, value, domain, home):
        self._name, self._value, self._domain = name, value, domain
        self._home = home          # the "UI thread" it belongs to

    def _check(self):
        if threading.current_thread().name != self._home:
            libc = _libc()
            libc.usleep(2_000_000)      # the hang, with the GIL held
        return True

    @property
    def Name(self):
        self._check()
        return self._name

    @property
    def Value(self):
        self._check()
        return self._value

    @property
    def Domain(self):
        self._check()
        return self._domain


class CookieWindow:
    """Window whose GetCookiesAsync returns real COM-ish cookies."""

    def __init__(self, ui_thread_name="MainThread"):
        self.ui_thread = ui_thread_name
        self.queued = []
        window = self

        class CookieManager:
            def GetCookiesAsync(self, url):
                return [ComCookie(c, "v", ".google.com", window.ui_thread)
                        for c in ("SID", "HSID", "SSID")]

        class Core:
            pass

        Core.CookieManager = CookieManager()

        class Native:
            InvokeRequired = True

            def BeginInvoke(self, invoker):
                window.queued.append(invoker)

        self.native = Native()
        self.native.webview = type("W", (), {"CoreWebView2": Core()})()

    def run_queued(self):
        """Stand-in for the UI thread draining its message queue."""
        for invoker in self.queued:
            invoker()
        self.queued.clear()


def test_cookie_fields_are_read_on_the_ui_thread(fake_winforms):
    """The freeze: cookie.Name on a Flask thread blocks forever, GIL and all."""
    engine = google_ai.GoogleEngine()
    # The cookies belong to the thread that drains the window's queue — that is
    # what the pywebview UI thread is on Windows. Naming it here is what makes
    # an off-thread read block, exactly like the real COM proxy.
    engine.window = CookieWindow(ui_thread_name="ui-loop")
    # The window is on screen in this scenario (that is the whole point: a
    # visible window's renderer runs its tasks). A hidden one is deliberately
    # not polled at all — see test_hidden_window_is_not_polled_for_cookies.
    engine.visible = True
    engine._shown_evt.set()

    def ui_loop():
        while True:
            window = engine.window
            if window is None:
                return
            window.run_queued()
            time.sleep(0.01)

    ui = threading.Thread(target=ui_loop, daemon=True, name="ui-loop")
    ui.start()
    try:
        with GilProbe() as probe:
            started = time.monotonic()
            pairs = engine._cookies_direct("https://www.google.com/", limit=2.0)
            elapsed = time.monotonic() - started
        assert elapsed < 1.5, (
            f"_cookies_direct blocked for {elapsed:.1f}s — COM was read off the "
            "UI thread")
        # No GIL assertion here: the whole call now takes ~40 ms, far too fast
        # for the probe to tick. The elapsed bound above is the real signal —
        # the broken version sat for the full 2 s COM timeout. What this test
        # additionally pins down is that COM objects never escape the UI thread.
        assert pairs, "cookies came back empty"
        assert pairs == [("SID", "v", ".google.com"),
                         ("HSID", "v", ".google.com"),
                         ("SSID", "v", ".google.com")], pairs
    finally:
        engine.window = None

# --------------------------------------------------------------------------
# Never wait for a WebView2 task *inside* the UI call
# --------------------------------------------------------------------------

class PumpWindow:
    """A window whose async tasks only finish while the UI thread is free.

    This is how WebView2 and WinForms actually behave: ``ExecuteScriptAsync``
    posts its completion back to the UI thread's message pump. Waiting for
    that task inside an Invoke/BeginInvoke delegate therefore blocks the very
    pump that would complete it — the wait can only ever time out, and while
    it runs the UI thread is stuck, so nothing is drawn and no later call is
    served. That is why the sign-in window never appeared.
    """

    def __init__(self):
        self.ui_free = threading.Event()
        self.ui_free.set()
        self.hidden = True
        window = self

        class Task:
            def __init__(self, value):
                self._value = value
                self._done = False

            @property
            def IsCompleted(self):
                return self._done

            @property
            def Result(self):
                return self._value

            def finish(self):
                self._done = True

        self.Task = Task
        self.pending = []

        class Core:
            def ExecuteScriptAsync(self, script):
                task = Task('"example.test"' if "host" in script else '"title"')
                window.pending.append(task)
                return task

        class Manager:
            def GetCookiesAsync(self, url):
                task = Task([])
                window.pending.append(task)
                return task

        class CoreWrap:
            """Stands in for CoreWebView2: it carries both the script call and
            the cookie manager, exactly like the real object."""
            CookieManager = Manager()

            def ExecuteScriptAsync(self, script):
                return Core().ExecuteScriptAsync(script)

        self.Core = Core

        class Native:
            InvokeRequired = True

            def BeginInvoke(self, invoker):
                window.queued.append(invoker)

        self.queued = []
        self.native = Native()
        self.native.webview = type("W", (), {"CoreWebView2": CoreWrap()})()

    def drain(self):
        """Run queued UI work, then complete the tasks it started.

        Completion takes a beat, exactly like a real WebView2 round trip — the
        test must not pass just because the mock answers synchronously.
        """
        while self.queued:
            invoker = self.queued.pop(0)
            invoker()
        if self.pending:
            time.sleep(0.05)
            for task in self.pending:
                task.finish()
            self.pending.clear()


def test_page_facts_does_not_wait_inside_the_ui_call(fake_winforms):
    """The sign-in window stayed invisible because of exactly this."""
    engine = google_ai.GoogleEngine()
    window = PumpWindow()
    engine.window = window

    stop = threading.Event()

    def ui_loop():
        while not stop.is_set():
            window.drain()
            time.sleep(0.01)

    ui = threading.Thread(target=ui_loop, daemon=True, name="ui-pump")
    ui.start()
    try:
        started = time.monotonic()
        host, title = engine._page_facts()
        elapsed = time.monotonic() - started
        assert elapsed < 1.0, (
            f"_page_facts took {elapsed:.1f}s — it waited for the task inside "
            "the UI call, blocking the pump that completes it")
        assert (host, title) == ("example.test", "title"), (host, title)
    finally:
        stop.set()
        engine.window = None

# --------------------------------------------------------------------------
# IsCompleted must be detected from the type, never with hasattr()
# --------------------------------------------------------------------------

class HiddenTask:
    """A .NET task whose property lookup raises, so ``hasattr`` says False.

    That is the whole trap: pythonnet hides members it cannot serve from the
    calling apartment, and ``hasattr`` converts the resulting AttributeError
    into "this object has no such member". Both detection sites in
    ``google_ai`` used ``hasattr`` and therefore classified a live WebView2
    task as a plain object, giving up in about 20 ms — the "[google-cookies]
    task did not complete in time" line that repeated on every attempt.

    The property is declared on the class, which is why looking at the *type*
    answers correctly.
    """

    def __init__(self, value):
        self._value = value

    @property
    def IsCompleted(self):          # noqa: N802  (mirrors the .NET name)
        raise AttributeError("CoreWebView2 task: cannot be read from here")

    @property
    def Result(self):
        raise AttributeError("CoreWebView2 task: cannot be read from here")


def test_has_completed_is_detected_from_the_type_not_from_hasattr():
    """hasattr() lies about .NET proxies; the detection must not use it."""
    task = HiddenTask(["SID"])

    # The trap, demonstrated: the property exists, yet hasattr denies it.
    assert "IsCompleted" in dir(type(task))
    assert hasattr(task, "IsCompleted") is False, (
        "the model is wrong: hasattr must lie for this test to mean anything")
    assert hasattr(type(task), "IsCompleted") is True

    assert google_ai._has_is_completed(task) is True, (
        "detection must look at the class; otherwise a live task is dismissed "
        "as a plain object and the read fails in about 20 ms")


def test_await_task_does_not_give_up_instantly():
    """The old early-exit returned (False, None) within milliseconds."""
    task = HiddenTask(["SID"])

    started = time.monotonic()
    ok, value = google_ai._await_task(task, 0.4)
    elapsed = time.monotonic() - started

    assert ok is False and value is None
    assert elapsed >= 0.3, (
        f"returned after {elapsed * 1000:.0f} ms — it treated the task as a "
        "plain object instead of waiting for it")


def test_await_task_waits_instead_of_giving_up():
    """A task that is not ready must be waited for, not abandoned instantly."""

    class PendingTask:
        def __init__(self):
            self.ready = False

        @property
        def IsCompleted(self):          # noqa: N802
            return self.ready

        @property
        def Result(self):
            return "done"

    task = PendingTask()

    def finish_later():
        time.sleep(0.3)
        task.ready = True

    threading.Thread(target=finish_later, daemon=True).start()
    started = time.monotonic()
    ok, value = google_ai._await_task(task, 2.0)
    elapsed = time.monotonic() - started
    assert ok is True, "gave up instead of waiting for the task"
    assert value == "done"
    assert elapsed >= 0.25, (
        f"returned after {elapsed:.2f}s — it did not actually wait")
