"""One browser window per site, and arena.ai signed in the same way as Google.

Three things are pinned here, all of them from what the app did wrong in the
field:

* pressing "Sign in to Google" opened **two** windows -- the browser showed the
  URL it was started with, and the first navigation opened the page again;
* arena.ai still signed in through an in-app WebView while Google moved to a
  real browser, so one app needed two toolchains;
* the sign-in buttons gave no sign that an account was actually signed in.
"""

from __future__ import annotations

import ast
from pathlib import Path

import pytest

from arena import browserwindow as bw


# -- one window ------------------------------------------------------------

def test_the_browser_is_started_blank():
    """The command line must not carry the site.

    A URL on the command line makes the browser open a window of its own, and
    the app's first navigation then opens a second one. Only one of them can be
    driven, so the other just sits there looking like the app is confused.
    """
    source = Path(bw.__file__).read_text()
    tree = ast.parse(source)

    appended = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and getattr(node.func, "attr", None) == "append":
            if isinstance(node.func.value, ast.Name) and node.func.value.id == "args":
                appended.append(ast.unparse(node))
    assert appended, "the browser arguments are built somewhere unexpected"
    assert any("about:blank" in line for line in appended), (
        "the browser is not started on about:blank")
    assert not any("self.url" in line for line in appended), (
        "the site URL is still passed on the command line, which opens a "
        "second window")


def test_navigating_reuses_the_page_instead_of_opening_another(monkeypatch):
    win = bw.BrowserWindow("https://www.google.com/")
    win._debug_ok = True          # the port is already up
    opened = []
    navigated = []

    monkeypatch.setattr(bw.BrowserWindow, "tab",
                        lambda self: {"webSocketDebuggerUrl": "ws://x"})
    monkeypatch.setattr(bw, "_open_tab", None, raising=False)
    monkeypatch.setattr(bw.BrowserWindow, "_open_tab",
                        lambda self, url: opened.append(url))
    monkeypatch.setattr(bw, "_navigate", None, raising=False)
    monkeypatch.setattr(bw.BrowserWindow, "_navigate",
                        lambda self, tab, url: navigated.append(url) or True)

    class Immediate(threading_thread()):
        """Runs the work inline so the assertions do not race a thread."""

        def __init__(self, target=None, **kw):
            self._target = target

        def start(self):
            self._target()

    monkeypatch.setattr(bw.threading, "Thread", Immediate)
    win.load_url("https://www.google.com/")
    assert opened == [], "a second window was opened although a page existed"
    assert navigated == ["https://www.google.com/"]


def threading_thread():
    import threading
    return threading.Thread


def test_a_page_is_created_only_when_there_is_none(monkeypatch):
    win = bw.BrowserWindow("https://www.google.com/")
    win._debug_ok = True
    opened = []
    navigated = []
    monkeypatch.setattr(bw.BrowserWindow, "tab", lambda self: None)
    monkeypatch.setattr(bw.BrowserWindow, "_open_tab",
                        lambda self, url: opened.append(url) or {
                            "webSocketDebuggerUrl": "ws://new"})
    monkeypatch.setattr(bw.BrowserWindow, "_navigate",
                        lambda self, tab, url: navigated.append(url) or True)

    class Immediate(threading_thread()):
        def __init__(self, target=None, **kw):
            self._target = target

        def start(self):
            self._target()

    monkeypatch.setattr(bw.threading, "Thread", Immediate)
    win.load_url("https://accounts.google.com/")
    assert len(opened) == 1
    assert navigated == ["https://accounts.google.com/"]


# -- arena.ai goes through the same transport ------------------------------

def test_an_arena_window_is_offered_by_the_browser_transport():
    assert hasattr(bw, "create_arena_window")
    assert bw.ARENA_DOMAINS == ("arena.ai",)


def test_desktop_builds_the_arena_window_lazily_too():
    """Signing in to arena must not open a browser at launch either."""
    source = (Path(__file__).resolve().parent.parent
              / "arena" / "desktop.py").read_text()
    assert "make_arena_window" in source
    assert "arena-browser" in source, (
        "arena needs its own browser profile, like Google")
    # and it is wrapped, so nothing opens until it is asked for
    assert "arena_win = LazyWindow(" in source


def test_the_engine_reads_a_browser_jar(monkeypatch):
    """`engine.cookies()` must work with a window that has no pywebview jar."""
    from arena.engine import ENGINE

    class Browserish:
        def cookie_tuples(self, *a, **kw):
            return [("arena-auth-prod-v1.0", "abc", ".arena.ai"),
                    ("other", "ignored", ".example.com")]

    original = ENGINE.window
    try:
        ENGINE.window = Browserish()
        jar = ENGINE.cookies()
        assert jar.get("arena-auth-prod-v1.0") == "abc"
    finally:
        ENGINE.window = original


def test_a_window_without_a_jar_reader_still_uses_pywebview(monkeypatch):
    from arena.engine import ENGINE

    class Pywebviewish:
        def get_cookies(self):
            return [{"arena-auth-prod-v1.0": type("M", (), {
                "value": "old", "get": lambda self, k, d=None: ".arena.ai"})()}]

    original = ENGINE.window
    try:
        ENGINE.window = Pywebviewish()
        assert ENGINE.cookies().get("arena-auth-prod-v1.0") == "old"
    finally:
        ENGINE.window = original


# -- the tick beside a sign-in button --------------------------------------

def test_the_ui_has_a_tick_for_each_sign_in_button():
    """Both accounts are independent, so both need their own confirmation."""
    app_js = (Path(__file__).resolve().parent.parent
              / "arena" / "web" / "static" / "app.js").read_text()
    assert "signin-tick" in app_js
    assert "function signInTick(" in app_js
    assert "arenaTick" in app_js and "googleTick" in app_js
    # the tick is driven by the account itself, not by "the window opened"
    assert "function arenaSignedIn(" in app_js
    assert "function googleSignedIn(" in app_js


def test_the_tick_is_hidden_until_signed_in():
    css = (Path(__file__).resolve().parent.parent
           / "arena" / "web" / "static" / "style.css").read_text()
    assert '.signin-tick[data-signed-in="false"]' in css, (
        "an unsigned tick must take no space, or the button jumps when it turns on")


def test_the_browsers_own_start_page_is_not_treated_as_our_page(monkeypatch):
    """The pane reported success while the window showed the browser's home.

    `page_tab` used to fall back to "the first page tab", so the browser's start
    page (edge://newtab) counted as ours: `loaded` fired, the tick went green,
    and google.com was never opened.
    """
    monkeypatch.setattr(bw, "_tabs", lambda port: [
        {"type": "page", "url": "edge://newtab/",
         "webSocketDebuggerUrl": "ws://start"},
    ])
    assert bw.page_tab(1234, bw.GOOGLE_DOMAINS) is None, (
        "the browser's start page was taken for the site's page")


def test_a_blank_tab_is_usable(monkeypatch):
    monkeypatch.setattr(bw, "_tabs", lambda port: [
        {"type": "page", "url": "about:blank", "webSocketDebuggerUrl": "ws://b"},
    ])
    assert bw.page_tab(1234, bw.GOOGLE_DOMAINS)["webSocketDebuggerUrl"] == "ws://b"


def test_a_navigation_waits_for_the_port_instead_of_giving_up(monkeypatch):
    """The button can be pressed before the browser has finished starting."""
    win = bw.BrowserWindow("https://www.google.com/")
    called = []
    monkeypatch.setattr(bw, "wait_for_debugger", lambda port, timeout=20.0: True)
    monkeypatch.setattr(bw.BrowserWindow, "tab",
                        lambda self: {"webSocketDebuggerUrl": "ws://x"})
    monkeypatch.setattr(bw.BrowserWindow, "_navigate",
                        lambda self, tab, url: called.append(url) or True)

    class Immediate:
        def __init__(self, target=None, **kw):
            self._target = target

        def start(self):
            self._target()

    monkeypatch.setattr(bw.threading, "Thread", Immediate)
    win.load_url("https://www.google.com/")
    assert called == ["https://www.google.com/"]


def test_the_tick_requires_a_live_confirmation():
    """A saved account outlives its session; the tick must not.

    This is what the person saw: no window opened, no sign-in happened, and a
    green tick appeared anyway because the old account record still existed.
    """
    app_js = (Path(__file__).resolve().parent.parent
              / "arena" / "web" / "static" / "app.js").read_text()
    start = app_js.index("function googleSignedIn()")
    body = app_js[start:start + 400]
    assert "live.signed_in" in body or "account.signed_in" in body or "g.signed_in" in body, (
        "the Google tick does not check that Google itself confirmed the session")
