"""The tab of our own site must be found by its *URL*.

`page_tab` matches tabs by domain. `_domain_matches` takes a bare domain
(``www.google.com``, as it comes from a cookie) and compares it to a list of
domains. Handing it a URL (``https://www.google.com/``) can never match:
nothing ends with ``.google.com`` because of the scheme and the trailing
slash.

That single argument deciding everything downstream:

* `page_tab` returned None for a browser that was showing google.com — the
  log line "page is https://www.google.com/" could never be reached from
  `_watch_page`, and the pane sat 90 s and then said "no page appeared";
* `tab()` returning None made `evaluate_js` answer None, so `_wait_for_page`
  read an empty host for its whole 20 s budget and reported "no page
  confirmed" while the window was open and signed in.

These tests fail on that code and pass when the tab is matched properly.
"""

from __future__ import annotations

import pytest

from arena import browserwindow as bw


def _tabs(*urls):
    return [{"type": "page", "url": url, "webSocketDebuggerUrl": f"ws://{i}"}
            for i, url in enumerate(urls)]


@pytest.mark.parametrize("url", [
    "https://www.google.com/",
    "https://www.google.com/?authuser=0&hl=ru",
    "https://accounts.google.com/v3/signin/identifier",
    "https://consent.google.com/ml?continue=x",
    "https://www.google.ru/",
])
def test_a_google_url_is_recognised_as_the_google_page(monkeypatch, url):
    monkeypatch.setattr(bw, "_tabs", lambda port: _tabs(url))
    found = bw.page_tab(1234, bw.GOOGLE_DOMAINS)
    assert found is not None, f"{url} was not recognised as the Google page"
    assert found["url"] == url


@pytest.mark.parametrize("url", [
    "https://arena.ai/",
    "https://www.arena.ai/chat",
    "https://arena.ai",
])
def test_an_arena_url_is_recognised_as_the_arena_page(monkeypatch, url):
    monkeypatch.setattr(bw, "_tabs", lambda port: _tabs(url))
    assert bw.page_tab(1234, bw.ARENA_DOMAINS) is not None, url


def test_a_foreign_site_is_still_refused(monkeypatch):
    """The reason the match exists: one window serves both sites."""
    monkeypatch.setattr(bw, "_tabs", lambda port: _tabs("https://example.com/"))
    assert bw.page_tab(1234, bw.GOOGLE_DOMAINS) is None


def test_the_start_page_is_still_refused(monkeypatch):
    monkeypatch.setattr(bw, "_tabs", lambda port: _tabs("chrome://newtab/"))
    assert bw.page_tab(1234, bw.GOOGLE_DOMAINS) is None


def test_the_blank_tab_is_still_usable(monkeypatch):
    monkeypatch.setattr(bw, "_tabs", lambda port: _tabs("about:blank"))
    assert bw.page_tab(1234, bw.GOOGLE_DOMAINS) is not None


def test_cookie_domains_keep_working():
    """`cookie_tuples` passes a real domain, not a URL -- that must not change."""
    assert bw._domain_matches("google.com", bw.GOOGLE_DOMAINS)
    assert bw._domain_matches(".google.com", bw.GOOGLE_DOMAINS)   # leading dot
    assert bw._domain_matches("www.google.com", bw.GOOGLE_DOMAINS)
    assert not bw._domain_matches("notgoogle.com", bw.GOOGLE_DOMAINS)
    assert not bw._domain_matches("google.com.evil.net", bw.GOOGLE_DOMAINS)


def test_watch_page_reaches_the_page_is_line(monkeypatch, caplog):
    """The end-to-end symptom: `loaded` fires and "page is" is logged.

    This is the exact situation from the 22.11 logs -- the browser is up,
    showing google.com, and the pane still said "no page appeared".
    """
    win = bw.BrowserWindow("https://www.google.com/", user_data_dir="/tmp/x")
    win._debug_ok = True
    monkeypatch.setattr(bw, "_tabs",
                        lambda port: _tabs("https://www.google.com/?authuser=0&hl=ru"))
    monkeypatch.setattr(bw.BrowserWindow, "_navigate", lambda self, tab, url: True)
    monkeypatch.setattr(bw.BrowserWindow, "_open_tab", lambda self, url: None)

    fired = []
    win.events.loaded += lambda: fired.append(True)

    with caplog.at_level("INFO", logger="arena.browserwindow"):
        win._watch_page()

    assert fired, "the page was there but `loaded` never fired"
    joined = caplog.text
    assert "page is https://www.google.com/?authuser=0&hl=ru" in joined
    assert "no page appeared" not in joined
