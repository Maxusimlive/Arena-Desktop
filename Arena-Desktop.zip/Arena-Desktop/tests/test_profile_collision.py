"""The app must not die when the sign-in browser opens.

That is what happened the first time the browser window was used: the browser
opened and the application vanished, with nothing in `desktop.log` because the
fault was native rather than Python.

The cause was a shared profile folder. The main window's WebView2 uses
`CONFIG_DIR/webview` as its storage, and the sign-in browser was started with
`--user-data-dir` pointing at that very directory -- a Chromium pointed at a
live WebView2 store. These tests keep the two profiles apart and keep the
failure visible if it ever happens again.
"""

from __future__ import annotations

import ast
from pathlib import Path

import pytest

from arena import browserwindow as bw


# -- the profiles must be different folders -------------------------------

def test_the_sign_in_browser_does_not_use_the_main_window_profile():
    """Read straight from the source: this must never line up again.

    A behavioural test would need a Windows GUI to catch this; the invariant is
    simple enough to state about the code itself, and that is what broke.
    """
    source = (Path(__file__).resolve().parent.parent
              / "arena" / "desktop.py").read_text()
    tree = ast.parse(source)

    # Find the storage folder handed to `webview.start(...)`.
    main_storage = None
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            func = node.func
            name = getattr(func, "attr", None) or getattr(func, "id", None)
            if name == "start":
                for kw in node.keywords:
                    if kw.arg == "storage_path":
                        main_storage = ast.unparse(kw.value)
    assert main_storage, "webview.start() no longer passes storage_path"

    # `storage_path` is usually `str(storage)`, so the local assignment has to
    # be resolved before the two folders can be compared.
    if not main_storage.startswith("str(CONFIG_DIR"):
        import re
        match = re.search(r"^\s*storage\s*=\s*(.+)$", source, re.MULTILINE)
        assert match, "the WebView2 storage folder is built somewhere unexpected"
        resolved = ast.unparse(ast.parse(match.group(1)).body[0].value)
        main_storage = resolved

    # Find the folder handed to the lazy Google window.
    google_profile = None
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            func = node.func
            name = getattr(func, "attr", None) or getattr(func, "id", None)
            if name == "make_google_window":
                for arg in node.args:
                    google_profile = ast.unparse(arg)
    assert google_profile, "make_google_window is no longer called"

    # Both sides are folder expressions; one may be wrapped in str(...).
    def bare(expr: str) -> str:
        expr = expr.strip()
        if expr.startswith("str(") and expr.endswith(")"):
            return expr[4:-1].strip()
        return expr

    assert bare(main_storage) != bare(google_profile), (
        f"storage_path={main_storage} vs google profile={google_profile}\\n"
        "the sign-in browser is pointed at the main window's WebView2 profile; "
        "starting Chromium on a live WebView2 store kills the app")


def test_a_webview2_folder_is_refused_even_if_a_caller_passes_it(tmp_path):
    """Second line of defence: the transport refuses the folder itself."""
    profile = tmp_path / "webview"
    profile.mkdir()
    assert bw._safe_profile(str(profile)) is None


def test_a_folder_holding_a_webview2_store_is_refused(tmp_path):
    profile = tmp_path / "whatever"
    (profile / "EBWebView").mkdir(parents=True)
    assert bw._safe_profile(str(profile)) is None


def test_an_ordinary_folder_is_used(tmp_path):
    profile = tmp_path / "google-browser"
    assert bw._safe_profile(str(profile)) == str(profile)
    assert profile.exists(), "the folder must be created before the browser starts"


def test_no_profile_means_the_browsers_own_private_one():
    assert bw._safe_profile(None) is None


# -- a silent death must leave a trace ------------------------------------

def test_the_main_window_closing_is_written_to_the_log(monkeypatch):
    """`os._exit` leaves nothing behind, so the event is logged first.

    Without this, "the app closed when the browser opened" and "the app closed
    because I closed it" look identical in the log -- and one of them is a bug.
    """
    from arena import desktop

    source = (Path(__file__).resolve().parent.parent
              / "arena" / "desktop.py").read_text()
    assert "main window closed" in source
    assert "_on_main_closed" in source
    # and it still exits: the process must not linger after its window is gone
    assert "os._exit(0)" in source


# -- a COM collection must not be released on a worker thread ------------

def test_the_cookie_jar_leaves_as_a_plain_list(monkeypatch):
    """A .NET collection released off its apartment is a native fault.

    The engine used to hand the live collection back to a Flask thread. When
    that reference died, the release ran on the wrong thread -- one of the ways
    this app has died with an empty log.
    """
    from arena import google_ai

    class NetList:
        def __init__(self, items):
            self._items = items

        def __iter__(self):
            return iter(self._items)

        @property
        def Count(self):
            return len(self._items)

    engine = google_ai.GoogleEngine()

    class AlreadyPlain:
        """No COM objects inside: `_looks_like_cookie` says False."""

    jar = NetList([("SID", "abc"), ("SSID", "def")])

    monkeypatch.setattr(google_ai, "_looks_like_cookie", lambda value: False)
    engine.cookies_readable = lambda: True
    monkeypatch.setattr(google_ai.GoogleEngine, "_on_ui",
                        lambda self, call, limit=5.0: jar)

    result = engine._cookies_direct("https://www.google.com/")
    assert isinstance(result, list), (
        "the live .NET collection was handed to the caller instead of a list")
    assert result == [("SID", "abc"), ("SSID", "def")]
