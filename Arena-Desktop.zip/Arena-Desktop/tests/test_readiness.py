"""The startup gate: what it checks and what it refuses.

The rule the screen enforces is simple and worth pinning down in tests: a
blocking check that fails keeps the app closed. A check must also never crash
the endpoint — a broken check is a failed check, not a 500.
"""

import pytest

import arena.web.app as app_mod


@pytest.fixture()
def client():
    app_mod.app.config["TESTING"] = True
    c = app_mod.app.test_client()
    c.environ_base["HTTP_X_ARENA_TOKEN"] = app_mod._API_TOKEN
    return c


def test_check_list_names_every_step(client):
    data = client.get("/api/readiness").get_json()
    ids = [step["id"] for step in data["checks"]]
    # Accounts comes before Models on purpose: the catalog answers 403 to
    # anonymous requests, so an empty model list is a *symptom* of the missing
    # sign-in. Checking Models first showed a red error that blamed the
    # catalog for a login problem and sent people to retry the wrong thing.
    assert ids == ["dependencies", "integrity", "accounts", "arena_chats", "google_chats", "models"]
    assert all(step["title"] for step in data["checks"])


def test_every_check_answers_with_the_same_shape(client):
    for step in client.get("/api/readiness").get_json()["checks"]:
        data = client.get(f"/api/readiness?check={step['id']}").get_json()
        assert data["id"] == step["id"]
        assert isinstance(data["ok"], bool)
        assert isinstance(data["blocking"], bool)
        assert "detail" in data


def test_accounts_blocks_because_models_depend_on_it(client):
    """Without a session the catalog is empty, so this step cannot be optional.

    It used to be informational, which produced the worst combination: Models
    failed on a 403, Accounts was green with an empty list, and the person was
    told to retry a catalog request that could never succeed.
    """
    data = client.get("/api/readiness?check=accounts").get_json()
    assert data["blocking"] is True


def test_dependencies_and_integrity_block(client):
    for name in ("dependencies", "integrity"):
        data = client.get(f"/api/readiness?check={name}").get_json()
        assert data["blocking"] is True, f"{name} must gate the app"


def test_unknown_check_is_rejected(client):
    assert client.get("/api/readiness?check=nope").status_code == 400


def test_a_crashing_check_reports_failure_instead_of_500(client, monkeypatch):
    """A check that raises must answer, otherwise the screen hangs on it."""

    def boom():
        raise RuntimeError("checks must never escape")

    monkeypatch.setitem(app_mod._READINESS_CHECKS, "chats", boom)
    response = client.get("/api/readiness?check=chats")
    assert response.status_code == 200
    data = response.get_json()
    assert data["ok"] is False
    assert "RuntimeError" in data["detail"]
    assert data["blocking"] is True


def test_integrity_fails_when_a_ui_file_is_missing(client, monkeypatch):
    from pathlib import Path

    real_exists = Path.exists

    def fake_exists(self):
        if self.name == "app.js":
            return False
        return real_exists(self)

    monkeypatch.setattr(Path, "exists", fake_exists)
    data = client.get("/api/readiness?check=integrity").get_json()
    assert data["ok"] is False
    assert "app.js" in data["detail"]
    assert data["action"]


def test_models_offline_is_not_a_failure(client, monkeypatch):
    """No network is a state, not a broken install."""
    monkeypatch.setattr(app_mod, "_catalog_models", lambda *a, **k: [])

    class Offline:
        reachable = False

    monkeypatch.setattr(app_mod, "get_client", lambda: Offline())
    data = client.get("/api/readiness?check=models").get_json()
    assert data["ok"] is True
    assert data["online"] is False


def test_models_empty_while_online_is_a_failure(client, monkeypatch):
    monkeypatch.setattr(app_mod, "_catalog_models", lambda *a, **k: [])

    class Online:
        reachable = True

    monkeypatch.setattr(app_mod, "get_client", lambda: Online())
    data = client.get("/api/readiness?check=models").get_json()
    assert data["ok"] is False
    assert data["action"]


def test_chats_empty_list_still_passes(client, monkeypatch):
    monkeypatch.setattr(app_mod, "_list_chats", lambda *a, **k: [])
    data = client.get("/api/readiness?check=arena_chats").get_json()
    assert data["ok"] is True

def test_dependencies_does_not_look_for_dlls_beside_the_exe(monkeypatch, client):
    """The bug that blocked a good build.

    ``Python.Runtime.dll`` and ``ClrLoader.dll`` are bundled *inside* the
    PyInstaller executable and unpacked at runtime, so they are not siblings of
    the .exe. Searching the folder therefore reported a missing bridge on a
    perfectly healthy install and the startup screen refused to let anyone in.
    The check must prove the bridge by importing it instead.
    """
    import sys as _sys

    monkeypatch.setattr(_sys, "frozen", True, raising=False)
    monkeypatch.setattr(_sys, "_MEIPASS", "/nonexistent/extraction/dir", raising=False)

    data = client.get("/api/readiness?check=dependencies").get_json()
    # What matters: the absence of the DLLs in that fake folder is not treated
    # as a broken install. A missing bridge is reported, never fatal — it
    # breaks Google mode only, and .NET legitimately refuses to start in some
    # environments (wine among them), which must not lock the whole app.
    assert "Python.Runtime.dll is missing" not in str(data["detail"])
    assert data["ok"] is True or "bridge" in str(data["detail"])

def test_models_blames_the_missing_session_not_the_catalog(client, monkeypatch):
    """The detail must name the real cause, or people retry forever."""
    monkeypatch.setattr(app_mod, "_catalog_models", lambda *a, **k: [])

    class Anonymous:
        reachable = True
        user = None

    monkeypatch.setattr(app_mod, "get_client", lambda: Anonymous())
    data = client.get("/api/readiness?check=models").get_json()
    assert data["ok"] is False
    assert data.get("needs_account") is True
    assert "sign in" in data["detail"].lower()
    assert "sign in" in data["action"].lower()
