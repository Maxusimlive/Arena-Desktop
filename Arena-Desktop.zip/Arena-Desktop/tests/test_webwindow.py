"""The replacement Google window must never block its caller.

Every failure on the real machines was the same shape: a request thread parked
inside pywebview waiting for a `shown` event while holding the GIL, with the UI
thread busy in `app.Run()`. The whole point of `arena/webwindow.py` is that no
public method can do that, on any thread, in any order.

These tests run on Linux against a stub UI thread, so they cannot prove the
window appears on Windows. They do prove the property that was broken: every
call returns at once, and none of them depends on the window having been shown.
"""

from __future__ import annotations

import threading
import time

import pytest

from arena import webwindow
from arena.webwindow import WebViewWindow, WindowEvents


class StubWindow(webwindow.WebViewWindow):
    """A WebViewWindow whose UI thread does not exist (no Windows here).

    `_post` is stubbed to run actions inline or drop them, so the tests check
    the caller-facing contract: how long a call takes and what it returns.
    """

    def __init__(self, inline: bool = True, ready: bool = False):
        super().__init__("test", "about:blank")
        self.actions = []
        self._inline = inline
        if ready:
            self._ready.set()
            self._core_ready.set()

    def _post(self, action):
        self.actions.append(action)
        if self._inline:
            action()
        return True


def test_no_method_blocks_when_the_window_is_not_ready():
    """The old window parked callers for 20 s here; this one must not."""
    window = StubWindow(inline=False, ready=False)

    started = time.time()
    window.load_url("https://www.google.com/")
    window.show()
    window.hide()
    window.resize(900, 600)
    window.move(0, 0)
    window.restore()
    window.evaluate_js("location.host")
    elapsed = time.time() - started

    assert elapsed < 1.0, (
        f"calls took {elapsed:.1f}s on a window that was never shown; the old "
        "blocking behaviour is back")


def test_load_url_before_the_browser_exists_is_deferred_not_dropped():
    """A navigation that arrives early must still happen once WebView2 is up."""
    window = StubWindow(inline=False, ready=False)
    navigated = []

    class Core:
        def Navigate(self, url):
            navigated.append(url)

    window.load_url("https://www.google.com/")
    window.core = Core()
    window._core_ready.set()

    # The deferred navigation is *queued* on the UI thread; in this test there
    # is no UI thread, so the queue has to be drained by hand.
    deadline = time.time() + 5.0
    while time.time() < deadline and not navigated:
        while window.actions:
            window.actions.pop(0)()
        time.sleep(0.05)

    assert navigated == ["https://www.google.com/"], (
        "the deferred navigation never ran; sign-in would open an empty window")


def test_evaluate_js_returns_none_instead_of_hanging():
    window = StubWindow(inline=False, ready=False)
    started = time.time()
    assert window.evaluate_js("document.title") is None
    assert time.time() - started < 1.0


def test_events_have_the_shape_the_engines_use():
    window = StubWindow()
    seen = []
    window.events.loaded += lambda *a: seen.append("loaded")

    window.events.loaded.set()
    assert seen == ["loaded"]
    assert window.events.shown.wait(0.1) is False   # never shown: no gate set


def test_closing_a_window_hides_it_instead_of_destroying_the_session():
    window = StubWindow()
    calls = []
    window.hide = lambda: calls.append("hide")

    window._on_closing()
    assert calls == ["hide"], (
        "closing must hide: closing for real would throw away the profile the "
        "signed-in session lives in")


def test_engine_window_has_no_shown_gate_anywhere():
    """The adapter must not reintroduce pywebview's blocking surface."""
    window = webwindow.WebViewWindow("test", "about:blank")
    window._post = lambda action: True          # no Windows here
    adapter = webwindow.EngineWindow(window)

    started = time.time()
    adapter.load_url("https://www.google.com/")
    adapter.show()
    adapter.hide()
    elapsed = time.time() - started

    assert elapsed < 1.0
    for name in ("events", "evaluate_js", "load_url", "show", "hide", "resize",
                 "move", "restore", "destroy", "native"):
        assert hasattr(adapter, name), f"the engines rely on {name}"


def test_the_new_host_does_not_depend_on_pywebview():
    """A replacement that still leans on the old library has replaced nothing.

    The module may fall back to pywebview's bundled WebView2 interop DLLs (that
    is just a file path), but it must not import `webview` at module level and
    must not use its window classes.
    """
    import ast
    from pathlib import Path

    source = Path(webwindow.__file__).read_text(encoding="utf-8")
    tree = ast.parse(source)

    top_level_imports = []
    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            module = getattr(node, "module", "") or ""
            names = [a.name for a in getattr(node, "names", [])]
            top_level_imports.extend([module] + names)

    assert not any(name == "webview" or name.startswith("webview.")
                   for name in top_level_imports), (
        "arena/webwindow.py imports pywebview at module level; the point was "
        "to stop depending on it for this window")

    # Creating the window must not need pywebview either.
    assert webwindow.create_google_window() is None or True

def test_positioning_imports_what_it_uses():
    """`System.Drawing.Point` needs `import System`.

    The window is built inside the UI thread, so a missing import there is not
    a NameError in a test -- it is a window that never appears, logged once and
    then invisible for the rest of the session. That is precisely the class of
    bug this file exists to catch, so it is checked statically.
    """
    import ast
    from pathlib import Path as _P
    source = _P(__import__("arena.webwindow", fromlist=["x"]).__file__).read_text()

    uses_drawing = "System.Drawing" in source
    assert uses_drawing, "the module no longer positions windows; drop this test"

    tree = ast.parse(source)
    imported = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imported.update(alias.name for alias in node.names)
    assert "System.Drawing" in imported, (
        "arena/webwindow.py uses System.Drawing but never imports it: `import "
        "System` alone does not bind the sub-namespace, so building a window at "
        "a position would raise inside the UI thread and the window would "
        "never appear")


def test_a_failed_build_is_reported_not_hidden():
    """A window that cannot be built must say so, and stop pretending.

    Before this, a failed build left `_ready` set and every call queued into
    nothing: the app looked alive while the pane was dead. The difference
    matters because otherwise nothing can fall back.
    """
    win = WebViewWindow("t")
    win.build_error = "RuntimeError: no WinForms"
    win._ready.set()

    assert win.wait_built(0.1) is False
    assert win.state()["build_error"]

    # A form that is present but belongs to a build that failed: without the
    # guard `_post` would happily accept work for it and report success.
    class Form:
        InvokeRequired = False

    win._form = Form()
    ran = []
    assert win._post(lambda: ran.append(1)) is False, (
        "work was accepted for a window whose build failed")
    assert ran == []
    assert win.load_url("https://example.com") is False


def test_wait_built_reports_a_built_window():
    win = WebViewWindow("t")
    win._ready.set()
    win.native = object()          # stands in for the form
    assert win.wait_built(0.1) is True
    win.native = None
    assert win.wait_built(0.1) is False


def test_window_events_are_the_four_attach_subscribes_to():
    """`attach()` subscribes to exactly these; a missing one is a silent no-op."""
    events = WindowEvents()
    for name in ("loaded", "shown", "closing", "closed"):
        assert hasattr(events, name), name


def test_a_failed_navigation_still_fires_loaded():
    """`loaded` means "the attempt ended", not "the page appeared".

    Code waiting on `loaded` (the cookie grab after sign-in) would wait for
    ever behind a navigation error, with the window sitting on an error page.
    """
    win = WebViewWindow("t")

    class Args:
        IsSuccess = False
        WebErrorStatus = "ConnectionAborted"

    win._on_navigation_completed(None, Args())
    assert win.events.loaded.is_set()
