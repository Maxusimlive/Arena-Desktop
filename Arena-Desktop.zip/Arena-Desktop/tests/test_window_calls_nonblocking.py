"""Every pywebview call that waits for `shown` must be made non-blocking.

The bug this exists for
-----------------------
Google sign-in opened nothing, and the app appeared to hang. The thread dump
shipped from a real Windows machine says exactly where:

    THREAD DUMP: window.load_url не возвращается уже 10 с
    --- поток Dummy-18 ---
      File "webview\\platforms\\winforms.py", line 808, in create
      ... app.Run()                      <- the UI thread is inside the loop
    --- поток Thread-158 ---
      File "arena\\engine.py", line 1060, in import_cookies
      File "webview\\window.py", line 43, in wrapper
      File "webview\\event.py", line 69, in wait      <- _shown_call: wait(20)

`load_url` is wrapped in pywebview's `@_shown_call`, which parks the caller for
20 seconds waiting for a `shown` event that a hidden window may never send.
`arena/diag.py` exists to route exactly such calls through `BeginInvoke`, and
it even lists `load_url` in `_BLOCKING_WINDOW_CALLS` -- but the dictionary that
actually replaces the methods never included it. The constant was documentation,
not code, so `load_url` stayed blocking and every page load could stall the
whole interpreter for 20 seconds with the GIL held.

These tests compare the intent (the constant) with the behaviour (the
dictionary). A future call added to one and not the other fails here instead of
in front of a person clicking a button that does nothing.
"""

from __future__ import annotations

import pytest

from arena import diag


class FakeWindow:
    """Enough of a pywebview window for the wrapper to install itself."""

    def __init__(self):
        self.native = None
        self.events = type("Evt", (), {})()
        self.hidden = 0
        self.loaded_urls = []

    def show(self):
        pass

    def hide(self):
        pass

    def resize(self, *a):
        pass

    def move(self, *a):
        pass

    def restore(self):
        pass

    def load_url(self, url):
        self.loaded_urls.append(url)


def test_load_url_is_covered_by_the_nonblocking_wrappers(monkeypatch):
    """The call that stalled sign-in must be replaced, not just listed.

    Note the second assertion. The first version of this test only compared
    ``window.load_url`` before and after, and it passed while the bug was still
    there: ``getattr(window, "load_url")`` is a *bound method*, and a bound
    method object is created fresh on every access, so ``is`` is never true.
    The test has to look at the instance ``__dict__``, where the wrapper is
    stored.
    """
    monkeypatch.setattr(diag, "enabled", lambda: True)
    monkeypatch.setattr(diag, "_wrapped_windows", [])

    window = FakeWindow()

    diag.make_window_calls_non_blocking(window)

    assert "load_url" in window.__dict__, (
        "load_url was left as pywebview's blocking version. It waits up to 20 "
        "seconds for the `shown` event while holding the GIL, which is exactly "
        "the 'window never opens' freeze from the field thread dump.")
    assert window.__dict__["load_url"] is not FakeWindow.load_url


def test_every_declared_blocking_call_is_actually_wrapped(monkeypatch):
    """No drift between the constant and the code it is supposed to describe."""
    monkeypatch.setattr(diag, "enabled", lambda: True)
    monkeypatch.setattr(diag, "_wrapped_windows", [])

    window = FakeWindow()
    declared = [name for name in diag._BLOCKING_WINDOW_CALLS
                if callable(getattr(window, name, None))]

    diag.make_window_calls_non_blocking(window)

    missing = [name for name in declared if name not in window.__dict__]
    assert not missing, (
        "these calls are declared blocking but were not wrapped, so each can "
        f"park a thread for 20 s: {missing}")


def test_wrapping_load_url_still_navigates(monkeypatch):
    """The wrapper must do the work, not merely accept the call."""
    monkeypatch.setattr(diag, "enabled", lambda: True)
    monkeypatch.setattr(diag, "_wrapped_windows", [])

    window = FakeWindow()
    diag.make_window_calls_non_blocking(window)

    # native is None (no WinForms host here): the wrapper runs the action
    # directly, which is what lets this be tested off Windows.
    window.load_url("https://www.google.com/")
    assert window.loaded_urls == ["https://www.google.com/"], (
        "the load was swallowed by the wrapper; navigation must still happen")


def test_load_url_never_calls_the_blocking_version_when_a_native_host_exists(monkeypatch):
    """The one thing the wrapper must never do is fall back to pywebview's load.

    CoreWebView2 is created asynchronously, so the first navigation usually
    arrives before the browser exists. Falling back to pywebview there parks
    the caller for 20 s on the `shown` event -- that is the field freeze, and
    it must not come back through the "core not ready yet" path.
    """
    monkeypatch.setattr(diag, "enabled", lambda: True)
    monkeypatch.setattr(diag, "_wrapped_windows", [])

    window = FakeWindow()
    window.native = object()          # a WinForms host, but no browser in it yet
    blocked_calls = []
    original = window.load_url
    window.__dict__["_original_load_url"] = lambda url: blocked_calls.append(url)

    diag.make_window_calls_non_blocking(window)
    window.load_url("https://www.google.com/")

    assert blocked_calls == [], (
        "the blocking pywebview load_url was called while CoreWebView2 was not "
        "ready yet; waiting for the browser must happen off the caller's thread")
