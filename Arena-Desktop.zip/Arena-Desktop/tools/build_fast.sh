#!/usr/bin/env bash
# Build the Windows EXE in seconds, with Python changes actually included.
#
# Two things are rebuilt, in this order:
#
#   1. tools/rebuild_pyz.py  — repacks the 39 project modules into the PYZ.
#      This MUST run under CPython 3.12: bytecode is version-locked, and the
#      bundle ships 3.12. uv fetches the interpreter on first use.
#   2. tools/fast_rebuild.py — rewrites the outer archive around the existing
#      bootloader, refreshing data files (app.js, style.css, ...) and using the
#      new PYZ from step 1.
#
# What is deliberately skipped is PyInstaller's Analysis: walking the import
# graph of 1466 modules and taking ~55 s of the old 63 s build. Nothing here
# needs it — the module list already exists in the archive.
#
# Usage:  tools/build_fast.sh
set -euo pipefail

ROOT=/home/user
ARENA_ROOT="$ROOT/Arena-Desktop"
cd "$ROOT"

DEFAULT_BASELINE="$ARENA_ROOT/releases/Arena-Desktop.exe"
[ -f "$DEFAULT_BASELINE" ] || DEFAULT_BASELINE="$ROOT/Arena-Desktop/dist/Arena-Desktop.exe"
EXE="${1:-${ARENA_BASELINE:-$DEFAULT_BASELINE}}"

# -- 1. the interpreter the bundle was built with ---------------------------
if ! command -v uv >/dev/null 2>&1; then
    echo "[build] installing uv (fetches CPython 3.12)"
    pip install --quiet uv
fi
PY=$(uv python find 3.12 2>/dev/null || true)
if [ -z "${PY}" ]; then
    echo "[build] installing CPython 3.12"
    uv python install 3.12
    PY=$(uv python find 3.12)
fi

start=$(date +%s)

# -- 2. rebuild the Python payload from source ------------------------------
# Recompiles EVERY module the archive lists (project, stdlib 3.12 and the
# third-party packages in /tmp/v312), so nothing is copied out of the previous
# PYZ. Copying untouched blobs is what shipped a bundle whose every entry was
# shifted by 17 bytes: correct size, unreadable contents, and the app died at
# startup with "incorrect header check".
"$PY" tools/rebuild_pyz_full.py "$EXE" "$ROOT/tools/pyz_fresh.bin"

# -- 3. rewrite the outer archive -------------------------------------------
python3 tools/fast_rebuild.py

# -- 4. prove the marks landed in the file, not just in the source ----------
"$PY" - "$EXE" <<'CHECK'
"""Verify the shipped bundle contains the changes we just made.

Skipping this is how a "rebuilt" EXE shipped with the previous backend for
days: every size and archive check passed, because the archive was perfectly
well-formed — it simply held the old code.
"""
import sys

sys.path.append("/usr/local/lib/python3.13/site-packages")
from PyInstaller.archive.readers import CArchiveReader, ZlibArchiveReader

path = sys.argv[1]
archive = CArchiveReader(path)
pyz_path = "/tmp/build_check_pyz.bin"
with open(pyz_path, "wb") as fh:
    fh.write(archive.extract("PYZ.pyz"))
pyz = ZlibArchiveReader(pyz_path)


def strings(code, out):
    # Constants cover string literals; names cover module-level identifiers
    # like BROWSER_ORDER, which never appear as a constant.
    out.extend(getattr(code, "co_names", ()))
    for const in getattr(code, "co_consts", ()):
        if isinstance(const, str):
            out.append(const)
        elif hasattr(const, "co_consts"):
            strings(const, out)


problems = []

source_markers = {
    "arena/google_ai.py": "reading is paused",
    "arena/web/app.py": "cookie_probe",
}
for module, marker in (("arena.google_ai", "reading is paused"),
                       ("arena.web.app", "pending"),
                       # round 6: Chrome is forced, the window tolerates a
                       # not-yet-ready debugger, and the smoke run is headless.
                       ("arena.browserwindow", "BROWSER_ORDER"),
                       ("arena.browserwindow", "wait_for_debugger"),
                       # round 7: a Chrome profile is not a WebView2 store,
                       # and the app keeps trying browsers until one opens.
                       ("arena.browserwindow", "FALLBACK_ORDER"),
                       ("arena.appcache", "BROWSER_PROFILES"),
                       ("arena.web.app", "api_cache_clear"),
                       # round 8: the name lookup that made every browser
                       # invisible, and the browser jar the engine now reads.
                       ("arena.browserwindow", "_NAME_ALIASES"),
                       ("arena.browserwindow", "remote-debugging-address"),
                       ("arena.google_ai", "_cookies_from_browser"),
                       ("arena.desktop", "ARENA_NO_GUI"),
                       # round 9: the single-use window, the page that is on
                       # the command line, and the jar read through CDP.
                       ("arena.ephemeral", "close_and_forget"),
                       ("arena.ephemeral", "arena-signin-"),
                       ("arena.browserwindow", "open_url_on_start"),
                       ("arena.google_ai", "_eval_on_page"),
                       ("arena.google_ai", "_wait_for_page"),
                       ("arena.google_ai", "close_sign_in_window"),
                       # round 9: diag must not swallow a browser window's calls.
                       ("arena.diag", "its own calls kept"),
                       ("arena.lazywindow", "close_and_forget"),
                       ("arena.web.app", "_google_window_diagnosis"),
                       # round 10: the second sign-in. A closed window is
                       # forgotten instead of being handed back forever.
                       ("arena.browserwindow", "_watch_exit"),
                       ("arena.browserwindow", "browser-exit-watch"),
                       ("arena.browserwindow", "_exit_watched"),
                       ("arena.lazywindow", "detach_from"),
                       ("arena.google_ai", "_on_window_closed"),
                       ("arena.engine", "the poll must stop waiting"),
                       # round 11: a machine-readable reason for the window,
                       # and waits that stop when waiting cannot help.
                       ("arena.browserwindow", "build_code"),
                       ("arena.browserwindow", "already_running"),
                       ("arena.web.app", "_window_action"),
                       ("arena.google_ai", "_window_cannot_answer"),
                       # the profile must not be re-created by the launch
                       # thread after it was deleted: closing waits for the
                       # thread, not only for the process.
                       ("arena.ephemeral", "current_thread"),
                       # round 12: one press, one page. A failed read must not
                       # mark the engine as never loaded, and a tab the browser
                       # lists late must not be created twice.
                       ("arena.engine", "_after_load"),
                       ("arena.browserwindow", "_known_tab"),
                       ("arena.browserwindow", "_tab_lock"),
                       ("arena.ephemeral", "_same_origin")):
    seen = []
    strings(pyz.extract(module), seen)
    if not any(marker in text for text in seen):
        problems.append(f"{module} is missing {marker!r}")

data = archive.extract("arena\\web\\static\\app.js").decode()
# The Google tick is only allowed to follow a live confirmation.
for marker in ("API.loginPoll()", "function bootNote", "function renderCachePanel",
               "return Boolean(live.signed_in);"):
    if marker not in data:
        problems.append(f"app.js is missing {marker}")

# Decompress and unmarshal EVERY module, not just a marker sample. A PYZ can
# be well-formed and still hold shifted bytes; only a full pass catches that.
import marshal, struct, zlib

raw = pyz_path and open(pyz_path, "rb").read()
toc = marshal.loads(raw[struct.unpack("!i", raw[8:12])[0]:])
broken = []
for name, (typecode, offset, length) in toc:
    try:
        marshal.loads(zlib.decompress(raw[offset:offset + length]))
    except Exception as exc:
        broken.append(f"{name}: {exc}")
if broken:
    problems.append(f"{len(broken)} unusable modules, e.g. {broken[0]}")

print(f"[build] PYZ modules: {len(pyz.toc)}, archive entries: {len(archive.toc)}")
if problems:
    for problem in problems:
        print(f"[build] STALE: {problem}")
    raise SystemExit(1)
print("[build] every marker is present in the bundle")
CHECK

# -- 5. the check that actually proves it runs ------------------------------
# Structural checks (is it an archive, are the markers there) all passed on a
# build that died at startup with "No module named 'flask.sansio'". Only a real
# import walk sees a missing module, so the build refuses to finish without it.
echo "[build] verifying that the payload imports (tests/test_bundle_integrity.py)"
if ! ( cd "$ROOT/Arena-Desktop" && ARENA_PY312="$PY" python3 -m pytest \
        tests/test_bundle_integrity.py -q --no-header -p no:cacheprovider ); then
    echo "[build] FAILED: the bundle in $EXE cannot import its own modules"
    echo "[build] do not ship this file"
    exit 1
fi

# -- 6. and now actually start it -------------------------------------------
# A green import walk still says nothing about the launcher: the app can boot,
# import everything, and die before it serves a page. This runs the executable
# and talks to its HTTP surface. Wine cannot show the window (no WinForms), but
# everything up to and including the route table is real.
if [ -x /usr/bin/wine ]; then
    echo "[build] starting the executable under wine (tools/smoke_wine.py)"
    if ! ARENA_SMOKE_PORT="${ARENA_SMOKE_PORT:-8750}" python3 "$ROOT/tools/smoke_wine.py" "$EXE"; then
        echo "[build] FAILED: the build does not start or does not serve its API"
        echo "[build] do not ship this file"
        exit 1
    fi
else
    echo "[build] wine is not installed -- the launch smoke test did NOT run"
    echo "[build] install wine before shipping: sudo apt-get install -y wine"
    exit 1
fi

size=$(stat -c%s "$EXE")
md5=$(md5sum "$EXE" | cut -d' ' -f1)
took=$(( $(date +%s) - start ))
echo "[build] $EXE"
echo "[build] $size bytes, md5 $md5, ${took}s total"
