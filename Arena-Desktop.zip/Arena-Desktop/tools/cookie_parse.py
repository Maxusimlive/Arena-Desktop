#!/usr/bin/env python3
"""Turn whatever DevTools gives into one Cookie header line.

Handles every copy format of the Network tab context menu:
  * Copy as cURL (bash / POSIX / Windows / PowerShell)
  * Copy as Fetch
  * Copy request headers (a ``cookie: …`` line among the headers)
  * a raw request header value
  * the Application → Cookies table (name<TAB>value<TAB>…)

Usage:
    python3 tools/cookie_parse.py cookies.txt
    pbpaste | python3 tools/cookie_parse.py -

Prints the normalised ``name=value; name=value`` line on stdout and which
auth cookies are present on stderr. Exit code 2 means "no Google session".
"""
import re
import sys

AUTH = ("SID", "HSID", "SSID", "APISID", "SAPISID", "__Secure-1PSID",
        "__Secure-3PSID", "__Secure-1PAPISID", "__Secure-3PAPISID")


def _clean_value(value: str) -> str:
    value = value.strip()
    # Windows cmd escaping leaves these at the end of a copied argument.
    value = re.sub(r'[\^"\'\\]+\s*$', "", value)
    value = re.sub(r'^\^["\']', "", value)
    return value.strip()


def _find_cookie(text: str) -> str:
    """Pull the cookie value out of the copied text."""
    patterns = [
        r"""-H\s+\^?['"]cookie:\s*(.+?)['"]""",   # cURL bash / POSIX / Windows
        r"""-h\s+\^?['"]cookie:\s*(.+?)['"]""",
        r"""['"]cookie['"]\s*=\s*['"](.+?)['"]""",               # PowerShell @{"cookie"="…"}
        r"""['"]?cookie['"]?\s*:\s*['"](.+?)['"]""",             # Fetch / JS object
        r"^\s*cookie:\s*(.+)$",                                 # Copy request headers
        r"^\s*Cookie:\s*(.+)$",
    ]
    for pat in patterns:
        m = re.search(pat, text, re.I | re.M)
        if m and "=" in m.group(1):
            return m.group(1)
    return text


def parse(text: str) -> str:
    text = (text or "").strip()
    if not text:
        return ""
    # cmd line continuations ("^" at EOL) and shell backslashes join lines.
    text = re.sub(r"\^\s*\r?\n", " ", text)
    text = re.sub(r"\\\s*\r?\n", " ", text)
    text = _find_cookie(text)
    text = re.sub(r"^\s*cookie:\s*", "", text, flags=re.I)

    pairs = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        # Application → Cookies table: name<TAB>value<TAB>…
        if "\t" in line:
            cols = [c.strip() for c in line.split("\t")]
            if len(cols) >= 2 and cols[0] and "=" not in cols[0]:
                pairs.append((cols[0], _clean_value(cols[1])))
                continue
        for chunk in line.split(";"):
            chunk = chunk.strip()
            if "=" not in chunk:
                continue
            name, value = chunk.split("=", 1)
            name, value = name.strip(), _clean_value(value)
            if name and value and re.fullmatch(r"[A-Za-z0-9_.\-]+", name):
                pairs.append((name, value))

    seen, out = set(), []
    for name, value in pairs:
        if name in seen:
            continue
        seen.add(name)
        out.append(f"{name}={value}")
    return "; ".join(out)


def main() -> int:
    if sys.argv[1:]:
        chunks = []
        for arg in sys.argv[1:]:
            if arg == "-":
                chunks.append(sys.stdin.read())
            else:
                with open(arg, encoding="utf-8", errors="replace") as fh:
                    chunks.append(fh.read())
        raw = "".join(chunks)
    else:
        raw = sys.stdin.read()

    line = parse(raw)
    names = {p.split("=", 1)[0] for p in line.split("; ") if "=" in p}
    print(line)
    print(f"\n# cookies: {len(names)}", file=sys.stderr)
    have = sorted(names & set(AUTH))
    print("# auth present: " + (", ".join(have) or "NONE — this will not sign in"),
          file=sys.stderr)
    return 0 if have else 2


if __name__ == "__main__":
    sys.exit(main())
