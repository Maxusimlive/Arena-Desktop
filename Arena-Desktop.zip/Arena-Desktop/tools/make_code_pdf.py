#!/usr/bin/env python3
"""Собрать весь код проекта в один PDF -- для загрузки в другую модель.

Что внутри
----------
1. Титул: что это, из какой сборки, сколько файлов и строк.
2. Оглавление: каждый файл с номером страницы, сгруппированный по папкам.
3. Карта проекта: одна строка на файл -- что он делает и зачем он здесь.
   Это то, что модель читает *до* кода, и без него 66 000 строк читаются как
   случайный набор символов.
4. Сам код: каждый файл начинается со своей страницы, с шапкой (путь, размер,
   строки, описание, ключевые имена) и нумерацией строк на полях. Номера строк
   нужны, чтобы в ответе можно было сказать «app.py:12440», а не «где-то там».
5. HANDOFF: история решений -- почему код именно такой. Без неё модель
   «улучшит» то, что уже починено, и вернёт баги, которые чинились в раундах
   1-9.

Почему моноволокно 6.8 pt
-------------------------
3 МБ исходников -- это ~1350 страниц. При 9 pt было бы 2500, и большинство
моделей откажется это читать. 6.8 pt с нумерацией строк остаётся копируемым
текстом и разборчиво на экране при 100 %.

Запуск
------
    python3 tools/make_code_pdf.py --out /home/user/Arena-Desktop-code.pdf
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import pathlib
import re
import time

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (BaseDocTemplate, Frame, KeepTogether, PageBreak,
                                PageTemplate, Paragraph, Preformatted, Spacer,
                                Table, TableStyle)
from reportlab.platypus.tableofcontents import TableOfContents

# -- шрифты ---------------------------------------------------------------
# DejaVu: единственное, что гарантированно есть в контейнере и покрывает и
# кириллицу, и стрелки, и «ёлочки». Лицензия позволяет встраивание.
MONO_PATH = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
MONO_BOLD_PATH = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"
BODY_PATH = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
BODY_BOLD_PATH = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

pdfmetrics.registerFont(TTFont("Mono", MONO_PATH))
pdfmetrics.registerFont(TTFont("MonoBold", MONO_BOLD_PATH))
pdfmetrics.registerFont(TTFont("Body", BODY_PATH))
pdfmetrics.registerFont(TTFont("BodyBold", BODY_BOLD_PATH))
pdfmetrics.registerFontFamily("Body", normal="Body", bold="BodyBold",
                              italic="Body", boldItalic="BodyBold")

CODE_SIZE = 6.8
CODE_LEADING = 8.0
MARGIN_LEFT_MM = 11
MARGIN_RIGHT_MM = 9

# -- что включать ---------------------------------------------------------
INCLUDE_EXT = {".py", ".js", ".css", ".html", ".sh", ".spec", ".toml", ".txt",
               ".json", ".svg", ".cfg", ".md", ".bat", ".ps1", ".yml", ".yaml"}
SKIP_DIRS = {".git", "__pycache__", "releases", "dist", "build", ".pytest_cache",
             ".venv", "venv", "node_modules", ".mypy_cache", ".ruff_cache"}
# HANDOFF идёт отдельным разделом в конце, а не как обычный файл.
HANDOFF_NAME = "HANDOFF.md"

# Порядок разделов: сначала то, что описывает проект, потом код ядра, потом
# интерфейс, потом тесты. Модель читает сверху вниз, и это порядок, в котором
# проект имеет смысл объяснять.
GROUP_ORDER = ["Корень проекта", "arena/ (ядро)", "arena/web/", "arena/tools/",
               "arena/ui/", "scripts/", "tools/", "tests/", "docs/", "assets/",
               "прочее"]


def group_of(rel: pathlib.PurePath) -> str:
    parts = rel.parts
    if len(parts) == 1:
        return "Корень проекта"
    head = parts[0]
    if head == "arena":
        if len(parts) > 2 and parts[1] == "web":
            return "arena/web/"
        if len(parts) > 2 and parts[1] in ("tools", "ui"):
            return f"arena/{parts[1]}/"
        return "arena/ (ядро)"
    if head == "scripts":
        return "scripts/"
    if head == "tools":
        return "tools/"
    if head == "tests":
        return "tests/"
    if head == "docs":
        return "docs/"
    if head == "assets":
        return "assets/"
    return "прочее"


def collect(root: pathlib.Path) -> list[pathlib.Path]:
    files = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if any(part in SKIP_DIRS for part in rel.parts):
            continue
        if path.suffix.lower() not in INCLUDE_EXT:
            continue
        if path.name == HANDOFF_NAME:
            continue
        if path.stat().st_size == 0:
            continue
        files.append(path)
    return files


# -- описания -------------------------------------------------------------
def module_docstring(path: pathlib.Path) -> str:
    """Первая содержательная строка докстроки модуля, если она есть."""
    if path.suffix != ".py":
        return ""
    try:
        tree = ast.parse(path.read_text(errors="replace"))
    except Exception:
        return ""
    doc = (ast.get_docstring(tree) or "").strip()
    if not doc:
        return ""
    for line in doc.splitlines():
        line = line.strip()
        if line and not set(line) <= set("=-─—"):
            return line
    return ""


# Ручные описания для файлов, где докстроки нет или она бесполезна.
# Без них карта проекта -- это список имён, а не объяснение.
MANUAL: dict[str, str] = {
    "arena/web/static/app.js":
        "Вся логика интерфейса: экраны, настройки, поток чата, отрисовка "
        "сообщений, кнопка очистки кэша, экран загрузки с кнопками входа. "
        "Файл огромный (720 КБ) -- это не один модуль, а весь фронтенд.",
    "arena/web/static/index.html":
        "Разметка оболочки интерфейса: каркас приложения, экран загрузки "
        "с кнопкой кэша, контейнеры панелей.",
    "arena/web/static/style.css":
        "Стили интерфейса целиком: темы, сетка панелей, сообщения, экран "
        "загрузки.",
    "arena/web/static/logo.svg":
        "Логотип в интерфейсе.",
    "arena/web/app.py":
        "Flask-сервер: все HTTP-маршруты интерфейса, прокси к arena.ai, "
        "чтение аккаунтов Google, кнопка очистки кэша (/api/cache). "
        "Самый большой файл проекта (522 КБ).",
    "arena/engine.py":
        "Встроенный движок arena.ai: окно чата, загрузка страницы, "
        "перехват ответов, задачи, которые страница выполняет по просьбе "
        "приложения. Здесь же закрытие панели (close_pane/_on_closing).",
    "arena/google_ai.py":
        "Режим Google AI: окно входа, чтение страницы через CDP, "
        "распознавание входа по кукам, наблюдение за входом. Правки "
        "раундов 8-9 (_eval_on_page, _wait_for_page, close_sign_in_window) "
        "живут здесь.",
    "arena/browserwindow.py":
        "Окно входа как настоящий браузер: поиск Chrome/Edge, флаги "
        "командной строки, порт отладки, создание вкладки сразу на нужном "
        "адресе, чтение банки кук через DevTools.",
    "arena/ephemeral.py":
        "Одноразовое окно входа (раунд 9): временный профиль на каждый "
        "вход, адрес в командной строке, удаление профиля после закрытия.",
    "arena/desktop.py":
        "Точка входа приложения: главное окно, создание окон Arena и Google "
        "по требованию, выбор реализации окна, обработка закрытия.",
    "arena/diag.py":
        "Диагностика: чем приложение занимается прямо сейчас. Здесь же "
        "make_window_calls_non_blocking -- обёртки, из-за которых в раунде 9 "
        "не запускался браузер (исправлено: обёртки не глотают вызовы).",
    "arena/lazywindow.py":
        "Окно, которое создаётся только при первом обращении: приложение "
        "не открывает браузер при запуске.",
    "arena/webwindow.py":
        "Собственный хост WebView2 для панели Google без pywebview "
        "(альтернативный путь, включается переменной окружения).",
    "arena/appcache.py":
        "Что считается кэшем приложения и как его очистить, не задевая "
        "данные человека (.arena_personal).",
    "arena/contracts.py":
        "Соглашения с arena.ai: адреса, идентификаторы, форматы запросов.",
    "arena/auth.py":
        "Работа с куками arena.ai: разбор, хранение, проверка сессии.",
    "arena/api.py":
        "Клиент arena.ai и разбор потокового ответа.",
    "arena/gateway.py":
        "Шлюз агента: локальный доступ к инструментам.",
    "arena/native_agent.py":
        "Протокол Native Arena Agent Mode.",
    "arena/agent.py":
        "Локальные инструменты для чатов: работа с папкой на компьютере.",
    "arena/models.py":
        "Каталог моделей: загрузка, кэш, маршрутизация по модальностям.",
    "arena/history_sync.py":
        "Перенос истории arena.ai в локальный формат чатов.",
    "arena/workspace.py":
        "Рабочие папки для ответов с кодом.",
    "arena/config.py":
        "Пути, настройки, сохранение между запусками.",
    "arena/crypto.py":
        "Защита кук на диске средствами Windows (DPAPI).",
    "arena/deep_links.py":
        "Ссылки arenadesktop:// и передача их уже запущенному экземпляру.",
    "arena/procguard.py":
        "Дочерние процессы внутри Job Object: закрыли приложение -- "
        "закрылись и браузеры.",
    "arena/menu.py":
        "Меню в консоли для start.bat.",
    "arena/components.py":
        "Внешние компоненты: поиск и установка.",
    "arena/connectors.py":
        "MCP-коннекторы: настройка и запуск.",
    "arena/google_http.py":
        "Google AI без окна браузера: обычные HTTPS-запросы.",
    "arena/cli.py":
        "Команды командной строки.",
    "arena/procguard.py ": "",
    "arena-cli.py": "Точка входа CLI.",
    "arena-cli.spec": "Сборка PyInstaller: что попадает в EXE.",
    "requirements.txt": "Зависимости.",
    "README.md": "Описание проекта для человека.",
    "START_HERE.md": "С чего начинать чтение проекта.",
    "APP.md": "Подробное описание приложения.",
    "DIAGNOSTIC_README.md": "Как читать диагностические логи.",
    "KNOWN_ISSUES.md": "Известные проблемы.",
    "AUTH.md": "Как устроена авторизация.",
    "RELEASE_NOTES.md": "Что менялось по версиям.",
    "PROMPT_FOR_CODE_MODE.md": "Готовый промпт для режима Code.",
    "README_UI.txt": "Заметки по интерфейсу.",
    "tests/conftest.py": "Общая настройка тестов.",
    "tests/gilprobe.py":
        "Измеритель GIL: ловит «приложение замерло целиком» без Windows.",
    "tests/test_ephemeral_window.py":
        "Тесты одноразового окна (раунд 9): профиль, командная строка, "
        "отсутствие повторной навигации, закрытие после входа.",
    "tests/test_browser_window.py": "Тесты окна-браузера.",
    "tests/test_google_ai.py": "Тесты режима Google AI.",
    "tests/test_cache_button.py": "Тесты кнопки очистки кэша и её текста.",
    "tests/test_bundle_integrity.py":
        "Проверка, что собранный EXE содержит те же модули, что и исходники.",
    "tests/test_no_gil_freeze.py":
        "Воспроизведение зависания всего приложения без Windows.",
    "tests/test_lazy_window.py":
        "Окно открывается, когда его просят, и не раньше.",
    "tools/cookie_parse.py": "Разбор кук из DevTools в одну строку Cookie.",
    "scripts/check_exe.py": "Проверка, что в EXE попал нужный код.",
    "scripts/check_pe_arch.py": "Проверка разрядности PE-файла.",
}


# Задача -> файлы. Это то, что экономит читателю час поиска по 786 страницам.
TOPIC_INDEX: list[tuple[str, str]] = [
    ("Вход в Google: окно, куки, засчитывание входа",
     "arena/google_ai.py → arena/ephemeral.py → arena/browserwindow.py"),
    ("Почему окно вообще открывается (или нет)",
     "arena/browserwindow.py (запуск, порты, кандидаты браузеров) → "
     "arena/lazywindow.py → arena/desktop.py"),
    ("Одноразовое окно: временный профиль и удаление",
     "arena/ephemeral.py → tests/test_ephemeral_window.py"),
    ("Кнопки и экран загрузки",
     "arena/web/static/app.js (boot*, cache*) → arena/web/static/index.html → "
     "arena/web/static/style.css"),
    ("Очистка кэша: что чистится и что нельзя трогать",
     "arena/appcache.py → arena/web/app.py (/api/cache, /api/cache/clear) → "
     "tests/test_cache_button.py"),
    ("Сервер и все HTTP-маршруты интерфейса",
     "arena/web/app.py"),
    ("Движок arena.ai: окно чата и ответы",
     "arena/engine.py → arena/contracts.py → arena/api.py"),
    ("Режим Google AI по обычному HTTPS (без окна)",
     "arena/google_http.py → arena/google_ai.py"),
    ("Аккаунты, сессии, куки на диске",
     "arena/auth.py → arena/crypto.py → arena/web/app.py"),
    ("Диагностика и логи (desktop.log)",
     "arena/diag.py → DIAGNOSTIC_README.md"),
    ("Зависания и GIL: почему приложение мертвело",
     "tests/test_no_gil_freeze.py → arena/diag.py → tests/gilprobe.py"),
    ("Сборка EXE и проверка, что код внутри именно тот",
     "arena-cli.spec → scripts/check_exe.py → tools/build_fast.sh → "
     "tests/test_bundle_integrity.py"),
    ("Агент, инструменты, MCP",
     "arena/agent.py → arena/native_agent.py → arena/tools/ → "
     "arena/connectors.py"),
    ("Повторный вход: почему второй раз окно не открывалось",
     "arena/browserwindow.py (start, _watch_exit) → arena/lazywindow.py "
     "(forget, detach_from) → arena/google_ai.py (_on_window_closed) → "
     "tests/test_ephemeral_window.py"),
    ("История: что менялось и почему", "HANDOFF.md (в конце документа)"),
]


def describe(path: pathlib.Path, rel: str) -> str:
    manual = MANUAL.get(rel) or MANUAL.get(rel.rstrip("/"))
    if manual:
        return manual
    doc = module_docstring(path)
    if doc:
        return doc
    if path.suffix == ".md":
        # Первый заголовок или первая строка текста.
        for line in path.read_text(errors="replace").splitlines():
            line = line.strip().lstrip("#").strip()
            if line:
                return line[:200]
    if path.suffix == ".sh":
        for line in path.read_text(errors="replace").splitlines():
            if line.startswith("#") and not line.startswith("#!"):
                text = line.lstrip("# ").strip()
                if text:
                    return text[:200]
    return ""


def top_names(path: pathlib.Path, limit: int = 14) -> list[str]:
    """Ключевые имена файла: классы, функции верхнего уровня, маршруты.

    Нужны в шапке файла: по ним модель понимает, что искать внутри, ещё до
    чтения 500 КБ кода.
    """
    names: list[str] = []
    if path.suffix == ".py":
        try:
            tree = ast.parse(path.read_text(errors="replace"))
        except Exception:
            return names
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                names.append(node.name)
    elif path.suffix == ".js":
        text = path.read_text(errors="replace")
        for match in re.finditer(r"^\s*(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(",
                                 text, re.MULTILINE):
            names.append(match.group(1))
        for match in re.finditer(r"^\s*(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?\(",
                                 text, re.MULTILINE):
            names.append(match.group(1))
    seen: set[str] = set()
    out = []
    for name in names:
        if name in seen:
            continue
        seen.add(name)
        out.append(name)
        if len(out) >= limit:
            break
    return out


# -- стили -----------------------------------------------------------------
def styles() -> dict[str, ParagraphStyle]:
    return {
        "title": ParagraphStyle("title", fontName="BodyBold", fontSize=26,
                                leading=32, spaceAfter=6),
        "subtitle": ParagraphStyle("subtitle", fontName="Body", fontSize=11,
                                   leading=16, textColor=colors.HexColor("#555555")),
        "h1": ParagraphStyle("h1", fontName="BodyBold", fontSize=17, leading=22,
                             spaceBefore=4, spaceAfter=10,
                             textColor=colors.HexColor("#111111")),
        "h2": ParagraphStyle("h2", fontName="BodyBold", fontSize=12.5, leading=16,
                             spaceBefore=10, spaceAfter=4),
        "body": ParagraphStyle("body", fontName="Body", fontSize=8.8, leading=12.4,
                               spaceAfter=4),
        "small": ParagraphStyle("small", fontName="Body", fontSize=7.6, leading=10.5,
                                textColor=colors.HexColor("#444444")),
        "code": ParagraphStyle("code", fontName="Mono", fontSize=CODE_SIZE,
                               leading=CODE_LEADING),
        "filehead": ParagraphStyle("filehead", fontName="BodyBold", fontSize=11,
                                   leading=14, spaceBefore=0, spaceAfter=2),
        "toc0": ParagraphStyle("toc0", fontName="BodyBold", fontSize=9.5,
                               leading=13, spaceBefore=6),
        "toc1": ParagraphStyle("toc1", fontName="Body", fontSize=8.6, leading=12,
                               leftIndent=10),
        "toc2": ParagraphStyle("toc2", fontName="Mono", fontSize=6.9, leading=9.6,
                               leftIndent=18, textColor=colors.HexColor("#333333")),
    }


# -- документ с закладками и оглавлением -----------------------------------
class CodeDoc(BaseDocTemplate):
    """Обычный документ плюс два уровня закладок в боковой панели PDF.

    Закладки важнее, чем кажется: в PDF на 1300 страниц без них не найти
    нужный файл, а именно ради поиска по файлам этот документ и делается.
    """

    def __init__(self, filename: str, **kwargs):
        super().__init__(filename, **kwargs)
        frame = Frame(self.leftMargin, self.bottomMargin,
                      self.width, self.height, id="normal",
                      leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
        self.addPageTemplates([PageTemplate(id="page", frames=[frame],
                                            onPage=self._footer)])
        self.toc_entries: dict[str, int] = {}

    def _footer(self, canvas, doc):
        canvas.saveState()
        canvas.setFont("Body", 7)
        canvas.setFillColor(colors.HexColor("#888888"))
        canvas.drawRightString(A4[0] - MARGIN_RIGHT_MM * mm, 10 * mm, str(doc.page))
        canvas.drawString(MARGIN_LEFT_MM * mm, 10 * mm,
                          "Arena Desktop — исходный код и HANDOFF")
        canvas.restoreState()

    def afterFlowable(self, flowable):
        """Запомнить закладку/оглавление и, если заказано, номер страницы."""
        bookmark = getattr(flowable, "_bookmark", None)
        if bookmark is None:
            return
        level, text, key = bookmark
        self.canv.bookmarkPage(key)
        self.canv.addOutlineEntry(text, key, level=level, closed=(level >= 1))
        # Уровень 2 -- это файлы. Без них оглавление бесполезно: по нему
        # ищут «где app.py», а не «где группа arena/».
        if level <= 2:
            self.notify("TOCEntry", (level, text, self.page, key))
        self.toc_entries[key] = self.page


class Heading(Paragraph):
    """Абзац, который заодно становится закладкой и строкой оглавления."""

    def __init__(self, text: str, style: ParagraphStyle, *, level: int, key: str):
        super().__init__(text, style)
        self._bookmark = (level, text, key)


def file_header_block(path: pathlib.Path, root: pathlib.Path, rel: str,
                      st: dict[str, ParagraphStyle], *, level: int = 2) -> list:
    """Шапка одного файла: путь, размер, строки, описание, ключевые имена."""
    size = path.stat().st_size
    try:
        line_count = len(path.read_text(errors="replace").splitlines())
    except Exception:
        line_count = 0
    anchor = "file:" + rel
    head = Heading(rel, st["filehead"], level=level, key=anchor)
    facts = f"{size:,} байт · {line_count:,} строк".replace(",", " ")
    bits = [facts]
    desc = describe(path, rel)
    if desc:
        bits.append(desc)
    names = top_names(path)
    if names:
        shown = ", ".join(names)
        bits.append("Ключевые имена: " + shown)
    body = Paragraph(" — ".join(bits[:1]) + ("<br/>" + "<br/>".join(bits[1:]) if len(bits) > 1 else ""),
                     st["small"])
    return [KeepTogether([head, body, Spacer(1, 3)])]


def numbered(text: str) -> str:
    """Код с нумерацией строк на полях.

    Номера вшиты в текст, а не нарисованы сбоку: так они копируются вместе с
    кодом, и ссылка «app.py:12440» из ответа модели находится обычным поиском
    по PDF.
    """
    lines = text.expandtabs(4).split("\n")
    width = len(str(len(lines)))
    return "\n".join(f"{i:>{width}}  {line}" for i, line in enumerate(lines, 1))


def chars_per_line(margin_left_mm: float, margin_right_mm: float) -> int:
    """Сколько символов моноширинного кода влезает в строку.

    Считается по метрике шрифта, а не подбирается на глаз: при 6.8 pt один
    символ занимает 4.09 pt, и строка в 190 символов уезжает за правый край
    (ровно это и было видно на первой сборке -- текст обрывался на границе).
    Пять символов отдаём под номера строк и два под отступ.
    """
    width_pt = A4[0] - (margin_left_mm + margin_right_mm) * mm
    glyph_pt = pdfmetrics.stringWidth("M", "Mono", CODE_SIZE)
    return max(40, int(width_pt / glyph_pt) - 7)


def wrap_long_lines(text: str, limit: int = 190) -> str:
    """Длинные строки переносим с пометкой.

    Иначе строка в 1488 символов уезжает за правый край и пропадает
    (Preformatted не переносит). Перенос с «↳» честнее, чем обрезка: видно,
    что это продолжение.
    """
    out = []
    for line in text.split("\n"):
        while len(line) > limit:
            out.append(line[:limit] + " ↳")
            line = "    " + line[limit:]
        out.append(line)
    return "\n".join(out)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default="/home/user/Arena-Desktop")
    parser.add_argument("--out", default="/home/user/Arena-Desktop-code.pdf")
    parser.add_argument("--handoff", default=None,
                        help="HANDOFF.md (по умолчанию -- из корня проекта)")
    args = parser.parse_args()

    root = pathlib.Path(args.root).resolve()
    handoff_path = pathlib.Path(args.handoff) if args.handoff else root / HANDOFF_NAME
    st = styles()
    started = time.time()
    code_limit = chars_per_line(MARGIN_LEFT_MM, MARGIN_RIGHT_MM)
    print(f"[pdf] в строку влезает {code_limit} символов кода")

    files = collect(root)
    rels = [str(p.relative_to(root)) for p in files]

    # Группы в осмысленном порядке, внутри группы -- по пути.
    grouped: dict[str, list[tuple[pathlib.Path, str]]] = {}
    for path, rel in zip(files, rels):
        grouped.setdefault(group_of(pathlib.Path(rel)), []).append((path, rel))
    ordered_groups = [g for g in GROUP_ORDER if g in grouped]
    ordered_groups += [g for g in grouped if g not in GROUP_ORDER]

    total_lines = 0
    for path in files:
        try:
            total_lines += len(path.read_text(errors="replace").splitlines())
        except Exception:
            pass

    exe = root / "releases" / "Arena-Desktop.exe"
    exe_line = ""
    if exe.is_file():
        digest = hashlib.md5(exe.read_bytes()).hexdigest()
        exe_line = f"Сборка: Arena-Desktop.exe, {exe.stat().st_size:,} байт, md5 {digest}"

    story: list = []

    # -- титул ---------------------------------------------------------
    story.append(Spacer(1, 60 * mm))
    story.append(Paragraph("Arena Desktop", st["title"]))
    story.append(Paragraph("Полный исходный код проекта и HANDOFF", st["subtitle"]))
    story.append(Spacer(1, 8 * mm))
    story.append(Paragraph(
        "Документ собран для передачи другой модели: сначала карта проекта — "
        "что делает каждый файл и почему он такой, затем весь код с номерами "
        "строк, в конце — HANDOFF с историей решений и списком того, что уже "
        "чинилось и не должно быть «улучшено» заново.", st["body"]))
    story.append(Spacer(1, 5 * mm))
    facts = [
        ["Файлов", f"{len(files)}"],
        ["Строк кода и текста", f"{total_lines:,}".replace(",", " ")],
        ["Корень", str(root)],
        ["Собрано", time.strftime("%Y-%m-%d %H:%M")],
    ]
    if exe_line:
        facts.append(["Сборка", exe_line.replace("Сборка: ", "")])
    table = Table(facts, colWidths=[45 * mm, 120 * mm])
    table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "BodyBold"),
        ("FONTNAME", (1, 0), (1, -1), "Body"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("LEADING", (0, 0), (-1, -1), 12),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("LINEBELOW", (0, 0), (-1, -2), 0.25, colors.HexColor("#DDDDDD")),
    ]))
    story.append(table)
    story.append(Spacer(1, 8 * mm))
    story.append(Paragraph(
        "Как читать: раздел «Карта проекта» — оглавление по смыслу; "
        "«Оглавление» — по номерам страниц; каждый файл начинается с новой "
        "страницы и подписан путём. Ссылки в тексте вида "
        "<font name='Mono' size='7'>arena/web/app.py:12440</font> находятся "
        "поиском по документу.", st["small"]))
    story.append(PageBreak())

    # -- карта проекта -------------------------------------------------
    story.append(Heading("Карта проекта", st["h1"], level=0, key="map"))
    story.append(Paragraph(
        "Одна строка на файл: путь, размер и что этот файл делает. Читать "
        "стоит до кода — по этой таблице видно, где что искать.", st["body"]))
    story.append(Spacer(1, 2 * mm))
    story.append(Paragraph(
        "Цветовые пометки нет намеренно: она мешает печати и поиску. "
        "Файлы идут в том же порядке, что и в документе ниже.", st["small"]))
    story.append(Spacer(1, 3 * mm))

    map_header = Paragraph("<b>Файл</b>", st["small"])
    map_facts = Paragraph("<b>Размер / строки</b>", st["small"])
    map_desc = Paragraph("<b>Что это</b>", st["small"])
    map_rows: list[list] = [[map_header, map_facts, map_desc]]
    for group in ordered_groups:
        map_rows.append([Paragraph(f"<b>{group}</b>", st["small"]), "", ""])
        for path, rel in grouped[group]:
            size = path.stat().st_size
            try:
                lines = len(path.read_text(errors="replace").splitlines())
            except Exception:
                lines = 0
            size_text = (f"{size / 1024:.0f} КБ" if size >= 1024
                         else f"{size} Б")
            map_rows.append([
                Paragraph(f"<font name='Mono' size='6.5'>{rel}</font>", st["small"]),
                Paragraph(f"<font name='Mono' size='6.3'>{size_text}<br/>"
                          f"{lines:,} стр</font>".replace(",", " "), st["small"]),
                Paragraph(describe(path, rel) or "—", st["small"]),
            ])
    map_table = Table(map_rows, colWidths=[51 * mm, 15 * mm, 104 * mm], repeatRows=1)
    map_table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("FONTSIZE", (0, 0), (-1, -1), 6.9),
        ("LEADING", (0, 0), (-1, -1), 8.6),
        ("TOPPADDING", (0, 0), (-1, -1), 1.6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 1.6),
        ("LINEBELOW", (0, 0), (-1, 0), 0.4, colors.HexColor("#999999")),
        ("LINEBELOW", (0, 1), (-1, -1), 0.15, colors.HexColor("#E8E8E8")),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#F2F2F2")),
    ]))
    story.append(map_table)
    story.append(PageBreak())

    # -- где что искать ------------------------------------------------
    story.append(Heading("Где что искать", st["h1"], level=0, key="topics"))
    story.append(Paragraph(
        "Короткий указатель по задачам: с чего начинать, если нужно понять или "
        "поменять конкретную часть приложения. Файлы перечислены в порядке "
        "важности, а не по алфавиту.", st["body"]))
    story.append(Spacer(1, 2 * mm))
    topic_rows = [[Paragraph("<b>Задача</b>", st["small"]),
                   Paragraph("<b>Файлы</b>", st["small"])]]
    for topic, where in TOPIC_INDEX:
        topic_rows.append([
            Paragraph(topic, st["small"]),
            Paragraph(f"<font name='Mono' size='6.5'>{where}</font>", st["small"]),
        ])
    topic_table = Table(topic_rows, colWidths=[62 * mm, 108 * mm], repeatRows=1)
    topic_table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEADING", (0, 0), (-1, -1), 9.6),
        ("TOPPADDING", (0, 0), (-1, -1), 2.4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2.4),
        ("LINEBELOW", (0, 0), (-1, 0), 0.4, colors.HexColor("#999999")),
        ("LINEBELOW", (0, 1), (-1, -1), 0.15, colors.HexColor("#E8E8E8")),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#F2F2F2")),
    ]))
    story.append(topic_table)
    story.append(PageBreak())

    # -- оглавление ----------------------------------------------------
    story.append(Heading("Оглавление", st["h1"], level=0, key="toc"))
    toc = TableOfContents()
    toc.levelStyles = [st["toc0"], st["toc1"], st["toc2"]]
    toc.dotsMinLevel = 0
    story.append(toc)
    story.append(PageBreak())

    # -- код -----------------------------------------------------------
    story.append(Heading("Исходный код", st["h1"], level=0, key="code"))
    story.append(Paragraph(
        "Файлы идут по группам. Каждый начинается с новой страницы: путь, "
        "размер, число строк, что это и ключевые имена внутри. Слева — "
        "номера строк, по ним можно ссылаться в ответе.", st["body"]))
    story.append(PageBreak())

    for group in ordered_groups:
        key = f"group:{group}"
        story.append(Heading(group, st["h1"], level=1, key=key))
        story.append(Paragraph(
            f"Файлов в группе: {len(grouped[group])}.", st["small"]))
        story.append(Spacer(1, 3 * mm))
        for path, rel in grouped[group]:
            story.extend(file_header_block(path, root, rel, st, level=2))
            try:
                text = path.read_text(errors="replace")
            except Exception as exc:
                text = f"<не удалось прочитать: {exc}>"
            body = wrap_long_lines(numbered(text), limit=code_limit)
            story.append(Preformatted(body, st["code"]))
            story.append(PageBreak())

    # -- HANDOFF -------------------------------------------------------
    if handoff_path.is_file():
        text = handoff_path.read_text(errors="replace")
        story.append(Heading(HANDOFF_NAME, st["h1"], level=1, key="file:HANDOFF"))
        story.append(Paragraph(
            "История решений: что было сломано, почему именно так и что нельзя "
            "переделывать заново. Это самая важная часть документа для того, "
            "кто будет менять код.", st["body"]))
        story.append(Spacer(1, 2 * mm))
        story.append(Preformatted(wrap_long_lines(numbered(text), limit=code_limit),
                                  st["code"]))

    doc = CodeDoc(args.out, pagesize=A4,
                  leftMargin=MARGIN_LEFT_MM * mm, rightMargin=MARGIN_RIGHT_MM * mm,
                  topMargin=12 * mm, bottomMargin=14 * mm,
                  title="Arena Desktop — исходный код и HANDOFF",
                  author="Arena Desktop build notes",
                  subject="Полный исходный код проекта")
    doc.multiBuild(story)

    size = os.path.getsize(args.out)
    print(f"[pdf] {args.out}")
    print(f"[pdf] {size:,} байт ({size / 1024 / 1024:.2f} МБ), "
          f"файлов {len(files)}, строк {total_lines:,}, "
          f"за {time.time() - started:.0f} с")
    print(f"[pdf] закладок: {len(doc.toc_entries)}")


if __name__ == "__main__":
    main()
