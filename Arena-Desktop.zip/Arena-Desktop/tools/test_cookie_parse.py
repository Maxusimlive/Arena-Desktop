"""Sanity tests for tools/cookie_parse.py (all DevTools copy formats)."""
import importlib.util
import pathlib
import unittest

spec = importlib.util.spec_from_file_location(
    "cookie_parse", pathlib.Path(__file__).parent / "cookie_parse.py")
cp = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cp)

EXPECTED = "SID=g.a000A; HSID=AXy"


class CookieParseTest(unittest.TestCase):
    def test_curl_windows(self):
        text = ('curl ^"https://www.google.com/^" ^\n'
                '  -H ^"cookie: SID=g.a000A; HSID=AXy; SSID=AQ7^" ^\n  --compressed')
        out = cp.parse(text)
        self.assertTrue(out.startswith(EXPECTED))
        self.assertNotIn("^", out)

    def test_curl_posix(self):
        text = ("curl 'https://www.google.com/' \\\n"
                "  -H 'cookie: SID=g.a000A; HSID=AXy' \\\n  --compressed")
        self.assertEqual(cp.parse(text), EXPECTED)

    def test_request_headers_block(self):
        text = ":authority: www.google.com\ncookie: SID=g.a000A; HSID=AXy\nuser-agent: x"
        self.assertEqual(cp.parse(text), EXPECTED)

    def test_powershell_and_fetch(self):
        self.assertEqual(cp.parse('curl.exe -Headers @{"cookie"="SID=g.a000A; HSID=AXy"}'),
                         EXPECTED)
        self.assertEqual(cp.parse('fetch("x", {"headers": {"cookie": "SID=g.a000A; HSID=AXy"}})'),
                         EXPECTED)

    def test_cookie_table_tsv(self):
        self.assertEqual(cp.parse("SID\tg.a000A\nHSID\tAXy\n"), EXPECTED)

    def test_no_session_is_reported(self):
        line = cp.parse("NID=527=Z1; SIDCC=abc")
        names = {p.split("=", 1)[0] for p in line.split("; ")}
        self.assertFalse(names & set(cp.AUTH))


if __name__ == "__main__":
    unittest.main()
